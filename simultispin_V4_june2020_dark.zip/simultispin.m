function Simultispin
%
% (Pour windows et linux)
% Simulation et fit avec easyspin. 
%
% Simultispin Version 4 nouveaut�s : 
% Outils smoothing dans tool menu
% Ajout DStrain et gestion D/g-AStrains
% Ajout checkbox aniso pour choisir broadening iso / strains aniso
% Prise en charge simul avec ancienne version
% Ajout info conversion A hyperfin en mT avec g r�el et ZFS en MHz
% Ajout enable/disable ZFS selon S
% Marker axialit� en rouge mieux visibles pour dark theme
% Simplification esfit table quand param�tres = 0
% Correction de bug :
% bug cancel, l�gendes et �chelles (eprload) des tools menu
% bug quand hyperfin diff�rent entre 2 component windows
% suppression "MHz" pour gStrain
% Garlic : warning quand S>1/2 et chkbox strains
% Juin 2020
% Rappel V3 :
% Tools menu baseline corr et double I
% hyperfin en MHz au lieu de mT
% Residue box

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

warning('off','MATLAB:oldPfileVersion') % eviter warning: pcode file ...
warning('off','MATLAB:hg:uicontrol:ParameterValuesMustBeValid') %eviter warning slider out of range
warning('off','MATLAB:hg:uicontrol:ValueMustBeInRange')%eviter warning slider out of range sur version recente
warning('off','MATLAB:uitabgroup:OldVersion') %eviter warning tab

path4doc = mfilename('fullpath');%chemin de la derniere function lancee
path4doc=path4doc(1:end-11); %chemin pour ouvrir la doc

% au lancement, fermeture de la fenetre Simultispin prealablement ouverte 
closeSimultispin();

clc; %clear command window
evalin('base','clear'); %clear workspace de base

%% Simultispin_main
ftsz=11;%fontsize en pixels

% if isempty(findobj('type','figure'))
%     hSimultispinmain=figure(1);
% else
%    hSimultispinmain=figure(max(findobj('type','figure'))+1); %pour ne pas superposer des figures
% end;
hSimultispinmain=figure();
%taille ecran  taille fenetre
scrszpix = get(0,'ScreenSize'); %taille ecran [left, bottom, width, height] en pixels
%scrszcm=scrszpix/get(0,'screenpixelsperinch')*2.54; %1inch=2.54cm  taille ecran en cm

set(hSimultispinmain,'Units','pixels','Outerposition',...    
    [scrszpix(3)/7 0.1*scrszpix(4) 700 scrszpix(4)*0.81],...
    'Name','Simultispin_main','Menubar', 'none', 'Toolbar', 'figure',...%'resize','off',...
    'NumberTitle','off','DoubleBuffer','on','CloseRequestFcn',@closeSimultispin,...
    'color',[0.25 0.25 0.25]);

%%% panel bas %%%
hpanelmain = uipanel(...
        'Parent',hSimultispinmain,...
        'Title','',...
        'Position',[0 0 1 0.249],...
        'BackgroundColor',[0.25 0.25 0.25]);
    
%%% delta B %%%
hdeltaB1=uicontrol('Style','text','Units','Normalized','pos',[0.3 0.135 0.10 0.17],...
    'parent',hpanelmain,'String',{'deltaB (mT)';'(real-read) ='},'HorizontalAlignment','center','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
    'fontunits','pixels','fontsize',ftsz,'enable','off','TooltipString','Experimental offset of magnetic field');
hdeltaBval=uicontrol('Style','edit','Units','Normalized','pos',[0.397 0.18 0.043 0.10],'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
    'parent',hpanelmain,'String',num2str(0,'%3.2f'),'Callback', @defdeltaB,'fontunits','pixels','fontsize',ftsz,...
    'enable','off','TooltipString','Experimental offset of magnetic field');
hdeltaBslid=uicontrol('Style','slider','Units','Normalized','pos',[0.439 0.18 0.022 0.1],'BackgroundColor',[0.9 0.9 0.9],...
    'parent',hpanelmain,'String',num2str(0,'%3.2f'),'Callback', @sliddeltaB,'fontunits','pixels','fontsize',ftsz,...
    'Min',-20,'Max',+20,'Value',0,'SliderStep',[0.01/40 1/40],'enable','off','TooltipString','Experimental offset of magnetic field');

%%% push buttons %%%
haddcomp=uicontrol('Style','pushbutton','String','+','Units','Normalized',...
    'pos',[0.5 0.01 0.12 0.15],'parent',hpanelmain,'Callback', @addcomponent,...
    'TooltipString','Add new component','fontunits','pixels','fontsize',ftsz*3);
hdefaultpar=uicontrol('Style','pushbutton','String','init.','Units','Normalized',...
    'pos',[0.625 0.01 0.03 0.15],'parent',hpanelmain,'Callback', @reinitcomponent,...
    'TooltipString','Set default values for next components','fontunits','pixels','fontsize',ftsz);

hloadexp=uicontrol('Style','pushbutton','String','LOAD Exp.','Units','Normalized',...
    'pos',[0.01 0.17 0.12 0.12],'parent',hpanelmain,'Callback', @loadexpcllbck,...
    'TooltipString',sprintf('Load new experimental spectrum\n*.DSC or *.SPC'),'fontunits','pixels','fontweight','bold','fontsize',ftsz*1.1);

hloadsim=uicontrol('Style','pushbutton','String','LOAD Sim.','Units','Normalized',...
    'pos',[0.5 0.17 0.12 0.12],'parent',hpanelmain,'Callback', @loadparam,...
    'TooltipString','Load previous simulation','fontunits','pixels','fontweight','bold','fontsize',ftsz*1.1);

hrealtime=uicontrol('Style','checkbox','String','Real Time','Units','Normalized',...
    'fontunits','pixels','fontsize',1.1*ftsz,... %largeur simul anisotrope
    'pos',[0.76 0.13 0.15 0.18],'parent',hpanelmain,'Callback',@chkrealtime,...
    'TooltipString',sprintf('Simulation calculated in real time.\nA first "Run Simul." is needed,\nonly one component is calculated.'),...
    'value',0,'fontweight','bold','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25]);

hrunsimul=uicontrol('Style','pushbutton','String','> RUN Sim','Units','Normalized',...
    'pos',[0.76 0.01 0.12 0.15],'parent',hpanelmain,'Callback', @runsimulcllbck,...
    'fontunits','pixels','fontsize',ftsz*1.2,'fontweight','bold','enable','on','BackgroundColor',[0 0.8 0.4],'ForegroundColor',[0.25 0.25 0.25],...
    'TooltipString',sprintf('Run simulation with EasySpin (garlic or pepper function).\nAll components are calculated.'));%,'interruptible','off');

hsavesimul=uicontrol('Style','pushbutton','String','SAVE Sim.','Units','Normalized',...
    'pos',[0.625 0.17 0.12 0.12],'parent',hpanelmain,'Callback', @savesimul,'enable','off',...
    'fontunits','pixels','fontsize',ftsz*1.1,'fontweight','bold','TooltipString',sprintf('Save current simulation\n(only included components are saved)'));

hcurrentsimul=uicontrol('Style','pushbutton','String','Buffer','Units','Normalized',...
    'pos',[0.66 0.01 0.085 0.15],'parent',hpanelmain,'Callback', @currentsimul,'enable','off',...
    'fontunits','pixels','fontsize',ftsz,'TooltipString','Display last simulation (not saved)');

exptool = {'  TOOLS MENU';'  > Baseline Correction';'  > Double Integration';'  > Smoothing'};
hexptool = uicontrol(...
        'Parent',hpanelmain,...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'BackgroundColor','w',...
        'Units','normalized',...
        'Callback',@cllbtool,...
        'Position',[0.145 0.15 0.15 0.14],...
        'String',exptool,...
        'Style','popupmenu',...
        'TooltipString',sprintf('Select tool for experimental spectrum'),...
        'enable', 'off',...
        'Value',1);

simultype={'Frozen Solution';'Fast Motion'};
hsimultype=uicontrol(...
        'Parent',hpanelmain,...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'BackgroundColor','w',...
        'Units','normalized',...
        'Callback',@func4easyspin,...
        'Position',[0.145 0.01 0.15 0.14],...
        'String',simultype,...
        'Style','popupmenu',...
        'TooltipString',sprintf('Select the simulation type,\nrelated to the choice of EasySpin function (garlic or pepper)'),...
        'Value',1);

htemptext = uicontrol('Parent',hpanelmain,'Units','normalized','FontUnits','pixels',...
        'HorizontalAlignment','right','FontSize',1.1*ftsz,'Fontweight','Bold',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.00 0.03 0.065 0.10],'String','T (K) =','Style','text','enable','on');   
    
htempexp = uicontrol('Parent',hpanelmain,'Units','normalized',...
        'FontUnits','pixels','BackgroundColor','w','Callback',@cllbcktempexp,...
        'FontSize',ftsz,'Position',[0.07 0.04 0.06 0.10],...
        'TooltipString','Experimental temperature','Style','edit','enable','on');
    
simulmode = {'perpendicular';'parallel'};
hsimulmode = uicontrol(...
        'Parent',hpanelmain,...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'BackgroundColor','w',...
        'Units','normalized',...
        'Callback',@cllbckmode,...
        'Position',[0.31 0.01 0.15 0.14],...
        'String',simulmode,...
        'Style','popupmenu',...
        'TooltipString',sprintf('perpendicular or parallel mode for simulation'),...
        'Value',1);
    
hresidue=uicontrol('Style','checkbox','String','Residue','Units','Normalized',...
    'pos',[0.885 0.17 0.11 0.12],'parent',hpanelmain,'Callback', @cllbckresidue, 'value',0,'enable','off',...
    'fontunits','pixels','fontsize',ftsz*1.1,'fontweight','bold','TooltipString','Plot the residue of the simulation','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25]);
    
hesfit=uicontrol('Style','pushbutton','String','>> ESFIT','Units','Normalized','ForegroundColor',[0 0.6 0],...
    'pos',[0.885 0.01 0.11 0.15],'parent',hpanelmain,'Callback', @openesfit,'enable','on',...
    'fontunits','pixels','fontsize',ftsz*1.2,'fontweight','bold','TooltipString','Open "esfit" panel (fitting with EasySpin)');

% hquitesfit=uicontrol('Style','pushbutton','String','Quit "esfit"','Units','Normalized',...
%     'pos',[0.35 0.05 0.08 0.15],'parent',hpanelmain,'Callback', @quitesfit,'enable','on','visible', 'off',...
%     'fontunits','pixels','fontsize',ftsz,'TooltipString','Import data from "esfit" (fitting with EasySpin)');

%%% list exp%%%
hlistexp=uicontrol('Style','listbox','Units','Normalized','pos',[0.01 0.3 0.45 0.6],...
    'parent',hpanelmain,'max',2,'min',0,'enable','off','Callback',@reloadexp,'fontunits','pixels','fontsize',ftsz,...
    'TooltipString','Experiments: select one or more...','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25]);
hsuprfromlistexp=uicontrol('Style','pushbutton','String','X','Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.46 0.81 0.03 0.08],'parent',hpanelmain,'Callback', @suprfromlistexp,'enable','off',...
    'TooltipString','Remove highlighted Exp. from list','fontunits','pixels','fontsize',ftsz);
hlistexptxt=uicontrol('Style','text','Units','Normalized','pos',[0.08 0.91 0.3 0.08],'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
    'parent',hpanelmain,'String','Experiments','HorizontalAlignment','center','fontunits','pixels',...
    'fontsize',1.1*ftsz,'fontweight','bold','TooltipString','Table of experimental spectra');
hupexp=uicontrol('Style','pushbutton','String',char(94),'Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.46 0.54 0.03 0.08],'parent',hpanelmain,'Callback', {@moveexp,'-'},'enable','off',...
    'TooltipString','Move up highlighted exp.','fontunits','pixels','fontsize',ftsz*1.5);
hdownexp=uicontrol('Style','pushbutton','String',char(86),'Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.46 0.45 0.03 0.08],'parent',hpanelmain,'Callback', {@moveexp,'+'},'enable','off',...
    'TooltipString','Move down highlighted exp.','fontunits','pixels','fontsize',ftsz);

%%% list simul%%%
hlist=uicontrol('Style','listbox','Units','Normalized','pos',[0.50 0.3 0.45 0.6],...
    'parent',hpanelmain,'max',2,'min',0,'enable','off','Callback',@reload,'fontunits','pixels','fontsize',ftsz,...
    'TooltipString','Simulations: select one or more...','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25]);
hsuprfromlist=uicontrol('Style','pushbutton','String','X','Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.95 0.81 0.03 0.08],'parent',hpanelmain,'Callback', @suprfromlist,'enable','off',...
    'TooltipString','Remove highlighted simul. from list','fontunits','pixels','fontsize',ftsz);
hexpfromlist=uicontrol('Style','pushbutton','String',char(62),'Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.95 0.73 0.03 0.08],'parent',hpanelmain,'Callback', @expfromlist,'enable','off',...
    'TooltipString',sprintf('Export highlighted simul. in .txt with parameters in .par.\nIf displaid, exp. spec is included.'),'fontunits','pixels','fontsize',ftsz);
hlisttxt=uicontrol('Style','text','Units','Normalized','pos',[0.57 0.91 0.3 0.08],...
    'parent',hpanelmain,'String','Saved Simulations','HorizontalAlignment','center','fontunits','pixels',...
    'fontsize',1.1*ftsz,'fontweight','bold','TooltipString','Table of saved simulations','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25]);
hupsim=uicontrol('Style','pushbutton','String',char(94),'Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.95 0.54 0.03 0.08],'parent',hpanelmain,'Callback', {@movesim,'-'},'enable','off',...
    'TooltipString','Move up highlighted simul.','fontunits','pixels','fontsize',ftsz*1.5);
hdownsim=uicontrol('Style','pushbutton','String',char(86),'Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.95 0.45 0.03 0.08],'parent',hpanelmain,'Callback', {@movesim,'+'},'enable','off',...
    'TooltipString','Move down highlighted simul.','fontunits','pixels','fontsize',ftsz);

%%% graphes %%%
hspecaxes=axes('parent',hSimultispinmain,'OuterPosition',[0 0.25 1 0.75],'Position',[0.05 0.30 0.9 0.65],...
               'Ytick',NaN,'Box','on','Xtick',NaN,'ButtonDownFcn',@MouseleftclickaxeCllbck, 'Xcolor',[0.9 0.9 0.9],'color',[0.7 0.7 0.7]);
hold all
xlabel(hspecaxes,'Magnetic Field [mT]','color',[0.9 0.9 0.9]); 

hsuprexp=uicontrol('Style','pushbutton','String','X','Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.96 0.93 0.03 0.02],'parent',hSimultispinmain,'Callback', @suprexp,'enable','off',...
    'TooltipString','Remove experimental spectrum','fontunits','pixels','fontsize',ftsz);

hsuprsimul=uicontrol('Style','pushbutton','String','X','Units','Normalized','HorizontalAlignment','center',...
    'pos',[0.96 0.90 0.03 0.02],'parent',hSimultispinmain,'Callback', @suprsimul,'enable','off',...
    'TooltipString','Remove simulated spectrum','fontunits','pixels','fontsize',ftsz,'ForegroundColor','m');

hsavefig=uicontrol('Style','pushbutton','String','Save fig.','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.01 0.96 0.08 0.03],'parent',hSimultispinmain,'Callback', @savefig,...
            'TooltipString','Save figure in .fig or .bmp with parameters in .par','enable','on');
        
hfs=uicontrol('Style','pushbutton','String','FS','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.10 0.96 0.05 0.03],'parent',hSimultispinmain,'Callback', @cllbckfs,...
            'TooltipString',sprintf('Full scale of\n-exp. (first click)\n-simul. (second click)'),'enable','on');

hresetfreq=uicontrol('Style','pushbutton','String','Reset freq.','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.16 0.96 0.1 0.03],'parent',hSimultispinmain,'Callback', @cllbckresetfreq,...
            'TooltipString',sprintf('Reset Frequency for new simulation'),'enable','on');        
        
hfreq=uicontrol('Style','text','Units','Normalized','pos',[0.3 0.955 0.5 0.02],...[0.43 0.96 0.42 0.02],...
    'parent',hSimultispinmain,'HorizontalAlignment','center',...
    'fontunits','pixels','fontsize',ftsz,'visible','on','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25]);

hexpname=uicontrol('Style','text','Units','Normalized','pos',[0.30 0.98 0.5 0.02],...[0.20 0.96 0.22 0.02]
    'parent',hSimultispinmain,'HorizontalAlignment','center',...
    'fontunits','pixels','fontsize',ftsz,'visible','off','foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25]);

hfitindicator=uicontrol('Style','text','Units','Normalized','pos',[0.82 0.965 0.14 0.02],'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
    'parent',hSimultispinmain,'HorizontalAlignment','center','visible','off',...
    'fontunits','pixels','fontsize',ftsz*1.2,'TooltipString',sprintf('Fit indicator:\nderivative/absorption spectra\n(best fit: fit = 0 / 0)'));

hexpx=uicontrol('Style','pushbutton','String','<x>','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.05 0.26 0.04 0.03],'parent',hSimultispinmain,'Callback', @cllbckexpandx,...
            'TooltipString','Expand x axes (x2)');
hsetB=uicontrol('Style','pushbutton','String','Set','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.005 0.26 0.04 0.03],'parent',hSimultispinmain,'Callback', @cllbcksetB,...
            'TooltipString','Set magnetic field range');        

hexpy=uicontrol('Style','pushbutton','String','<y>','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.005 0.32 0.04 0.03],'parent',hSimultispinmain,'Callback', @cllbckexpandy,...
            'TooltipString','Expand y axes (x2)');

hnormpanel=uibuttongroup(...
        'Parent',hSimultispinmain,...
        'BorderType','line',...'none'
        'BorderWidth',3,...
        'HighlightColor','k',...
        'Title','',...
        'Position',[0.96 0.30 0.032 0.1],...[0.96 0.70 0.03 0.15],...
        'SelectedObject',[],...
        'backgroundcolor',[0.25 0.25 0.25],...
        'SelectionChangeFcn',@normradiocllbck,...
        'OldSelectedObject',[]);        
hnormI = uicontrol(...
        'Parent',hnormpanel,...
        'Style','radiobutton',...
        'Units','normalized',...
        'Position',[0 0.55 0.9 0.4],...[0 0.6 1 0.4],...
        'String','',...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'TooltipString','Normalization to integrated intensity',...
        'backgroundcolor',[0.25 0.25 0.25],...
        'value',0,...
        'Tag','intensity'); 
hnormminmax = uicontrol(...
        'Parent',hnormpanel,...
        'Style','radiobutton',...
        'Units','normalized',...
        'Position',[0 0.05 0.9 0.4],...[0 0.3 1 0.4],...
        'String','',...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString',sprintf('Normalisation to amplitude\nexp.: [max-min]=1\nsim.: [max-min]=Scaling factor'),...
        'value',1,...
        'Tag','minmax');%,... 
    
hscaling=uicontrol('Style','text','Units','Normalized','pos',[0.87 0.255 0.1 0.04],...
    'parent',hSimultispinmain,'String',{'Scaling';'factor'},'HorizontalAlignment','center',...
    'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
    'fontunits','pixels','fontsize',ftsz,'enable','on','TooltipString',sprintf('Scaling factor for simulations\n(normalized with amplitude)'));
hscalingval=uicontrol('Style','edit','Units','Normalized','pos',[0.955 0.26 0.04 0.032],'BackgroundColor','w',...
    'parent',hSimultispinmain,'String',num2str(1,'%3.2f'),'Callback', @defscaling,'fontunits','pixels','fontsize',ftsz,...
    'enable','on','TooltipString',sprintf('Scaling factor for simulations\n(normalized with amplitude)'));     
    
hcomponentletter=uicontrol('Style','text','Units','Normalized','pos',[0.64 0.30 0.3 0.2],...
    'parent',hSimultispinmain,'HorizontalAlignment','right',...
    'fontunits','pixels','fontsize',ftsz*1.3,'visible','off','backgroundcolor',[0.25 0.25 0.25]);

hcursorinfo=uicontrol('Style','text','Units','Normalized','pos',[0.06 0.31 0.25 0.02],...
    'parent',hSimultispinmain,'HorizontalAlignment','center','visible','off',...
    'fontunits','pixels','fontsize',ftsz,'fontweight','bold','backgroundcolor','w');

hdoc=uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.958 0.96 0.035 0.03],'parent',hSimultispinmain,'Callback', @opendoc,...
            'TooltipString',sprintf('Simultispin (V4, june 2020)\nOpen Help doc and mT / MHz scale'));

%handle d'initialisation
% versionyear=version('-date');
% versionyear=str2double(versionyear(end-4:end)); %annee version matlab
versionyear=version('-release');
versionyear=str2double(versionyear(1:4)); %annee version matlab
versionletter=versionyear(end); %lettre version matlab


if versionyear>2018 %a partir de R2018b, outils zoom = axes
   addToolbarExplorationButtons(hSimultispinmain); %comme dans versions anterieures
   hspecaxes.Toolbar = []; % Removes axes toolbar data
end

        %%%% pour ne garder que les outils zoomin, zoomout et main
hToolbar = findall(hSimultispinmain,'tag','FigureToolBar'); %handle toolbar
halltoolbar=allchild(hToolbar); %tous les handles de la toolbar
hzoomin=findall(halltoolbar,'TooltipString','Zoom In');
hzoomout=findall(halltoolbar,'TooltipString','Zoom Out');
hhand=findall(halltoolbar,'TooltipString','Pan');
halltoolbar(halltoolbar==hzoomin)=[];%supprime 1 handle a conserver
halltoolbar(halltoolbar==hzoomout)=[];%supprime 1 handle a conserver
halltoolbar(halltoolbar==hhand)=[];%supprime 1 handle a conserver
set(halltoolbar,'visible','off')

delete(findall(hToolbar,'tag','Plottools.PlottoolsOn'))
delete(findall(hToolbar,'tag','Plottools.PlottoolsOff'))
delete(findall(hToolbar,'tag','DataManager.Linking'))
delete(findall(hToolbar,'tag','Standard.EditPlot'))

%% ================ "variables globales" + initialisations ===============

easyspinfunc=@pepper; %par defaut Frozen Solution
%pos_Simultispinx=[scrszpix(3)-scrszpix(3)/20-800 scrszpix(4)-scrszpix(4)/20-280-scrszpix(4)*0.1*(fignumber-1) 800 280];
kolor= [0 0 1; %1  pour les differentes composantes
        0.3 0.8 0; %2
        1 0.6 0; %3
        0 0.8 1; %4
        0.6 0 0; %5
        0.75 0.75 0; %6
        1 0 0; %7
        0 1 0.5; %8
        0.7 0 1; %9
        0.4 0.4 0.4;%10
        0.8 0.8 0.8];%11
    
poscomponentfig=ones(size(kolor,1),4); %positions des fenetres de component
posy=ones(size(kolor,1));
posx=scrszpix(3)-scrszpix(3)/20-800;
for ind=1:size(poscomponentfig,1) %initialisation
    posy(ind)=scrszpix(4)-scrszpix(4)/20-300-scrszpix(4)*0.25*(ind-1);
    if posy(ind)<0
        posy(ind)=posy(ind-1);
    end
    poscomponentfig(ind,:)=[posx posy(ind) 800 300];
end
    
%busy=0; %si calcul en cours busy=1    
% bornes des sliders g
gmin=-100000;
gmax=200000;
minstepg=66.66/gmax; %facteur d'increment min de g-2
maxstepg=666/gmax; %facteur d'increment max de g-2

% bornes des sliders lw (lorentzian et gaussian) valeur par defaut pour
% Fast Motion
lwmin=0;
lwmax=500;
minsteplw=0.5/lwmax; %facteur d'increment min 
maxsteplw=1/lwmax; %facteur d'increment max 

% menu deroulant pour S
differentS={'1/2';'1';'3/2';'2';'5/2';'3';'7/2'}; %differents spins electroniques possibles

% bornes des sliders A
Amin=0;%MHz
Amax=1000;%MHz
minstepA=0.1/Amax; %facteur d'increment min de A (mT)
maxstepA=1/Amax; %facteur d'increment max de A (mT)

differentI={'';'1/2';'1';'3/2';'2';'5/2';'3';'7/2'}; %different spin nucleaires possibles
differentNucs={'';'1H';'14N';'7Li';'36Cl';'17O';'10B';'59Co'}; %different noyau associes au spins precedents

% bornes des sliders D
Dmin=-5;%MHz
Dmax=5;%MHz
minstepD=0.005/Dmax; %facteur d'increment min de D (MHz)
maxstepD=0.1/Dmax; %facteur d'increment max de D (MHz)

% bornes des sliders E
Emin=-2;%unite?
Emax=2;%unite?
minstepE=0.005/Emax; %facteur d'increment min de E (mT)
maxstepE=0.1/Emax; %facteur d'increment max de E (mT)

%handle d'initialisation
if versionyear>2014
        hinit=gobjects; %handle=structure
elseif versionyear==2014 && strcmp('b',versionletter)
        hinit=gobjects; %handle=structure a partir de 2014b
else
        hinit=NaN; %handle=double
end

%componenth=[]; %structure contenant les handles des fenetres Simultispin_X et des uicontrol associes
componenth = struct('hfig',hinit,... handles d'une figure pour initialisation (1er element du tableau de structure componenth)
    'hname',hinit,'hchk',hinit,'hvisible',hinit,'hhide',hinit,'haniso',hinit,...
    'htextweight',hinit,'heditweight',hinit,'htextpercent',hinit,...
    'heditlorentzian',hinit,'hslidlorentzian',hinit,'heditgaussian',hinit,'hslidgaussian',hinit,...
    'hpopupS',hinit,'hpanelS',hinit,...
    'hpanelg',hinit,'heditg',[hinit hinit hinit],'hslidg',[hinit hinit hinit],'haxialg',hinit,'hmarkerg',[hinit hinit hinit],'hgmoy',hinit,...
    'hpopupI',[hinit hinit],'haxialA',[hinit hinit],'heditA',[hinit hinit hinit;hinit hinit hinit],'hslidA',[hinit hinit hinit;hinit hinit hinit],...
    'hAmoy',[hinit hinit],'hpanelA',[hinit hinit],'hmarkerA',[hinit hinit hinit;hinit hinit hinit],'hAmt',[hinit hinit hinit;hinit hinit hinit],...
    'hpanelHStrain',hinit,'heditHStrain',[hinit hinit hinit],'haxialHStrain',hinit,'hmarkerHStrain',[hinit hinit hinit],...
    'hpanelgStrain',hinit,'heditgStrain',[hinit hinit hinit],'haxialgStrain',hinit,'hmarkergStrain',[hinit hinit hinit],...
    'hpanelAStrain',hinit,'heditAStrain',[hinit hinit hinit],'haxialAStrain',hinit,'hmarkerAStrain',[hinit hinit hinit],...
    'hpanelzfs',hinit,'heditD',hinit,'hslidD',hinit,'heditE',hinit,'hslidE',hinit,'hDMHZ',hinit,'hEMHz',hinit,'hEsurD',hinit,...
    'hpanelDStrain',hinit,'heditDStrain',[hinit hinit],...
    'hplot',hinit);

hpoint=hinit; %initialisation du handle du point clique sur spectre exp
hvert=hinit; %initialisation du handle de ligne verticale passant par point clique
handlesenab4comp=[];% initialisation des handles a rendre enable off pendant le mode comparaison
componentdatainit=struct(... donnees de composante pour initialisation (1er element du tableau de structure componentdata)
    'name','',...
    'color',[NaN NaN NaN],...
    'weightval',1,...
    'anisolw',0,...
    'gaussianval',5,...
    'lorentzianval',0,...    
    'Sval',1/2,...
    'gval',[2 2 2],...
    'axialcombinationg',[NaN NaN],... %si g axial [i j] avec i et j les deux coordonnees egales
    'Istr',{{'1',''}},...
    'Aval',[150 150 150;NaN NaN NaN],...
    'axialcombinationA',[NaN NaN;NaN NaN],... %si A1 axial [i j; NaN NaN] avec i et j les deux coordonnees egales 
    'HStrainval',[0 0 0],...
    'axialcombinationHStrain',[NaN NaN],...
    'gStrainval',[0 0 0],...
    'axialcombinationgStrain',[NaN NaN],...
    'AStrainval',[0 0 0],...
    'axialcombinationAStrain',[NaN NaN],...
    'Dval',0,...
    'Eval',0,...
    'DStrainval',[0 0],...
    'include',1,...
    'status',0,...% 0='hide'  1='visible'
    'specsimul',[],...%simulation de la composante
    'type','Frozen Solution');%type de simulation (la meme pour toutes les composantes!) 'Fast Motion' ou 'Frozen Solution'(defaut)

componentdata=componentdatainit;
Sysinit=struct('S',componentdata.Sval,...
           'g',componentdata.gval,...%initialisation Structure systeme de spin pour simul easyspin / {} car tous les Sys n'ont pas les memes champs
           'weight',1,...
           'lw',[componentdata.gaussianval componentdata.lorentzianval],...
           'A',(componentdata.Aval(1,:)),'Nucs','14N',...      
           'HStrain',componentdata.HStrainval,...
           'gStrain',componentdata.gStrainval,...
           'AStrain',componentdata.AStrainval,...
           'D',[(componentdata.Dval)/0.333E-4 (componentdata.Eval)/0.333E-4],...
           'DStrain',componentdata.DStrainval);
Sys{1}=Sysinit;
Exp=[]; %init structure experimentale pour easyspin
defaultRangeg=[34 1.1]; %g pour  plage de champ par default

bufferdatainit.Syssimul=Sys; %pour mise en tampon de la simul venant d'etre calculee
bufferdatainit.datasimul=componentdata;
bufferdatainit.Exp=Exp;
bufferdata=bufferdatainit;
runsim=false; %aucune simul lancee


reloading=false; %indicateur de recharge de simul.  en train ou non de reafficher une simul selectionee dans la liste
hSimultispincompare=hinit; %handle de la figure contenant la table en mode comparaison de simuls
comparisonmode=false; %pas en mode comparaison (exp ou simul)
posSimultispincompare=[scrszpix(3)/3+350 0 350 scrszpix(4)*0.6];

%differentes possibilites pour A axial
markerstatepossy={'off off off',...  A rhombique (off off off)
                  'on on off',...    A1=A2 et A3 (on on off)
                  'on off on',...    A1=A3 et A2 (on off on)
                  'off on on'};%     A2=A3 et A1 (off on on)
              
              
%loadexpspec=0; %indicateur de spectre experimental charge (si spectre charge, loadspecexp=1)
hspecexp=hinit; %init handle du plot du spectre exp
scalefact=1; %facteur d'affichage de la simul 
% delta=0; %shift pour affichage de la simul (max(simul)=0.5,
% min(simul)=-0.5) (a appliquer aux composantes seules) affiche=calcule*scalefact+delta

hplotsimall=hinit; %handle du plot simul avec toutes les composantes selectionnees
hlegend=hinit; %handle legende
expfreq=NaN; %frequence experimentale
dispsimulfreq=NaN;%frequecomponent 1nce de la simulation affichee

fsfactor=0.05; %full scale factor pour joli affichage (si h=amplitude du spectre, ylim pour fenetre= [min-fsfactor*h max+fsfactor*h]

expspecf=[]; %nom fu fichier exp
path2expspec=[];%chemin du fichier exp
Bexpinit=[]; %champ experimental brut
Bexp=[]; %champ experimental decale
spec=[]; %spectre experimental brut
specexp=[]; %spectre experimental normalise
dispspecsimul=[]; %spectre de simul totale lie a hplotsimall (pour fullscale) (1024 points quand non vide)
Bsimul=[]; %champ de la simul totale (1024 points quand non vide)

hprevsimplot=[]; %handles des plots de simuls precedentes "en mode comparaison"
% specsimul=[];% simulations brutes de chaque composantes
% specsimul_=specsimul;

listfile=[]; % tous les noms de fichiers sauves et/ou charges
listpath=[]; % tous les chemins des fichiers sauves et/ou charges
list2disp=[]; % liste a afficher: '#: fichier'

listfileexp=[]; % tous les noms de fichiers exp charges
listpathexp=[]; % tous les chemins des fichiers exp charges
list2dispexp=[]; % liste a afficher: '#: fichier'


warningstatus=0;% pas de warning affiche
simulfile4esfit=[]; %simulation manuelle utilisee pour lancer esfit
handlesmainenab4esfit=[];%liste des handles enable 'on' sur Simultispin_main avant esfit
%Sysfit=[]; %tableau systeme de spin envoye a esfit
%datafit=[]; % 1 structure regroupant toutes les composantes a envoyer a esfit
componentdatafit=componentdatainit;%composantes, utilisees pour esfit (pour l'info d'axialite)
%Vary=[]; %structure des parametres variables envoyes a esfit
alldata={}; %cell array contenant donnees affichees sur fenetre avant esfit
htable=hinit; %handle de la table de parametres a transferer a esfit
hOK4esfit=hinit; %handle bouton OK de la table de parametres a transferer a esfit
path4function4esfit=path2expspec;
%path4function4esfit=which('bmagn.p');
%path4function4esfit=path4function4esfit(1:end-8);%chemin du dossier easyspin pour placer la function de simul temporaire pour fit
correltab=[]; %table des corelations pour esfit

hmt2mhz=hinit; %handle figure 

path2keep=pwd;%chemin mis en memoire pour prochaines ouvertures ou sauvegardes...

%% ================= FUNCTIONS ============================================

%% Callback functions de Simultispin_main

function closeSimultispin(~,~) %a la fermeture de la fenetre principale Simultispin_main
    allfigname=get(findobj('type','figure'),'name'); %cellarray avec noms des figures ouvertes
    if ~isempty(allfigname)
        if ischar(allfigname) %1! fenetre
         allfigname={allfigname};
        end
        for i=1:numel(allfigname)
            if strncmp(allfigname{i},'Simultispin',11) %compare les 11 premiers caracteres
                delete(findobj('type','figure','name',allfigname{i}));
            end
        end
    end
    clear componenth componentdata Sys;
    
    
   hfigesfit=findobj('type','figure','-and','name','EasySpin Least-Squares Fitting'); 
   if ishandle(hfigesfit)
       close(hfigesfit)
   end 
    %colormap('default') %pour applications futures
end

function chkrealtime(~,~)
    if get(hrealtime,'Value')==1
        if ishandle(hplotsimall)

            warnstatus=testwarning();%teste plage de champs et frequences :1 si warning s'affiche, 0 sinon
            if ~warnstatus
                set (hrunsimul,'enable','off');
                set (hexpx,'enable','off');
                set (hsetB,'enable','off');
                set (hzoomin,'enable','off');
                set (hzoomout,'enable','off');
                set (hhand,'enable','off');
                set (haddcomp,'enable','off');
                set (hsimultype,'enable','off');
                set (hlist,'enable','off');
                set (hupsim,'enable','off');
                set (hdownsim,'enable','off');
                set (hsuprfromlist,'enable','off');
                set (hexpfromlist,'enable','off');
                set (hlistexp,'enable','off');
                set (hsuprfromlistexp,'enable','off');
                set (hupexp,'enable','off');
                set (hdownexp,'enable','off');
                set (hdeltaB1,'enable','off');
                set (hdeltaBslid,'enable','off');
                set (hdeltaBval,'enable','off');
                set (hfs,'enable','off');
                set (hresetfreq,'enable','off');
                set (hsuprsimul,'enable','off');
                set (hsimulmode,'enable','off');
                set(hresidue,'enable','off');
                pan off
                zoom off
            else
                set(hrealtime,'Value',0)
            end
        else
            set(hrealtime,'Value',0)
            uiwait(msgbox({'WARNING:   No global simulation in memory...';'';'You must first perform global simulation with "Run. Simul."...'},...
                 'Simultispin_WARNING','Warn','modal'));
        end
    else
        set (hrunsimul,'enable','on');
        set (hexpx,'enable','on');
        set (hsetB,'enable','on');
        set (hzoomin,'enable','on');
        set (hzoomout,'enable','on');
        set (hhand,'enable','on');
        set (haddcomp,'enable','on');
        set (hsimultype,'enable','on');
        set (hlist,'enable','on');
        set (htempexp,'enable','on');
        set (htemptext,'enable','on');
        set (hsimulmode,'enable','on');
        set (hupsim,'enable','on');
        set (hdownsim,'enable','on');
        set (hsuprfromlist,'enable','on');
        set (hexpfromlist,'enable','on');
        set (hresetfreq,'enable','on');
        set(hresidue,'enable','on');
        
        if numel(get(hlistexp,'string'))>0 %au moins 1 spc exp charge
            set (hlistexp,'enable','on');
            set (hsuprfromlistexp,'enable','on');
            set (hupexp,'enable','on');
            set (hdownexp,'enable','on');
        end
        set (hdeltaB1,'enable','on');
        set (hdeltaBslid,'enable','on');
        set (hdeltaBval,'enable','on');
        set (hfs,'enable','on');
        set(hsuprsimul,'enable','on');
        if ~ishandle(hspecexp)
            set(hresetfreq,'enable','on');
        end

    end
           
end

function loadexpcllbck(~,~)
    [filename,path2exp]=uigetfile(fullfile(path2keep,'*.DSC;*.SPC'),'Select Spectrum to Open','MultiSelect', 'on'); %ouverture boite de dialogue dans repertoire courant (.DSC selectionnes)
    
    if ischar(filename) %1!fichier selectione
         filename={filename};
    end 
    
    if not(isnumeric(filename)) %no cancel;
         for i=1:numel(filename)
                add2listexp(filename{i},path2exp);
         end
          loadexp(filename{end},path2exp);%affichage du dernier

%         set(hlistexp,'value',find(ismember(listfileexp,filename{i})));
        expspecf=filename{1};
        path2expspec=path2exp;
        set(hlistexp,'enable','on');
        set(hsuprfromlistexp,'enable','on');
        set (hupexp,'enable','on');
        set (hdownexp,'enable','on');
        set (hexptool, 'enable','on');
        path2keep=path2exp;

    end
end     

function loadexp(filename,path2exp)
   set(hdeltaB1,'enable','on');
   set(hdeltaBval,'enable','on');
   set(hdeltaBslid,'enable','on');
   set(hsuprexp,'enable','on');

%         if ishandle(hspecexp)
%             delete(hspecexp)
%         end;

    [B,spec,param]=eprload(fullfile(path2exp,filename));
    spec=real(spec); %EMX: enregistrement sous forme complexe
    Bexpinit=B/10; % B en G Bexpinit en mT
    if isfield(param,'MWFQ')
        expfreq=param.MWFQ*1e-9; %frequence exp en GHz from ELEXSYS
    elseif isfield(param,'MF')
        expfreq=param.MF; %en GHz from ESP
    else
        disp('No experimental frequency...')
    end
    
    specexp=mimilrescale(Bexpinit,spec,1);
    expdeltaBf=[filename(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
    if exist([path2exp,expdeltaBf], 'file')
        load([path2exp,expdeltaBf]); %definition de deltaB
    else
        deltaB=0;
    end
    set(hdeltaBval,'string',num2str(deltaB,'%3.2f'))
    set(hdeltaBslid,'value',deltaB);
    plotspecexp(deltaB); %trace spectre exp en tenant compte de deltaB
    fullscale(Bexp,specexp);
    set(hfitindicator,'visible','off');

    set(hexpname,'string',filename,'visible','on');
   
    sep=filesep();% / ou \ selon systeme exploitation
    if strcmp(sep,'\') %windows
        path2disp=strrep(path2exp,sep,[sep,sep]);
    else %linux
        path2disp=path2exp;
    end
    
    set(hexpname,'TooltipString',sprintf(['Experimental spectrum file in\n',path2disp,'\nfrequency = ',num2str(expfreq),'GHz']));
    
    if ishandle(hplotsimall)
        if get(hrealtime,'value')==1
            testwarning();
        end
        dispfitindicator() %affichage de l'indicateur de fit si bonnes plages de champ et bonnes frequences
    end

end

function cllbcktempexp(~,~)
    Temp=str2double(get(htempexp,'string'));
    if isnan(Temp)
       Temp=100;
    end
    set(htempexp,'string',num2str(Temp,'%1.1f'));
end

function cllbckmode(~,~)
    Mode=simulmode{get(hsimulmode,'value')};
end

function defdeltaB(~,~)
    deltaB=str2double(get(hdeltaBval,'string'));
    if isnan(deltaB)
        deltaB=0;
    end
    set(hdeltaBval,'string',num2str(deltaB,'%3.2f'));
    
    set(hdeltaBslid,'value',deltaB);
    plotspecexp(deltaB);
%     if deltaB~=0
%          testwarning4deltaB();
%          set(hfitindicator,'visible','off'); 
%     end
%      if ishandle(hspecexp) && deltaB~=0 %enregistrement du deltaB s'il existe
%          rang2save=get(hlistexp,'value');
%         expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
%         save(fullfile(listpathexp{rang2save},expdeltaBf),'deltaB');
%      end

    rang2save=get(hlistexp,'value');
    expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB ?
    if ~exist(expdeltaBf,'file') %pas de fichier deltaB
       if deltaB~=0
         testwarning4deltaB();
         set(hfitindicator,'visible','off'); 
         rang2save=get(hlistexp,'value');
         expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
         save(fullfile(listpathexp{rang2save},expdeltaBf),'deltaB');
       end 
    else 
         testwarning4deltaB();
         set(hfitindicator,'visible','off'); 
         rang2save=get(hlistexp,'value');
         expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
         save(fullfile(listpathexp{rang2save},expdeltaBf),'deltaB');
    end

end

function sliddeltaB(~,~)
    deltaB=(get(hdeltaBslid,'value'));
    set(hdeltaBval,'string',num2str(deltaB,'%3.2f'));
    plotspecexp(deltaB);
%    testwarning4deltaB();
    set(hfitindicator,'visible','off'); 
%      if ishandle(hspecexp) && deltaB~=0 %enregistrement du deltaB s'il existe
%          rang2save=get(hlistexp,'value');
%         expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
%         save(fullfile(listpathexp{rang2save},expdeltaBf),'deltaB');
%      end
    rang2save=get(hlistexp,'value');
    expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB ?
    if ~exist(expdeltaBf,'file') %pas de fichier deltaB
       if deltaB~=0
         testwarning4deltaB();
         set(hfitindicator,'visible','off'); 
         rang2save=get(hlistexp,'value');
         expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
         save(fullfile(listpathexp{rang2save},expdeltaBf),'deltaB');
       end 
    else 
         testwarning4deltaB();
         set(hfitindicator,'visible','off'); 
         rang2save=get(hlistexp,'value');
         expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
         save(fullfile(listpathexp{rang2save},expdeltaBf),'deltaB');
    end
end

function defscaling(hobject,~)
    scalingfactor=str2double(get(hobject,'string'));
    if isnan(scalingfactor) || scalingfactor==0
        scalingfactor=1;
    end
    set(hobject,'string',num2str(scalingfactor,'%3.2f'));
    if scalingfactor~=1
        set(hobject,'backgroundcolor',[0.98 0.5 0.45]);
    else
        set(hobject,'backgroundcolor','w');
    end
    
    %si une selection dans liste
    rangselected=get(hlist,'value');
    realtimestatus=get(hrealtime,'value');
    
    if ishandle(hspecexp)
         specexp=mimilrescale(Bexp,spec,1);
         set(hspecexp,'ydata',specexp)
    end
    runsimul(hinit)

    cllbckfs %full scale sur sim
    cllbckfs %full scale sur exp
    if ~isempty(rangselected)
        set(hlist,'value',rangselected)
    end
    if realtimestatus==1
        chkrealtime
    end
    
    if ~isempty(rangselected) %si selection dans la liste de simul affichage du chemin dans tooltipstr de freq
        path2sim=listpath{rangselected};
        sep=filesep();% / ou \ selon systeme exploitation
        if strcmp(sep,'\') %windows
             path2disp=strrep(path2sim,sep,[sep,sep]);
        else %linux
             path2disp=path2sim;
        end
        set(hfreq,'TooltipString',sprintf(['Saved simulation file in\n',path2disp]));
    end
end

function loadparam(~,~) %charger parametres sauvegarde en .sms
     [prevparam,path2param]=uigetfile(fullfile(path2keep,'*.sms'),'Select Simulation to Open','MultiSelect', 'on'); %ouverture boite de dialogue dans repertoire courant (.mat selectionnes)
     
     if ischar(prevparam) %1!fichier selectione
         prevparam={prevparam};
     end
     if not(isnumeric(prevparam)) %no cancel;

         prevdata=load(fullfile(path2param,prevparam{end}),'-mat'); %chargement des donnees (prevdata=structure)
         loadanddisp(prevdata); %affichage du dernier
         for i=1:numel(prevparam)
                add2list(prevparam{i},path2param);
         end
         set(hsavesimul,'enable','off'); 
         %set(hlist,'value',find(ismember(listfile,prevparam{i})));
         path2keep=path2param;
         
         sep=filesep();% / ou \ selon systeme exploitation
         if strcmp(sep,'\') %windows
             path2disp=strrep(path2param,sep,[sep,sep]);
         else %linux
             path2disp=path2param;
         end
         set(hfreq,'TooltipString',sprintf(['Saved simulation file in\n',path2disp]));
         if ~ishandle(hspecexp)
            set(hresetfreq,'enable','on'); 
         end
     end
     set(hresidue,'enable','on');
end

function runsimulcllbck(~,~)
   runsimul(hinit) 
end

function normradiocllbck(~,~)
    %si une selection dans liste
    rangselected=get(hlist,'value');
    realtimestatus=get(hrealtime,'value');
    
     switch get(get(hnormpanel,'SelectedObject'),'Tag')
            case 'intensity'
                set([hscaling hscalingval],'enable','off');
             case 'minmax'
                set([hscaling hscalingval],'enable','on');
     end
     set(hscalingval,'String',num2str(1,'%3.2f'),'backgroundcolor','w'); 

    if ishandle(hspecexp)
         specexp=mimilrescale(Bexp,spec,1);
         set(hspecexp,'ydata',specexp)
    end
    
    runsimul(hinit)

    cllbckfs %full scale
    
    if ~isempty(rangselected)
        set(hlist,'value',rangselected)
    end
    if realtimestatus==1
        chkrealtime
    end
end

function runsimul(hobject)
   
     componentnumberincluded=sum([componentdata.include])-1; %nb de composante a inclure dans simul (componentdata(1) = initialisation)
    if componentnumberincluded>=1
        runsim=true;
        numcomp=numel(componenth);
        if ishandle(hpoint) %point, ligne verticale pointillee, infos
            delete(hpoint)
            delete(hvert)
            set(hcursorinfo,'string','','visible','off');
        end
        
        Exp=Expgeneration(); %Expgeneration avant de supprimer simul pour mise en memoire de la frequence
        if ~isnan(Exp.mwFreq) % si cancel "set frequency" (freq=NaN) pas de calcul!
            if ishandle(hplotsimall)
                delete(hplotsimall);
                prevsim=1; %il y avait une simul
            else
                prevsim=0; %il n'y avait pas de simul
            end
            for k=2:numcomp
                if ishandle(componenth(k).hplot)
                        delete(componenth(k).hplot); %suppression des  plot precedents
                end
            end
            %%%%% simul  %%%%%%
           % Exp=Expgeneration()
            specsimul=zeros(componentnumberincluded+1,1024); %par defaut 1024 points dans simul easyspin (specsimul(1,:)=somme )
            i2beincluded=find([componentdata.include]); % pas tenir compte du 1er element de ce tableau = 1 =>componentdata d'initialisation

            if ishandle(hobject)% runsimul appele depuis callback (component forcement included) ie real time! hobject=hinit si appel depuis bouton "run simul"
                hfigtest=[get(hobject,'parent')  get(get(hobject,'parent'),'parent')]; %handle des 1er et 2e parents de l'objet considere
                %hfigttest(2)=get(get(hobject,'parent'),'parent') %handle du 2e parent de l'objet considere
                index= ismember(hfigtest,[componenth.hfig]);
                place=find([componenth.hfig]==hfigtest(index)); %indice considere dans la structure des handles componenth
                for k=2:numel(i2beincluded)
                    specsimul(k,:)=componentdata(i2beincluded(k)).specsimul;%recuperation des simul de composantes prealables
                end
                specsimul(i2beincluded==place,:)=easyspinfunc(Sys{place},Exp); %simul de la composante selectionnee

            else %simul globale (pas real time)
                [Bsimul,specsimul(2,:)]=easyspinfunc(Sys{i2beincluded(2)},Exp); %simul de la premiere composante selectionnee
                if componentnumberincluded>=2 %simul des composantes selectionnees suivantes
                for k=3:componentnumberincluded+1
                  specsimul(k,:)=easyspinfunc(Sys{i2beincluded(k)},Exp); %simul avec composantes selectionnees
                end
                end
            end

            specsimul(1,:)=sum(specsimul(2:componentnumberincluded+1,:),1);
            specsimul_=specsimul;


            [specsimul_(1,:),scalefact]=mimilrescale(Bsimul,specsimul(1,:),str2double(get(hscalingval,'string'))); %recalage de la somme
            %specsimul_(2:componentnumberincluded+1,:)=scalefact*specsimul(k,:);
            for k=2:componentnumberincluded+1 %recalage des composantes
               specsimul_(k,:)=scalefact*specsimul(k,:);%+delta;
            end

            hplotsimall=plot(hspecaxes,Bsimul,specsimul_(1,:),'m','linewidth',1);hold(hspecaxes,'on');
            set(hplotsimall, 'ButtonDownFcn',@MouseleftclicksimCllbck);
            dispspecsimul=specsimul_(1,:); %spectre total affiche
            dispsimulfreq=Exp.mwFreq;
            for k=2:componentnumberincluded+1
                if componentdata(i2beincluded(k)).status==1
                    visibility='on';
                else
                    visibility='off';
                end
                componenth(i2beincluded(k)).hplot=plot(hspecaxes,Bsimul,specsimul_(k,:),'color',componentdata(i2beincluded(k)).color,'visible',visibility);
                componentdata(i2beincluded(k)).specsimul=specsimul(k,:);
            end   
             setlegend(); %remplace la legende existante
            if ishandle(hspecexp)
                uistack(hspecexp,'top'); %spectre exp au 1er plan
                dispfitindicator(); %affiche indicateur de fit
            else
                 set(hspecaxes,'Ytick',NaN,'XTickMode','auto');
                 xlabel(hspecaxes,'Magnetic Field [mT]');
                 if prevsim==0
                     if ~isnan(max(dispspecsimul))
                    fullscale(Bsimul,dispspecsimul);
                     end
                 end
            end

            set(hsavesimul,'enable','on'); %sauver param simul = possible
            set(hlist,'value',[]); %pas de selection dans la listbox
            set(hfreq,'TooltipString','');
            set(hresidue,'enable','off');
           %mise en tampon de la simul qui vient d'etre calculee
            Sys2buffer=cell(1,numcomp);
            for k=2:numcomp
                Sys2buffer{k-1}=Sys{k};
            end
            bufferdata=bufferdatainit; %reinitialistaion du buffer
            bufferdata.Syssimul=Sys2buffer;
            bufferdata.datasimul=componentdata(2:end);
            bufferdata.Exp=Exp;
            [bufferdata.status]=deal(0); %[]:considere tous les champs status comme un vecteur
            %[bufferdata.include]=deal(1); %deal: distribution sur tous les elements du vecteur

    %         dispsimulfreq=Exp.mwFreq;
            set(hcurrentsimul,'enable','off'); %buffer enable off
            if get(hrealtime,'value')==0
                set(hsuprsimul,'enable','on');
            end
        end
    end
%toc
end

function runsimul2(hobject) %run simul si modification des include en real time
     place=find([componenth.hchk]==hobject); %indice considere dans la structure des handles componenth
     componentnumberincluded=sum([componentdata.include])-1; %nb de composante a inclure dans simul (componentdata(1) = initialisation)
     numcomp=numel(componenth);
     if ishandle(hplotsimall)
        delete(hplotsimall);
        hplotsimall=hinit;
        prevsim=1; %il y avait une simul
     else
        prevsim=0; %il n'y avait pas de simul
     end
     for k=2:numcomp
        if ishandle(componenth(k).hplot)
            delete(componenth(k).hplot); %suppression des  plot precedents
            componenth(k).hplot=hinit;
        end
     end
     %componentdata(5)
     
     if componentnumberincluded>=1
         if ishandle(hpoint) %point, ligne verticale pointillee, infos
            delete(hpoint)
            delete(hvert)
            set(hcursorinfo,'string','','visible','off');
         end
        
        %%%%% nouvelle simul  %%%%%%
        specsimul=zeros(componentnumberincluded+1,1024); %par defaut 1024 points dans simul easyspin (specsimul(1,:)=somme )
        i2beincluded=find([componentdata.include]); % pas tenir compte du 1er element de ce tableau = 1 =>componentdata d'initialisation
        for k=2:numel(i2beincluded)
            if k==place
                specsimul(k,:)=easyspinfunc(Sys{i2beincluded(k)},Exp);
            else
                specsimul(k,:)=componentdata(i2beincluded(k)).specsimul;%recuperation des simul de composantes inclues
            end
        end
        
        
        specsimul(1,:)=sum(specsimul(2:componentnumberincluded+1,:),1);
        specsimul_=specsimul;
        [specsimul_(1,:),scalefact]=mimilrescale(Bsimul,specsimul(1,:),str2double(get(hscalingval,'string'))); %recalage de la somme
        %specsimul_(2:componentnumberincluded+1,:)=scalefact*specsimul(k,:);
        for k=2:componentnumberincluded+1 %recalage des composantes
           specsimul_(k,:)=scalefact*specsimul(k,:);%+delta;
        end
        
        hplotsimall=plot(hspecaxes,Bsimul,specsimul_(1,:),'m','linewidth',1);hold(hspecaxes,'on');
        set(hplotsimall, 'ButtonDownFcn',@MouseleftclicksimCllbck);
        dispspecsimul=specsimul_(1,:); %spectre total affiche
        dispsimulfreq=Exp.mwFreq;
        for k=2:componentnumberincluded+1
            if componentdata(i2beincluded(k)).status==1
                visibility='on';
            else
                visibility='off';
            end
            componenth(i2beincluded(k)).hplot=plot(hspecaxes,Bsimul,specsimul_(k,:),'color',componentdata(i2beincluded(k)).color,'visible',visibility);
            componentdata(i2beincluded(k)).specsimul=specsimul(k,:);
        end   
         setlegend(); %remplace la legende existante
        if ishandle(hspecexp)
            uistack(hspecexp,'top'); %spectre exp au 1er plan
            dispfitindicator(); %affiche indicateur de fit
        else
             set(hspecaxes,'Ytick',NaN,'XTickMode','auto');
             xlabel(hspecaxes,'Magnetic Field [mT]');
             if prevsim==0
                fullscale(Bsimul,dispspecsimul);
             end
        end

        set(hsavesimul,'enable','on'); %sauver param simul = possible
        set(hlist,'value',[]); %pas de selection dans la listbox
        set(hfreq,'TooltipString','');
       %mise en tampon de la simul qui vient d'etre calculee
        Sys2buffer=cell(1,numcomp);
        for k=2:numcomp
            Sys2buffer{k-1}=Sys{k};
        end
        bufferdata=bufferdatainit; %reinitialistaion du buffer
        bufferdata.Syssimul=Sys2buffer;
        bufferdata.datasimul=componentdata(2:end);
        bufferdata.Exp=Exp;
        [bufferdata.status]=deal(0); %[]:considere tous les champs status comme un vecteur
        %[bufferdata.include]=deal(1); %deal: distribution sur tous les elements du vecteur
        
%         dispsimulfreq=Exp.mwFreq;
        set(hcurrentsimul,'enable','off'); %buffer enable off
        %set(hsuprsimul,'enable','on');
     end
end

function func4easyspin(hobj,~)
    if ishandle(hplotsimall)
        delete(hplotsimall)
        hplotsimall=hinit;
        set(hfreq,'string','');
        set(hfitindicator,'visible','off'); 
        dispsimulfreq=NaN;
        set(hsuprsimul,'enable','off');
            if ~ishandle(hspecexp)
                set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
            end
    end
    for k=2:numel(componenth)
        if ishandle(componenth(k).hplot)
            delete(componenth(k).hplot)
            componenth(k).hplot=hinit;
            set(componenth(k).hhide,'value',1);
            set(componenth(k).hvisible,'value',0);
            componentdata(k).status=0;
        end
    end
%     if isempty(get(hspecaxes,'children'))%~ishandle(hspecexp)
%                 set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
%     end
    set(hlist,'value',[]);
    set(hfreq,'TooltipString','');
    setlegend()
    
    statuslist=get(hobj,'string');
    statusval=get(hobj,'value');
    status=statuslist{statusval};
    switch status
        case 'Fast Motion'
            easyspinfunc=@garlic;
            [componentdata.type]=deal(status);
            lwmax=5;
            minsteplw=0.01/lwmax; %facteur d'increment min 
            maxsteplw=0.05/lwmax; %facteur d'increment max
            for k=2:numel(componenth)
                if componentdata(k).Sval > 0.5
                  cllbckpopupS(componenth(k).hpopupS)  
                end
                if componentdata(k).anisolw == 1
                    cllbckanisolw(componenth(k).haniso)
                end
            end

        case 'Frozen Solution'
            easyspinfunc=@pepper;
            [componentdata.type]=deal(status);
            lwmax=500;
            minsteplw=0.5/lwmax; %facteur d'increment min 
            maxsteplw=1/lwmax; %facteur d'increment max
    end
    for k=2:numel(componenth)
        set(componenth(k).hslidlorentzian,'Min',lwmin,'Max',lwmax,'SliderStep',[minsteplw maxsteplw]);
        set(componenth(k).hslidgaussian,'Min',lwmin,'Max',lwmax,'SliderStep',[minsteplw maxsteplw]);
    end
        
end

function savesimul(~,~)
     [simf,path2simf]=uiputfile(fullfile(path2keep,'*.sms')); %ouverture boite de dialogue dans repertoire courant (.mat selectionnes)
     if simf~=0
         %[componentdata.include]
         i2beincluded=find([componentdata.include]); % pas tenir compte du 1er element de ce tableau = 1 =>componentdata d'initialisation
        datasimul=componentdata(i2beincluded(2:end));
        [datasimul.status]=deal(0); %[]:considere tous les champs status comme un vecteur
        [datasimul.include]=deal(1); %deal: distribution sur tous les elements du vecteur
        
        %Syssimul=Sys{i2beincluded(2:end)} %<=> a Syssimul={Sys{...}}
        for k=2:numel(i2beincluded) %pas reussi a prendre sous tableau (struct, cell, ...)
            Syssimul{k-1}=Sys{i2beincluded(k)};
        end
        
       %Syssimul 
       
       modesimul=simulmode{get(hsimulmode,'value')};
       Tempsimul=str2double(get(htempexp,'string'));
       
       save([path2simf,simf],'Syssimul','datasimul','Exp','Tempsimul','modesimul')
       
       deltaB=str2double(get(hdeltaBval,'string'));
         
%          if ishandle(hspecexp) && deltaB~=0 %enregistrement du deltaB s'il existe
%              rang2save=get(hlistexp,'value');
%             expdeltaBf=[listfileexp{rang2save}(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
%             save(fullfile(listpathexp{rang2save},expdeltaBf),'deltaB');
%          end
         set(hsavesimul,'enable','off');
         bufferdata=bufferdatainit; %reinitialistaion du buffer
         set(hcurrentsimul,'enable','off');
          if ~get(hrealtime,'value')
             set(hlist,'enable','on');
             set(hsuprfromlist,'enable','on');
             set(hexpfromlist,'enable','on');
             set(hupsim,'enable','on');
             set(hdownsim,'enable','on');
         end
            
         add2list(simf,path2simf);
         path2keep=path2simf;
     end
end

function currentsimul(~,~)
  if ~isequal(bufferdata,bufferdatainit)  
    if ishandle(hSimultispincompare)
        delete(hSimultispincompare)
        hSimultispincompare=hinit;
    end
    if ishandle(hlegend)
        delete(hlegend)
        hlegend=hinit;
    end
    if ishandle(hprevsimplot)
        delete(hprevsimplot);
        hprevsimplot=hinit;
    end
    if ishandle(handlesenab4comp)
        set(handlesenab4comp,'enable','on') % tous les handles mis en 'enable' off en mode comparaison remis dans leur etat initial
    end
    if ishandle(hspecexp)
        uistack(hspecexp,'top'); %spectre exp au 1er plan
        set(hspecexp,'color','k');
    end
    set(hfs,'enable','on');
    handlesenab4comp=[]; %reinitialisation
    
    if get(hrealtime,'value') %en mode real time toutes les composantes sont affichees donc include=1
        sizebuffer=size(bufferdata.datasimul); %nb composante dans buffer
        for k=1:sizebuffer(2)
            bufferdata.datasimul(1,k).include=1;
            set(componenth(k+1).hvisible,'enable','on');
            set(componenth(k+1).hhide,'enable','on');
        end
    end
    
    loadanddisp(bufferdata);
    set(hsavesimul,'enable','on'); %sauver param simul
    set(hlist,'value',[]); %pas de selection dans la listbox
    set(hfreq,'TooltipString','');
    set(hcurrentsimul,'enable','off'); %buffer enable off
  end 
end

function cllbtool(hobj,~)
    toollist=get(hobj,'string');
    toolval=get(hobj,'value');
    status=toollist{toolval};
    switch status
        case '  TOOL MENU'
         set(hexptool, 'Value', 1); 
        case '  > Baseline Correction'
           set(hexptool, 'Value', 1);
           rang2load=get(hlistexp,'value');
           if numel(rang2load)>=2;
               uiwait(msgbox({'WARNING:   Baseline correction tool only for a single selected spectrum'},...
                  'Simultispin_WARNING','Warn','modal'));
           else  expcorr;
           end
        case '  > Double Integration'
           doubleinte;
           set(hexptool, 'Value', 1); 
        case '  > Smoothing'
            set(hexptool, 'Value', 1);
            rang2load=get(hlistexp,'value');
            if numel(rang2load)>=2;
                uiwait(msgbox({'WARNING:   Smoothing tool only for a single selected spectrum'},...
                    'Simultispin_WARNING','Warn','modal'));
            else  smoothcorr;
            end
    end
end

function expcorr(~,~)
    %%% pour enlever la simul du graph et fenetre component
    delete(hplotsimall);
    hplotsimall=hinit;
    hplot2del=[componenth.hplot];
    for k=1:numel(hplot2del)
        if ishandle(hplot2del(k))
            delete(hplot2del(k))
        end
    end
    set(hfreq,'string','');
    set(hfitindicator,'visible','off'); 
    dispsimulfreq=NaN;
    set(hsuprsimul,'enable','off');
    if ~ishandle(hspecexp)
        set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
        expfreq=NaN; %frequence experimentale
    end
   h2close=[componenth.hfig];
    for k=2:numel(h2close)
        close(h2close(k))
    end
    set(hlist,'value',[]);
    set(hfreq,'TooltipString','');
    setlegend();
    set(hrealtime,'value',0);
    chkrealtime()
    
rang2load=get(hlistexp,'value');
path2exp=listpathexp{rang2load};
filename=listfileexp{rang2load};
[B,y]=eprload(fullfile(path2exp,filename)); %chargement du spectre exp
y=real(y); %EMX: enregistrement sous forme complexe   
Bexp=B/10;
disabletool;

%function [ycorr,yfit] = baselinecorr(y,varargin)
% Baseline Fit each column in "x".
% Syntax: [ycorr,yfit] = bf(y,pts,avgpts,method,confirm);  
%   ycorr = bf(y);  ycorr = bf(y,method); ycorr = bf(y,avgpts); 
%   ycorr = bf(y,pts);  ycorr = bf(y,pts,avgpts); 
% A baseline fit is interpolated from selected points and then applied to the data.
%   "y" is a vector or array.
%       If an array, the baseline fit is performed for each column of data (dim 1).
%   Arguments following "y" may be in any order.
%   "pts" is vector specifying the indices of the points for a baseline fit.
%       If not specified then a plot is displayed and the user is instructed to
%       interactively select points for the baseline fit.
%       End points are always automatically included for interactive "pts" selection,
%       and do not need to explicitly selected. It is recommended that the end points
%       be included in any list of "pts".
%       It is not necessary to order or sort "pts" before use.
%   "avgpts" determines the width in points for the calculation of the mean y(x)
%       value, where x is a selected point in "pts". (Default = 3).
%       This can be helpful for noisy data.
%   "method" controls the algorithm applied for the baseline fit. The routine uses
%       Matlab's interp1 command. "method" must be one of the methods supported by
%       interp1. (Default is 'spline').
%   "confirm", if specified as the string 'confirm', will allow the user to see the
%       result and to confirm it is acceptable. If not the user can reslect "pts". 
%   "ycorr" is the baseline corrected data in the same format as "y".
%   "yfit" is a vector or array with the interpolated baseline fit.
%
% Examples:
%   [y,yfit] = bf(y,'confirm','linear');
%       "y" will be plotted and the user is instructed to select points for the fit.
%       A baseline will be linearly interpolated from the selected points and will be
%       plotted together with "y". The user is prompted as to whether to redo the
%       baseline selection. Upon completion, the corrected data "y" and the fitted 
%       baseline "yfit" are output.
%   ycorr = bf(y,5);
%      "y" is plotted and the user is instructed to select points for the fit.
%       The baseline fit is based on the mean value of "y" over 5 points centered on
%       the selected points. Cubic spline interpolation is used for the baseline fit.
%       The corrected data "ycorr" is output.
%   ycorr = bf(y,[5,10,15,30,35,40],'pchip');
%       Points with the specified indices are used to calculate a baseline fit using
%       the piecewise cubic Hermite interpolation method. No data is plotted.
%       The baseline fit is based on the mean value of "y" over 3 points centered on
%       the selected points. The corrected data "ycorr" is output.
%
% See Also:   interp1, spline, ginput

% Copyright 2009 Mirtech, Inc.
% Created by    Mirko Hrovat    08/01/2009  contact:mhrovat@email.com

def_method  = 'spline';
def_avgpts  = 3;
method = [];
avgpts = [];
pts    = [];
confirm = true;

% for n = 2:nargin
%     f = varargin{n-1}
%     if ischar(f)
%         if strcmpi(f,'confirm')
%             confirm = true;
%         else
%             method = f;
%         end
%     elseif isnumeric(f) && numel(f) == 1
%         avgpts = f;
%     elseif isnumeric(f) && numel(f) > 1
%         pts = f;
%     elseif isempty(f)
%         continue
%     else
%         warning('  Invalid input argument!')
%     end
% end

if isempty(method),     method = def_method;        end
if isempty(avgpts),     avgpts = def_avgpts;        end
dimy = size(y);
[maxy, idx] = max(dimy); % pour prendre en compte les colonnes invers�es en .SPC
lst = maxy;
newdimy = [maxy,1];
y = reshape(y,newdimy);
x = 1:lst;
nx=numel(x);
if isempty(pts)
    interactive = true;
else
    interactive = false;
end
ok = false;
while ~ok
    if interactive
        if ishandle(hspecexp)       
        delete(hspecexp)
        end
        expplot=plot(x,real(y(:,1)),'k','linewidth',0.5);
        fitleg=legend('exp.');
        xlabel('points');
        %xlim([1 nx]);
        fullscale([1 nx],[min(y) max(y)]);
        %plot(x,real(y(:,1)))
        %set(bffig,'Name','Baseline Fit - Select points')
        comment=text(50,min(y)/1.2,['Select abscissa points with cursor',char(10),'by mouse button or key press.',char(10),'Press Enter key when done.']);
        [a,b] = ginput;                                %#ok
        pts = round(a.');
    end
    pts = sort(pts);
    pts(diff(pts)==0) = [];         % delete duplicate points
    if pts(1)~=1,       pts = [1,pts];          end     %#ok
    if pts(end)~=lst,   pts = [pts,lst];        end     %#ok
    npts = numel(pts);
    pss = zeros(npts,2);
    pss(:,1) = pts - floor(avgpts/2);
    pss(:,2) = pss(:,1) + avgpts;
    pss(pss < 1) = 1;
    pss(pss > lst) = lst;
    yavg = zeros([npts,newdimy(2)]);
    for n = 1:npts
        yavg(n,:) = mean(y(pss(n,1):pss(n,2),:),1);
    end
    yfit = interp1(pts,yavg,x,method);
    if size(yfit,1) ==1   
        yfit = shiftdim(yfit,1);   % make yfit a column if it is a row vector
    end
    if confirm
        interactive = true;
        %figure(bffig)
        delete(comment);
        lineplot=plot(x,real(y(:,1)),'k',x,real(yfit(:,1)),'r',pts,real(yavg(:,1)),'ob');
        baselineleg=legend([lineplot(1) lineplot(2)],'exp','baseline fit');
        %legend('exp','baseline fit','fit points');
        %set(bffig,'Name','Baseline Fit - Verify baseline')
        answer = questdlg('Is the fit ok?','baseline fit','Yes','Redo','Cancel','Yes');
        if strcmp(answer,'Yes')
        end
        if strcmp(answer,'Redo')
           delete(lineplot);
           delete(expplot);
           delete(baselineleg);
           ok = false;
        else
            ok = true;
            delete(lineplot);
        end
        if strcmp(answer,'Cancel')
           delete(expplot);
           delete(lineplot);
           delete(baselineleg);
           reloadexp;
           enabletool;
           return
        end 
    end
end
ycorr = y - yfit;
ycorr = reshape(ycorr,dimy);
%yfit = reshape(yfit,dimy);
delete(expplot);
delete(lineplot);
delete(baselineleg);

hspecexp=plot(Bexp,y,'k',Bexp,ycorr,'r','linewidth',1);
fullscale(Bexp,[min(y) max(y)]);
xlabel('Magnetic Field [mT]');
correxp=legend('exp.','corr. exp.');
corrquest = questdlg('Save the corrected spectrum?','save corr','Yes','No','Yes');
   switch corrquest
     case 'Yes'
       Exp.mwFreq=expfreq;
       %rang2load=get(hlistexp,'value');
       %expspecf=listfileexp{rang2load};
       %corrspecf=([expspecf(1:end-4),'_corr']); 
       %[B,spec,param]=eprload(corrspecf);
       %loadexp(corrspecf,path2exp);
       [filename,path2exp]=uiputfile(fullfile(path2keep,'*.DSC'));
     if filename==0 % user pressed cancel
       reloadexp;
     else
       oldfolder=cd(path2exp);
       eprsave(filename,Bexp*10,ycorr,'corrspc',Exp.mwFreq);
       loadexp(filename,path2exp);
       add2listexp(filename,path2exp);
       cd(oldfolder)
       end

     case 'No'
       reloadexp;
   end
   enabletool;
end

function doubleinte(~,~)
    rang2load=get(hlistexp,'value');
    if  numel(rang2load)==1       % si un seul spectre exp s�lectionn�
 %%% pour enlever la simul du graph et fenetre component
    delete(hplotsimall);
    hplotsimall=hinit;
    hplot2del=[componenth.hplot];
    for k=1:numel(hplot2del)
        if ishandle(hplot2del(k))
            delete(hplot2del(k))
        end
    end
    set(hfreq,'string','');
    set(hfitindicator,'visible','off'); 
    dispsimulfreq=NaN;
    set(hsuprsimul,'enable','off');
    if ~ishandle(hspecexp)
        set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
        expfreq=NaN; %frequence experimentale
    end
   h2close=[componenth.hfig];
    for k=2:numel(h2close)
        close(h2close(k))
    end
    set(hlist,'value',[]);
    set(hfreq,'TooltipString','');
    setlegend();
    set(hrealtime,'value',0);
    chkrealtime()
    disabletool;
            delete(hspecexp);
            path2exp=listpathexp{rang2load};
            filename=listfileexp{rang2load};
            [B,y]=eprload(fullfile(path2exp,filename)); %chargement du spectre exp
            y=real(y); %EMX: enregistrement sous forme complexe
            Bexp=B/10;
            ymax = max(y);
            ymin = min(y);
            normy=y ./ (ymax-ymin);
            doubleintesingle=plot(hspecaxes,Bexp,normy,'k');
            xlabel('Magnetic Field [mT]');
            fullscale(Bexp,[min(normy) max(normy)]);
            ok = false;
            while ~ok,
            %path2exp=listpathexp{rang2load};
            %filename=listfileexp{rang2load};    
            %[B,y,param]=eprload(fullfile(path2exp,filename)); %chargement du spectre exp
            %y=real(y); %EMX: enregistrement sous forme complexe
            %B=B/10;
                valid = true;
                while valid
                prompt = {'Enter Bmin value (mT):','Enter Bmax value (mT):'};
                dlgtitle = 'Field window selection';
                Bvalue = inputdlg(prompt,dlgtitle);
                if isempty(Bvalue)
                      enabletool;
                      delete(doubleintesingle)
                      reloadexp;
                      return;
                end
                Bmin = str2num(Bvalue{1});
                Bmax = str2num(Bvalue{2});
                if (Bmin > Bmax)
                        uiwait(msgbox({'WARNING:   Bmin must be inferior to Bmax'},...
                        'Simultispin_WARNING','Warn','modal'));
                        valid = true;
                elseif Bmin<min(Bexp) | Bmin>max(Bexp) | Bmax<min(Bexp) | Bmax>max(Bexp)
                        uiwait(msgbox({'WARNING:   Bmin and/or Bmax does not respect the range of B'},...
                        'Simultispin_WARNING','Warn','modal'));
                        valid = true;              
                else break
                end
                end
            plotBmin = plot([Bmin Bmin],[min(normy) max(normy)],'r'); % trace la ligne verticale pour limite int�gration basse
            plotBmax = plot([Bmax Bmax],[min(normy) max(normy)],'r'); % trace la ligne verticale pour limite int�gration haute
            %patchBrange = patch([Bmin Bmax Bmax Bmin],[min(y) min(y) max(y) max(y)],'r','FaceAlpha',0.1,'EdgeAlpha',0); %trace la zone int�gr�e avec transparence
            %uistack(patchBrange, 'bottom'); %mettre la zone en arri�re plan

            [m,Idmin]=min(abs(Bexp-Bmin)); % indice de la case correspondant au plus proche de Bmin
            [n,Idmax] = min(abs(Bexp-Bmax)); % indice de la case correspondant au plus proche de Bmax

            inte = cumtrapz(Bexp(Idmin:Idmax),y(Idmin:Idmax)); % 1�re integration pour revenir au spectre d'absorption
            doubleinte = cumtrapz(Bexp(Idmin:Idmax),abs(inte));

            inteval1 = doubleinte(end);
            normdoubleinte = doubleinte ./ (max(doubleinte-min(doubleinte)));
            %inteval2 = num2str(inteval1,'%3.3e');
            
            doubleplot=plot(Bexp(Idmin:Idmax),normdoubleinte,'r','linewidth',1);
            ylim([-inf 1.1])
            doubleinteleg=legend('exp','double Inte. curve');
            %textval = text(Bexp(Idmax)/1.25,normdoubleinte(end),inteval2);

            doublequestion=questdlg((sprintf('On B = [%g %g] mT, \nDouble integration value = %3.3e', Bmin, Bmax, inteval1)),'Result','Ok', 'Redo','Ok');
                if strcmp(doublequestion,'Ok')
                   ok = true;
                end
                if strcmp(doublequestion,'Redo')
                    ok = false;
                    delete(doubleplot)
                    %delete(textval)
                 else
                        ok = true;
                end
          delete(plotBmin)
          delete(plotBmax)
          delete(doubleplot)
          delete(doubleintesingle)
          delete(doubleinteleg)
          %delete(textval)
%           rang2load=get(hlistexp,'value');
%           loadexp(listfileexp{rang2load},listpathexp{rang2load});
%           expspecf=listfileexp{rang2load};
          reloadexp;
          enabletool;
            end 
           % end
%si plusieurs spectres exp s�lectionn�s      
    elseif numel(rang2load)>=2
            delete(hprevsimplot);
            set(hspecaxes,'XDir','normal');
            set (hsuprsimul, 'enable', 'off');
         nbexp2inte=numel(rang2load); 
           for k=1:nbexp2inte 
                path2exp=listpathexp{rang2load(k)};
                filename=listfileexp{rang2load(k)};
                [B,y]=eprload(fullfile(path2exp,filename)); %chargement du spectre exp
                y=real(y); %EMX: enregistrement sous forme complexe
                B=B/10;
                ymax(k) = max(y);
                ymin(k) = min(y);
                if k>size(kolor,1) %choix de la couleur
                    kstr=num2str(k);
                    kolornumber=str2double(kstr(end));
                else
                    kolornumber=k;
                end
                ymax=max(ymax);
                ymin=min(ymin);
                hprevsimplot(k)=plot(hspecaxes,B,y,'color',kolor(kolornumber,:));
                xlabel('Magnetic Field [mT]');
                fullscale(B,[ymin ymax]);
           end
            setlegend3(rang2load);
            legend('AutoUpdate','off');
                 
         ok = false;
         while ~ok
                valid = true;
                while valid
                    prompt = {'Enter Bmin value (mT):','Enter Bmax value (mT):'};
                    dlgtitle = 'Field window selection';
                    Bvalue = inputdlg(prompt,dlgtitle);
                    if isempty(Bvalue)
                        enabletool;
                        return;
                    end
                    Bmin = str2num(Bvalue{1});
                    Bmax = str2num(Bvalue{2});
                    if (Bmin > Bmax)
                        uiwait(msgbox({'WARNING:   Bmin must be inferior to Bmax'},...
                            'Simultispin_WARNING','Warn','modal'));
                        valid = true;
                    elseif Bmin<min(B) | Bmin>max(B) | Bmax<min(B) | Bmax>max(B)
                        uiwait(msgbox({'WARNING:   Bmin and/or Bmax does not respect the range of B'},...
                            'Simultispin_WARNING','Warn','modal'));
                        valid = true;
                    else break
                    end
                end
         plotBmin = plot([Bmin Bmin],[ymin ymax],'r'); % trace la ligne verticale pour limite int�gration basse
         plotBmax = plot([Bmax Bmax],[ymin ymax],'r'); % trace la ligne verticale pour limite int�gration haute
         patchBrange = patch([Bmin Bmax Bmax Bmin],[ymin ymin ymax ymax],'r','FaceAlpha',0.1,'EdgeAlpha',0); %trace la zone int�gr�e avec transparence
         uistack(patchBrange, 'bottom'); %mettre la zone en arri�re plan
         str='';
             for k=1:nbexp2inte 
                path2exp=listpathexp{rang2load(k)};
                filename=listfileexp{rang2load(k)}(1:end-4);
                [B,y]=eprload(fullfile(path2exp,filename));
                %nb(k)=k;
                Bexp = B/10;
                y=real(y);

                [m,Idmin]=min(abs(Bexp-Bmin)); % indice de la case correspondant au plus proche de Bmin
                [n,Idmax] = min(abs(Bexp-Bmax)); % indice de la case correspondant au plus proche de Bmax
                
                inte = cumtrapz(Bexp(Idmin:Idmax),y(Idmin:Idmax)); % 1�re integration pour revenir au spectre d'absorption
                doubleinte = cumtrapz(Bexp(Idmin:Idmax),abs(inte));

                inteval1(k) = doubleinte(end);
                str=sprintf('%s#%d %s = %3.3e\n',str, k, filename, inteval1(k));
                x(k)=k;
                %filename(k)={filename};
             end

         figinte = figure;
         movegui(figinte,'northeast');
         inteplot = plot(x,inteval1,'-x');
         xlabel('spectrum index');
         xticks(0:1:k);
         ylabel('Double integration [a.u.]');
         
        doublequestion=questdlg(sprintf('On B = [%g %g] mT, double Integration values are:\n%s', Bmin, Bmax, str), 'Result', 'Save', 'Redo', 'Quit','Save');
             if strcmp(doublequestion,'Save')
                 ok = true;
                [figname, path2fig] = uiputfile({'*.bmp';'*.tif';'*.jpeg';'*.eps';'*.fig'});
                if figname==0 % user pressed cancel
                    rang2load=get(hlistexp,'value');
%                     loadexp(listfileexp{rang2load},listpathexp{rang2load});
%                     expspecf=listfileexp{rang2load};
                else
                    saveas(figinte,fullfile(path2fig,figname));
                    txtname = sprintf('%s.txt',figname(1:end-4)); %m�me nom que la figure sans l'extension
                    txtfile = fullfile(path2fig, txtname); %cr�ation du fichier txt
                    fid=fopen(txtfile,'w');
                    %fprintf(fid,'%12s\t','Index');
                    %fprintf(fid,'%12s\t','File name');
                    %fprintf(fid,'%12s\n','Double inte. value');
                    fprintf(fid, '%s\n', str);
                    fclose(fid);
                end
                end
            if strcmp(doublequestion,'Redo')
                    ok = false;
                    delete(figinte);
                    delete(plotBmin);
                    delete(plotBmax);
                    delete(patchBrange);
                 else
                    ok = true;
                 end
             if strcmp(doublequestion,'Quit')
                 end
                 %rang2load=get(hlistexp,'value');
         end 
    delete(figinte);
    delete(plotBmin);
    delete(plotBmax);
    delete(patchBrange);
    reloadexp;            
    end
end

function smoothcorr
     %%% pour enlever la simul du graph et fenetre component
    delete(hplotsimall);
    hplotsimall=hinit;
    hplot2del=[componenth.hplot];
    for k=1:numel(hplot2del)
        if ishandle(hplot2del(k))
            delete(hplot2del(k))
        end
    end
    set(hfreq,'string','');
    set(hfitindicator,'visible','off'); 
    dispsimulfreq=NaN;
    set(hsuprsimul,'enable','off');
    if ~ishandle(hspecexp)
        set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
        expfreq=NaN; %frequence experimentale
    end
   h2close=[componenth.hfig];
    for k=2:numel(h2close)
        close(h2close(k))
    end
    set(hlist,'value',[]);
    set(hfreq,'TooltipString','');
    setlegend();
    set(hrealtime,'value',0);
    chkrealtime()
    disabletool;
delete(hspecexp)
rang2load=get(hlistexp,'value');
path2exp=listpathexp{rang2load};
filename=listfileexp{rang2load};
[B,y]=eprload(fullfile(path2exp,filename)); %chargement du spectre exp
y=real(y); %EMX: enregistrement sous forme complexe   
Bexp=B/10;
ymax = max(y);
ymin = min(y);
normy=y ./ (ymax-ymin);
smoothexp=plot(Bexp,normy,'k');
xlabel('Magnetic Field [mT]');
fullscale(Bexp,[min(normy) max(normy)]);
    ok = false;
    while ~ok
        legexp=legend('exp.');
        smoothquestion=questdlg(sprintf('Select the smoothing function:'),'Smoothing function','Moving average', 'Savitsky-Golay','Cancel','Moving average');
                if strcmp(smoothquestion,'Moving average')
                   prompt = {'Enter the span:'};
                   dlgtitle = 'Moving average smoothing';
                   span = inputdlg(prompt,dlgtitle);
                   if isempty(span)
                        delete(smoothexp);
                        enabletool;
                        reloadexp;
                        return;
                    end
                   spanval = str2num(span{1});
                   smoothy = smoothdata(y,'movmean',spanval);
                   normsmoothy=smoothy ./ (max(smoothy)-(min(smoothy)));
                   smoothplot=plot(Bexp,normsmoothy,'r','linewidth',1);
                   fullscale(Bexp,[min(normy) max(normy)]);
                   smoothleg=legend('exp.','smoothed exp.');
                end
                if strcmp(smoothquestion,'Savitsky-Golay')
                    ok = true;
                    while ok
                    prompt = {'Enter the span:','Enter the degree (< span value):'};
                    dlgtitle = 'Savitsky-Golay smoothing';
                    value = inputdlg(prompt,dlgtitle);
                    if isempty(value)
                        delete(smoothexp);
                        enabletool;
                        reloadexp;
                        return
                    end
                    spanval = str2num(value{1});
                    degval = str2num(value{2});
                    if spanval <= degval
                        uiwait(msgbox({'WARNING:   Degree value must be inferior to span value'},...
                        'Simultispin_WARNING','Warn','modal'));
                        ok = true;
                    else    break
                    end
                    end
                    smoothy = smoothdata(y,'sgolay',spanval,'degree',degval);
                    normsmoothy=smoothy ./ (max(smoothy)-(min(smoothy)));
                    smoothplot=plot(Bexp,normsmoothy,'r','linewidth',1);
                    fullscale(Bexp,[min(normy) max(normy)]);
                    smoothleg=legend('exp.','smoothed exp.');
                end
                 if strcmp(smoothquestion,'Cancel')  
                    delete(smoothexp);
                    enabletool;
                    reloadexp;
                    return;
                 end
        
         corrquest = questdlg('Save the smoothed spectrum?','save smooth','Save','Redo','Quit','Save');
         if strcmp(corrquest,'Save')
             ok = true;
             Exp.mwFreq=expfreq;
             [filename,path2exp]=uiputfile(fullfile(path2keep,'*.DSC'));
             if filename==0 % user pressed cancel
                 rang2load=get(hlistexp,'value');
                 loadexp(listfileexp{rang2load},listpathexp{rang2load});
                 expspecf=listfileexp{rang2load};
             else
                 oldfolder=cd(path2exp);
                 eprsave(filename,Bexp*10,smoothy,'smoothspc',Exp.mwFreq);
                 loadexp(filename,path2exp);
                 add2listexp(filename,path2exp);
                 cd(oldfolder)
             end
         end
         if strcmp(corrquest,'Redo')
             ok = false;
             delete(smoothplot);
             delete(smoothleg);
         else
             ok = true;
         end
         if strcmp(corrquest,'Quit')
         end    
    end
         delete(smoothplot);
         delete(smoothexp);
         delete(smoothleg);
         reloadexp;
         
         enabletool;  
end

function cllbckresidue(~,~)
    
if get(hresidue,'Value')==1
     if isempty(specexp)
         uiwait(msgbox({'WARNING:   No experimental spectrum selected'},...
                  'Simultispin_WARNING','Warn','modal'));
        set(hresidue,'Value',0);
     else  
        set (hresetfreq,'enable','off');
        set (hrunsimul,'enable','off');
        set (haddcomp,'enable','off');
        set (hsimultype,'enable','off');
        set (hlist,'enable','off');
        set (htempexp,'enable','off');
        set (htemptext,'enable','off');
        set (hsimulmode,'enable','off');
        set (hupsim,'enable','off');
        set (hdownsim,'enable','off');
        set (hsuprfromlist,'enable','off');
        set (hexpfromlist,'enable','off');
        set (hlistexp,'enable','off');
        set (hsuprfromlistexp,'enable','off');
        set (hupexp,'enable','off');
        set (hdownexp,'enable','off');
        set (hdeltaB1,'enable','off');
        set (hdeltaBslid,'enable','off');
        set (hdeltaBval,'enable','off');
        set(hrealtime,'enable','off');
        set (hsuprexp, 'enable', 'off');
        set (hsuprsimul, 'enable', 'off');
        set (hdefaultpar, 'enable', 'off');
        set (hloadexp, 'enable', 'off');
        set (hloadsim, 'enable', 'off');
        set (hesfit,'enable','off');
        set(hexptool,'enable','off');
    rang2load=get(hlist,'value'); 
    prevdata=load(fullfile(listpath{rang2load},listfile{rang2load}),'-mat');
    nbcomponent=numel(prevdata.datasimul);
        for k=1:nbcomponent
            compsimul(k,:)=prevdata.datasimul(k).specsimul;
        end
        y=sum(compsimul,1);% somme des simul de composantes       
        B=linspace(prevdata.Exp.Range(1),prevdata.Exp.Range(2),numel(y)); %champ magnetique de la simul
        y=mimilrescale(B,y,1);
        ysim=(y)';
        specx = (interp1(Bexp,specexp,B,'spline',0))'; % pour avoir le spectre exp en 1024 pts comme la simu         
        yres = specx - ysim;
        delete(hspecexp)
        delete(hplotsimall)
        residueplot = plot(hspecaxes,B,specx,'--k', B, ysim, '--m',B, yres,'g');
        %SSresidue = sum(yres.^2);
        %SStotal = (length(specx)-1) * var(specx);
        %RSQ = 1 - (SSresidue/SStotal); % coefficient of determination
        %Rratio=sprintf('[exp-sim] R^2 = %3.2f',RSQ);
        legend('exp','sim','[exp-sim]')
     end
else
       set(hrealtime,'Value',0)
       delete(findobj(gca, 'type', 'line'))
       delete(findobj(gca, 'type', 'text'))
       delete(legend)
       reload;
       reloadexp;
               set (hexpx,'enable','on');
        set (hsetB,'enable','on');
        set (hzoomin,'enable','on');
        set (hzoomout,'enable','on');
        set (hhand,'enable','on');
        set (hrunsimul,'enable','on');
        set (haddcomp,'enable','on');
        set (hsimultype,'enable','on');
        set (hlist,'enable','on');
        set (htempexp,'enable','on');
        set (htemptext,'enable','on');
        set (hsimulmode,'enable','on');
        set (hupsim,'enable','on');
        set (hdownsim,'enable','on');
        set (hsuprfromlist,'enable','on');
        set (hexpfromlist,'enable','on');
        set (hlistexp,'enable','on');
        set (hsuprfromlistexp,'enable','on');
        set (hupexp,'enable','on');
        set (hdownexp,'enable','on');
        set(hrealtime,'enable','on');
        set (hsuprexp, 'enable', 'on');
        set (hsuprsimul, 'enable', 'on');
        set (hdefaultpar, 'enable', 'on');
        set (hloadexp, 'enable', 'on');
        set (hloadsim, 'enable', 'on');
        set (hesfit,'enable','on');
        set(hexptool,'enable','on');
end
end

function reloadexp(~,~)
    rang2load=get(hlistexp,'value');
%if ~isempty(rang2load) %si clic 2 fois sur meme exp
%     if numel(rang2load)>1
%        rang2loadeff=rang2load(1);
%        set(hlistexp,'value',rang2loadeff);
%     else
%         rang2loadeff=rang2load;
%     end
    if ishandle(hprevsimplot)
       delete(hprevsimplot);
       hprevsimplot=hinit;
    end
    if ishandle(hspecexp)
       delete(hspecexp);
       hspecexp=hinit;
    end
if ~isempty(rang2load) %si clic 2 fois sur meme exp
    if numel(rang2load)==1 %si 1! simul sauvee a charger 
        comparisonmode=false; %pas en mode comparaison
%     loadexp(listfileexp{rang2loadeff},listpathexp{rang2loadeff});
        loadexp(listfileexp{rang2load},listpathexp{rang2load});
        expspecf=listfileexp{rang2load};
        set(hspecaxes,'XDir','normal');
        set(hfitindicator,'visible','off');
        if ishandle(hplotsimall)
            dispfitindicator;
        end
        if ishandle(handlesenab4comp)
            set(handlesenab4comp,'enable','on') % tous les handles mis en 'enable' off en mode comparaison remis dans leur etat initial
        end
        handlesenab4comp=[]; %reinitialisation
    
    else %si plusieurs exp a comparer
        comparisonmode=true; %en mode comparaison
             if numel(rang2load)>=2 
                 set(hfreq,'string','');
                 set(hexpname,'string','');
                if isempty(handlesenab4comp)
                 handlesenab4comp=findobj(hpanelmain,'-property','enable','-and','enable','on'); %tous les handles du panel hpanelmain avec propriete 'enable' on 
                 handlesenab4comp(handlesenab4comp==hlistexp)=[];%supprimer le handle de la liste des handles a rendre enable off
                 handlesenab4comp=[handlesenab4comp;hnormI;hnormminmax;hscaling;hscalingval;hfs;hsuprexp;hsetB]; %choix de normalisation desactive
                 set(handlesenab4comp,'enable','off') % tous les handles 'enable' off => pas d'action possible en mode comparaison
                 set(hexptool,'enable','on')
                end
             end
             oldhfig=[componenth.hfig];
             if ~isempty(oldhfig) %si fenetres de composantes affichees, les effacer
                 for k=2:numel(oldhfig)
                closeSimultispinX(oldhfig(k));
                 end
             end

             nbexp2compare=numel(rang2load);
             for k=1:nbexp2compare
                %%% chargement des donnees
                path2exp=listpathexp{rang2load(k)};
                filename=listfileexp{rang2load(k)};
                [B,y,param]=eprload(fullfile(path2exp,filename)); %chargement du spectre exp
                y=real(y); %EMX: enregistrement sous forme complexe
                if isfield(param,'MWFQ')
                     freq=param.MWFQ*1e-9; %frequence exp en GHz from ELEXSYS
                     B=B/10; %en mT
                elseif isfield(param,'MF')
                     freq=param.MF; %en GHz from ESP
                     B=B/10; %en mT
                elseif isfield(param,'Measurement_MwFreq')
                     freq=param.Measurement_MwFreq; %en GHz from Magnettech
                else
                     freq=NaN;
                end
                expdeltaBf=[filename(1:end-3),'mat']; %fichier contenant le deltaB s'il existe
                if exist(fullfile(path2exp,expdeltaBf), 'file')
                    load(fullfile(path2exp,expdeltaBf)); %definition de deltaB
                else
                    deltaB=0;
                end
                B=B+deltaB;%en mT
                g{k,:}=planck*freq*1e9/bmagn./B*1e3;
                ming(k)=min([g{k,:}]);
                maxg(k)=max([g{k,:}]);
                
                y_{k,:}=mimilrescale(B,y,1);
                miny_(k)=min([y_{k,:}]);
                maxy_(k)=max([y_{k,:}]);
                
                if k>size(kolor,1) %choix de la couleur
                    kstr=num2str(k);
                    kolornumber=str2double(kstr(end));
                else
                    kolornumber=k;
                end
                hprevsimplot(k)=plot(hspecaxes,g{k,:},y_{k,:},'color',kolor(kolornumber,:));
                hold(hspecaxes,'on');

             end

             set(hspecaxes,'Ytick',NaN,'XTickMode','auto','XDir','reverse',...
                 'xlim',[min(ming) max(maxg)],'ylim',1.05*[min(miny_) max(maxy_)]);
             xlabel(hspecaxes,'g value');

             setlegend3(rang2load);

    end
    set(hlistexp,'value',rang2load);%laisse la selection apparente
end
end
    
function reload(~,~) 
    reloading=true;
        if ishandle(hSimultispincompare)
            closefigcompare()
        end
         rang2load=get(hlist,'value');
         set(hfitindicator,'visible','off');
          if ishandle(hprevsimplot)
             delete(hprevsimplot);
             hprevsimplot=hinit;
          end
          
  %   if ~isempty(rang2load) %si clic 2 fois sur meme sim  
         if numel(rang2load)==1 %si 1! simul sauvee a charger 
            comparisonmode=false; %pas en mode comparaison
             %set(hfs,'enable','on');
             if ishandle(hspecexp)
                uistack(hspecexp,'top'); %spectre exp au 1er plan
                set(hspecexp,'color','k');
                %fullscale(Bexp,specexp);
             end
            prevdata=load(fullfile(listpath{rang2load},listfile{rang2load}),'-mat'); %chargement des donnees (prevdata=structure)
            
            if ~isempty(handlesenab4comp) %ishandle
                set(handlesenab4comp,'enable','on') % tous les handles mis en 'enable' off en mode comparaison remis dans leur etat initial
            end
            handlesenab4comp=[]; %reinitialisation
            loadanddisp(prevdata);
            
            sep=filesep();% / ou \ selon systeme exploitation
            if strcmp(sep,'\') %windows
                path2disp=strrep(listpath{rang2load},sep,[sep,sep]);
            else %linux
                path2disp=listpath{rang2load};
            end
            set(hfreq,'TooltipString',sprintf(['Saved simulation file in\n',path2disp]));
            set(hresidue,'enable','on'); 
            
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %si plusieurs simul sauvees a comparer
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

         elseif ~isempty(rang2load) %si clic 2 fois sur meme sim  
            comparisonmode=true; %en mode comparaison             
             %%%%%% table %%%%%
             hSimultispincompare=figure();
             set(hSimultispincompare,'Units','pixels','outerposition',posSimultispincompare,...
                 'Name','Simultispin_compare sim.','Menubar','none', 'Toolbar', 'none',...
                 'NumberTitle','off','color',[0.25 0.25 0.25],...
                 'CloseRequestFcn',@closefigcompare);
             htablecompare=uitable(hSimultispincompare,'Units','normalized','Position',[0.01 0.01 0.98 0.98]);
             
             %%%%%% plot %%%%%
             set(hfreq,'string','');
             %set(hfs,'enable','off');
             if numel(rang2load)>=2 
                if isempty(handlesenab4comp)
                 handlesenab4comp=findobj(hpanelmain,'-property','enable','-and','enable','on'); %tous les handles du panel hpanelmain avec propriete 'enable' on 
                 handlesenab4comp(handlesenab4comp==hlist)=[];%supprimer le handle de la liste des handles a rendre enable off
                 set(handlesenab4comp,'enable','off') % tous les handles 'enable' off => pas d'action possible en mode comparaison
                end
             end
             %set(hfs,'enable','off');
             %sortie du mode real time
             if get(hrealtime,'Value')==1
                 set(hrealtime,'Value',0);
                 chkrealtime();
             end
    
             
             oldhfig=[componenth.hfig];
             if ~isempty(oldhfig) %si fenetres de composantes affichees, les effacer
                 for k=2:numel(oldhfig)
                closeSimultispinX(oldhfig(k));
                 end
             end

             nbsim2compare=numel(rang2load);
             datasimul2disp=cell(nbsim2compare,1);%init tableau des datasimul a afficher dans table de comparaison
             nbcomp2compare=ones(nbsim2compare,1);%init du nb de composantes/simul

             for k=1:nbsim2compare
                %%% chargement des donnees
                prevdata=load(fullfile(listpath{rang2load(k)},listfile{rang2load(k)}),'-mat'); %chargement d'une structure sinon conflit de noms
                [B,y]=prevsimul(prevdata);
                datasimul2disp{k}=update_simuldata(prevdata.datasimul);%Si simul sauvee avec version precedente de SimLabel=> ajouter des champs...
                nbcomp2compare(k)=numel(datasimul2disp{k});
               
                if k>size(kolor,1) %choix de la couleur
                    kstr=num2str(k);
                    kolornumber=str2double(kstr(end));
                else
                    kolornumber=k;
                end
                
                hprevsimplot(k)=plot(hspecaxes,B,y,'color',kolor(kolornumber,:));
                hold(hspecaxes,'on');
             end
            set(hspecaxes,'Ytick',NaN,'XTickMode','auto');
            xlabel(hspecaxes,'Magnetic Field [mT]');
            
            if ishandle(hspecexp)
                %uistack(hspecexp,'top'); %spectre exp au 1er plan
                set(hspecexp,'color',[0.8 0.8 0.8]);
                fullscale(Bexp,specexp);
            else
                fullscale(B,y);
            end
            setlegend2(rang2load);
            
            %%% table %%%
            nbcomp2disp=max(nbcomp2compare);
            rownamelistbase={'-','Weight (%)','Gaussian (mT)','Lorentzian (mT)','S','g(1)','g(2)','g(3)','g_iso','I_1',...
                'A_1(1) (MHz)','A_1(2) (MHz)','A_1(3) (MHz)','A_1_iso (MHz)','I_2','A_2(1) (MHz)','A_2(2) (MHz)','A_2(3) (MHz)','A_2_iso (MHz)',...
                'HStrain(1) (MHz)','HStrain(2) (MHz)','HStrain(3) (MHz)','gStrain(1)','gStrain(2)','gStrain(3)','AStrain(1) (MHz)','AStrain(2) (MHz)','AStrain(3) (MHz)','D (cm-1)','E (cm-1)','DStrain(1) (MHz)','DStrain(2) (MHz)'};

            nbparambase=numel(rownamelistbase)+1; %nb de param de base
            rownamelist2disp={}; %nom des lignes
            for k=1:nbcomp2disp
                rownamelist2disp=[rownamelist2disp,['Component ',num2str(k)],rownamelistbase];
            end
            colonneformat={}; %format des colonnes
            colonnelargeur={80}; 
            for k=1:nbsim2compare
                colonneformat=[colonneformat,'char'];
                colonnelargeur=[colonnelargeur,'auto'];
            end            
            simulname2disp=[{''},{listfile{rang2load}}]; %pas d'erreur
            alldata2disp=cell(nbparambase*nbcomp2disp,nbsim2compare+1); %init data de la table 
            for k=1:nbparambase*nbcomp2disp
                alldata2disp{k,1}=rownamelist2disp{k};
            end
            for k=1:nbsim2compare
                for m=1:nbcomp2compare(k)
                    
                    alldata2disp{1+(m-1)*nbparambase,k+1}=datasimul2disp{k}(m).name;
                    if nbcomp2compare(k)>1
                        alldata2disp{2+(m-1)*nbparambase,k+1}=num2str(100*datasimul2disp{k}(m).weightval/sum([datasimul2disp{k}(:).weightval]),'%3.1f');
                    end
                    alldata2disp{4+(m-1)*nbparambase,k+1}=num2str(datasimul2disp{k}(m).gaussianval,'%3.2f');
                    alldata2disp{5+(m-1)*nbparambase,k+1}=num2str(datasimul2disp{k}(m).lorentzianval,'%3.2f');
                    
                    alldata2disp{6+(m-1)*nbparambase,k+1}=num2str(rats(datasimul2disp{k}(m).Sval));
                    
                    g2disp=datasimul2disp{k}(m).gval;
                    alldata2disp{7+(m-1)*nbparambase,k+1}=num2str(g2disp(1),'%6.5f');
                    alldata2disp{8+(m-1)*nbparambase,k+1}=num2str(g2disp(2),'%6.5f');
                    alldata2disp{9+(m-1)*nbparambase,k+1}=num2str(g2disp(3),'%6.5f');
                    alldata2disp{10+(m-1)*nbparambase,k+1}=num2str(mean(g2disp),'%6.5f');
                    
                    A2disp=datasimul2disp{k}(m).Aval;
                    Istr2disp=datasimul2disp{k}(m).Istr;
                    if ~isnan(A2disp(1,:))
                        if ischar(Istr2disp{1})
                            alldata2disp{11+(m-1)*nbparambase,k+1}=Istr2disp{1};
                        else %iscell
                            alldata2disp{11+(m-1)*nbparambase,k+1}=Istr2disp{1}{1};
                        end
                        alldata2disp{12+(m-1)*nbparambase,k+1}=num2str(A2disp(1,1),'%3.2f');
                        alldata2disp{13+(m-1)*nbparambase,k+1}=num2str(A2disp(1,2),'%3.2f');
                        alldata2disp{14+(m-1)*nbparambase,k+1}=num2str(A2disp(1,3),'%3.2f');
                        alldata2disp{15+(m-1)*nbparambase,k+1}=num2str(mean(A2disp(1,:)),'%3.2f');
                    end
                    if ~isnan(A2disp(2,:))
                        if ischar(Istr2disp{2})
                            alldata2disp{16+(m-1)*nbparambase,k+1}=Istr2disp{2};
                        else %iscell
                            alldata2disp{16+(m-1)*nbparambase,k+1}=Istr2disp{2}{1};
                        end
                        alldata2disp{17+(m-1)*nbparambase,k+1}=num2str(A2disp(2,1),'%3.2f');
                        alldata2disp{18+(m-1)*nbparambase,k+1}=num2str(A2disp(2,2),'%3.2f');
                        alldata2disp{19+(m-1)*nbparambase,k+1}=num2str(A2disp(2,3),'%3.2f');
                        alldata2disp{20+(m-1)*nbparambase,k+1}=num2str(mean(A2disp(2,:)),'%3.2f');
                    end
                    HStrain2disp=datasimul2disp{k}(m).HStrainval;
                    alldata2disp{21+(m-1)*nbparambase,k+1}=num2str(HStrain2disp(1),'%3.2f');
                    alldata2disp{22+(m-1)*nbparambase,k+1}=num2str(HStrain2disp(2),'%3.2f');
                    alldata2disp{23+(m-1)*nbparambase,k+1}=num2str(HStrain2disp(3),'%3.2f');
                    
                    gStrain2disp=datasimul2disp{k}(m).gStrainval;
                    alldata2disp{24+(m-1)*nbparambase,k+1}=num2str(gStrain2disp(1),'%4.3f');
                    alldata2disp{25+(m-1)*nbparambase,k+1}=num2str(gStrain2disp(2),'%4.3f');
                    alldata2disp{26+(m-1)*nbparambase,k+1}=num2str(gStrain2disp(3),'%4.3f');
                    
                    AStrain2disp=datasimul2disp{k}(m).AStrainval;
                    alldata2disp{27+(m-1)*nbparambase,k+1}=num2str(AStrain2disp(1),'%3.2f');
                    alldata2disp{28+(m-1)*nbparambase,k+1}=num2str(AStrain2disp(2),'%3.2f');
                    alldata2disp{29+(m-1)*nbparambase,k+1}=num2str(AStrain2disp(3),'%3.2f');
                    
                    alldata2disp{30+(m-1)*nbparambase,k+1}=num2str(datasimul2disp{k}(m).Dval,'%3.2f');
                    alldata2disp{31+(m-1)*nbparambase,k+1}=num2str(datasimul2disp{k}(m).Eval,'%3.2f');

                    DStrain2disp=datasimul2disp{k}(m).DStrainval;
                    alldata2disp{32+(m-1)*nbparambase,k+1}=num2str(DStrain2disp(1),'%3.2f');
                    alldata2disp{33+(m-1)*nbparambase,k+1}=num2str(DStrain2disp(2),'%3.2f');                
                end
                
            end
            %cellule vide => '-'
            index_emptycell=cellfun('isempty',alldata2disp); % true for empty cells
            alldata2disp(index_emptycell)={'-'};
            set(htablecompare,'data',alldata2disp,'columnname',simulname2disp,'rowname',[],...
                'columnformat',colonneformat,'columnwidth',colonnelargeur);
         end
         
         set(hlist,'value',rang2load);%laisse la selection apparente
         set(hsavesimul,'enable','off'); 
         if runsim %=> 1 simul a ete lancee
            set(hcurrentsimul,'enable','on'); 
         end
   %  end
         reloading=false;
end

function closefigcompare(~,~)
       posSimultispincompare=get(hSimultispincompare,'outerposition');
       delete(hSimultispincompare)
       hSimultispincompare=hinit;
end
        
function suprfromlist(~,~)
    rang2del=get(hlist,'value');
  if ~isempty(rang2del) && numel(rang2del)==1
    listfile{rang2del}=[];
    listpath{rang2del}=[];
    listfile(cellfun(@isempty,listfile)) = []; %enleve les elements vide de la liste de fichiers
    listpath(cellfun(@isempty,listpath)) = []; %enleve les elements vide de la liste de chemins
    if ~isempty(listfile)
        clear list2disp
        for i=1:numel(listfile)
            list2disp{i}=[num2str(i),': ',listfile{i}];
        end    
        if rang2del>1 %trouver le nouvel elt selectione de la liste
            rang=rang2del-1;
        else
            rang=1;
        end
        %set(hlist,'string',list2disp,'value',rang);
        prevdata=load(fullfile(listpath{rang},listfile{rang}),'-mat'); %chargement chargement des donnees (prevdata=structure)
        loadanddisp(prevdata);
        set(hsavesimul,'enable','off'); 
        
        set(hlist,'string',list2disp,'value',rang);
    else
        %buttonrun=get(hrunsimul,'enable'); %mise en memoire de l'etat du bouton  'run'
        set(hlist,'string',[])
        set(hfreq,'TooltipString','');
                 %%%% supression des donnees %%%
         hfig2del=[componenth.hfig]; %handles des figures Simultispin_X a supprimer (1er element de componenth: initialisation)
         if numel(hfig2del)>=2 %s'il y a des fenetres a fermer
             for k=hfig2del(end:-1:2)
                closeSimultispinX(k);
             end
         end
%          set(hdeltaBval,'string',num2str(0));
%          set(hdeltaBslid,'value',0);
         
         
         set(hlist,'enable','off');
         set(hsuprfromlist,'enable','off');
         set(hexpfromlist,'enable','off');
         set(hupsim,'enable','off');
         set(hdownsim,'enable','off');
         set(hresetfreq,'enable','off');
         %set(hrunsimul,'enable',buttonrun); %bouton run dans meme etat qu'avant (si donnee dnas buffer)
    end 
  end
end

function suprfromlistexp(~,~)
    rang2del=get(hlistexp,'value');
  if ~isempty(rang2del) && numel(rang2del)==1
    listfileexp{rang2del}=[];
    listpathexp{rang2del}=[];
    listfileexp(cellfun(@isempty,listfileexp)) = []; %enleve les elements vide de la liste de fichiers
    listpathexp(cellfun(@isempty,listpathexp)) = []; %enleve les elements vide de la liste de chemins
    if ~isempty(listfileexp)
        clear list2dispexp
        for i=1:numel(listfileexp)
            list2dispexp{i}=[num2str(i),': ',listfileexp{i}];
        end    
        if rang2del>1 %trouver le nouvel elt selectione de la liste
            rang=rang2del-1;
        else
            rang=1;
        end
        loadexp(listfileexp{rang},listpathexp{rang});
        
        set(hlistexp,'string',list2dispexp,'value',rang);
    else
        %buttonrun=get(hrunsimul,'enable'); %mise en memoire de l'etat du bouton  'run'
        set(hlistexp,'string',[])
                 %%%% supression des donnees %%%
         suprexp();
         set(hdeltaBval,'string',num2str(0));
         set(hdeltaBslid,'value',0);
         
         set(hlistexp,'enable','off');
         set(hsuprfromlistexp,'enable','off');
         set (hupexp,'enable','off');
         set (hdownexp,'enable','off'); 
         set(hexptool,'enable', 'off');
         
    end 
  end
end


function expfromlist(~,~)
    
    rang2exp=get(hlist,'value'); %{fullfile(listpath{rang2exp},[listfile{rang2exp}(1:end-4),
  if numel(rang2exp)==1 %exportation possible si 1! simul selectionnee
      epsB=1e-13;
      [expf,path2expf]=uiputfile('*.txt','export',fullfile(listpath{rang2exp},listfile{rang2exp}(1:end-4))); %ouverture boite de dialogue dans repertoire courant (nom propose)
      if expf~=0 
             data2exp=load(fullfile(listpath{rang2exp},listfile{rang2exp}),'-mat'); 
             B2exp=get(hplotsimall,'xdata');%linspace(data2exp.Exp.Range(1),data2exp.Exp.Range(2),numel(spec2exp)); %champ magnetique a exporter
             nbcomp=numel(data2exp.datasimul);%nb de composantes
             for k=1:nbcomp
                speccomp2exp(:,k)=data2exp.datasimul(k).specsimul; %spectres des composantes a exporter
             end
             spectot2exp=sum(speccomp2exp,2);% somme des simul de composantes 
            [spectot2exp_,scalefact4exp]=mimilrescale(B2exp,spectot2exp,1);% somme des simul de composantes, recalee
            speccomp2exp_=speccomp2exp*scalefact4exp;
             %spectre
             mat2exp(:,1)=B2exp';
             currentcol=2;
             addspecexp=false; %marqueur de presence de spectre exp
             if ishandle(hspecexp)
                specexp2exp=mimilrescale(Bexp,spec,1);
                newBexp=Bsimul;
                specexp2exp=interp1(Bexp,specexp2exp,newBexp,'spline',0);
                mat2exp(:,2)=specexp2exp;
                currentcol=3;
                addspecexp=true;
             end
             fid=fopen(fullfile(path2expf,expf),'w');
             %1ere ligne
             fprintf(fid,'%13s\t','B [mT]');
             if addspecexp
                    fprintf(fid,'%13s\t','Exp'); 
             end
             scalingfactor=str2double(get(hscalingval,'string'));
             mat2exp(:,currentcol)=scalingfactor*spectot2exp_;
             for k=1:nbcomp
                mat2exp(:,k+currentcol)=scalingfactor*speccomp2exp_(:,k);
             end
             
             if nbcomp>1                 
                 fprintf(fid,'%13s\t','Sim');
                 nbcp=numel(componentdata); %nombre component +1
                 for k=2:nbcp
                     switch k
                         case nbcp
                             fprintf(fid,'%13s\n',componentdata(k).name);
                         otherwise
                             fprintf(fid,'%13s\t',componentdata(k).name);
                     end
                 end

                 %lignes suivantes
                 linenb=size(mat2exp,1);
                 colnb=size(mat2exp,2);
                 for k=1:linenb
                     for col=1:colnb-1
                         fprintf(fid,'%e\t',mat2exp(k,col));
                     end
                     if k~=linenb
                         fprintf(fid,'%e\n',mat2exp(k,col+1));
                     else
                         fprintf(fid,'%e',mat2exp(k,col+1));
                     end
                 end
             else
                 fprintf(fid,'%13s\n',componentdata(2).name);
                 %lignes suivantes
                 linenb=size(mat2exp,1);
                 colnb=size(mat2exp,2);
                 for k=1:linenb
                     for col=1:colnb-2
                         fprintf(fid,'%e\t',mat2exp(k,col));
                     end
                     if k~=linenb
                         fprintf(fid,'%e\n',mat2exp(k,col+1));
                     else
                         fprintf(fid,'%e',mat2exp(k,col+1));
                     end
                 end
             end
             fclose(fid);
             
             savepar(fullfile(path2expf,expf),rang2exp); %param de la simul dans fichier par
      end

 end
end

function movesim(~,~,strsign) %strsign='+' ou '-'
    rang1=get(hlist,'value'); %highlighted simul
    nbsim=numel(get(hlist,'string')); %nb de simul chargees/sauvees
    switch strsign
       case '+'
           if rang1~=nbsim
               rang2=rang1+1;
           else
               rang2=0;
           end         
           
       case '-'
           if rang1~=1
               rang2=rang1-1;
           else
               rang2=0;
           end   
    end
    if rang2~=0
        path1=listpath{rang1};file1=listfile{rang1};
        path2=listpath{rang2};file2=listfile{rang2};
        
        listpath{rang1}=path2;listfile{rang1}=file2;list2disp{rang1}=[num2str(rang1),': ',file2];
        listpath{rang2}=path1;listfile{rang2}=file1;list2disp{rang2}=[num2str(rang2),': ',file1];
        set(hlist,'value',rang2,'string',list2disp);  
    end
end

function moveexp(~,~,strsign) %strsign='+' ou '-'
    rang1=get(hlistexp,'value'); %highlighted exp
    nbsim=numel(get(hlistexp,'string')); %nb de spc exp charges
    switch strsign
       case '+'
           if rang1~=nbsim
               rang2=rang1+1;
           else
               rang2=0;
           end         
           
       case '-'
           if rang1~=1
               rang2=rang1-1;
           else
               rang2=0;
           end   
    end
    if rang2~=0
        path1=listpathexp{rang1};file1=listfileexp{rang1};
        path2=listpathexp{rang2};file2=listfileexp{rang2};
        
        listpathexp{rang1}=path2;listfileexp{rang1}=file2;list2dispexp{rang1}=[num2str(rang1),': ',file2];
        listpathexp{rang2}=path1;listfileexp{rang2}=file1;list2dispexp{rang2}=[num2str(rang2),': ',file1];
        set(hlistexp,'value',rang2,'string',list2dispexp);  
    end
end

function suprexp(~,~)
    delete(hspecexp);
    set(hexpname,'visible','off');
    set(hfitindicator,'visible','off');
    hspecexp=hinit; %handle de spectre experimental 
    set(hsuprexp,'enable','off');
    set(hdeltaB1,'enable','off');
    set(hdeltaBval,'enable','off');
    set(hdeltaBslid,'enable','off');
    if ~ishandle(hplotsimall)
        set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
    end
    if ishandle(hpoint)
        delete(hpoint)
        delete(hvert)
        set(hcursorinfo,'string','','visible','off');
    end
    Bexpinit=[]; %champ experimental brut
    Bexp=[]; %champ experimental decale
    specexp=[]; %spectre experimenatl normalise
    spec=[]; %spectre experimenatl brut
    expfreq=NaN; %frequence experimentale
    expspecf=[]; %nom fu fichier exp
    path2expspec=[];%chemin du fichier exp
    setlegend();
    set(hnormminmax,'value',1);
    normradiocllbck;
    set(hlistexp,'value',[]);
    set(hresetfreq,'enable','on');
end

function suprsimul(~,~)
    delete(hplotsimall);
    hplotsimall=hinit;
    hplot2del=[componenth.hplot];
    for k=1:numel(hplot2del)
        if ishandle(hplot2del(k))
            delete(hplot2del(k))
        end
    end
    set(hfreq,'string','');
    set(hfitindicator,'visible','off'); 
    dispsimulfreq=NaN;
    set(hsuprsimul,'enable','off');
    if ~ishandle(hspecexp)
        set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
        expfreq=NaN; %frequence experimentale
    end
   h2close=[componenth.hfig];
    for k=2:numel(h2close)
        close(h2close(k))
    end
    set(hlist,'value',[]);
    set(hfreq,'TooltipString','');
    setlegend();
    set(hrealtime,'value',0);
    chkrealtime()
    if ishandle(hpoint)
        delete(hpoint)
        delete(hvert)
        set(hcursorinfo,'string','','visible','off');
    end
end

function cllbckfs(~,~) %full scale
    limitex=get(hspecaxes,'xlim');
    limitey=get(hspecaxes,'ylim');
    if ishandle(hspecexp)
        maxy=max(specexp);
        miny=min(specexp);
        h=maxy-miny;
        %[miny-0.08*h maxy+0.08*h]
        if limitex~=[Bexp(1) Bexp(end)] | limitey~=[miny-fsfactor*h maxy+fsfactor*h] %si limites courantes !=limites apres fullscale sur spectre exp
            fullscale(Bexp,specexp);
        elseif ishandle(hplotsimall)
            fullscale(Bsimul,dispspecsimul);
        end
    elseif ishandle(hplotsimall) && ~isequal(dispspecsimul,zeros(1,numel(dispspecsimul))) %= zeros() si pas de resonance sur plagede champ
        fullscale(Bsimul,dispspecsimul);
        %set(hrunsimul,'enable','off');
    end  
end

function cllbckresetfreq(~,~)
    delete(hplotsimall);
    hplotsimall=hinit;
    hplot2del=[componenth.hplot];
    for k=1:numel(hplot2del)
        if ishandle(hplot2del(k))
            delete(hplot2del(k))
        end
    end
    set(hfreq,'string','');
    set(hfitindicator,'visible','off'); 
    dispsimulfreq=NaN;
    set(hsuprsimul,'enable','off');
 %   if ~ishandle(hspecexp)
        set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
        expfreq=NaN; %frequence experimentale
%    end
%    h2close=[componenth.hfig];
%     for k=2:numel(h2close)
%         close(h2close(k))
%     end
    set(hlist,'value',[]);
    set(hfreq,'TooltipString','');
    setlegend();
    set(hrealtime,'value',0);
    chkrealtime()
end

function cllbckexpandx(~,~) %x2 plage des x
    limitex=get(hspecaxes,'xlim');
    if limitex~=[0 1] %si limites courantes !=limites par defaut
        meanx=mean(limitex);
        swx=limitex(2)-limitex(1);
        set(hspecaxes,'xlim',[meanx-swx meanx+swx]); 
        set(hrunsimul,'enable','on');
        %set(hrealtime,'value',0);
    end    
end

function cllbcksetB(~,~) %imposer manuellement plage de B
    Blimcurr=get(hspecaxes,'xlim');
    if isequal(Blimcurr,[0 1])
        Blimcurr=defaultRangeB(9.8);
    end
    prompt = {'Enter B min (mT):','Enter B max (mT):'};
    dlg_title = 'Simultispin_setB';
    num_lines = 1;
    def = {num2str(Blimcurr(1)),num2str(Blimcurr(2))};
    newBlimcell=inputdlg(prompt,dlg_title,num_lines,def);
    newBlim=str2double(newBlimcell);
    if ~isnan(newBlim)
        set(hspecaxes,'xlim',newBlim);
    end
    
end

function cllbckexpandy(~,~) %x2 plage des y
    limitey=get(hspecaxes,'ylim');
    if limitey~=[0 1] %si limites courantes !=limites par defaut
        meany=mean(limitey);
        swy=limitey(2)-limitey(1);
        set(hspecaxes,'ylim',[meany-swy meany+swy]); 
    if ishandle(hvert)
        set(hvert,'ydata',get(hspecaxes,'ylim'));
    end
    end    
end

function savefig(~,~)
 if ~isempty(get(hspecaxes,'children')) %si des plot sont affiches
  rang2exp=get(hlist,'value'); %{fullfile(listpath{rang2exp},[listfile{rang2exp}(1:end-4),
  if ~isempty(rang2exp) && numel(rang2exp)==1
    [figname,path2fig]=uiputfile({'*.bmp';'*.jpeg';'*.tif';'*.eps';'*.fig'},'export',fullfile(listpath{rang2exp},listfile{rang2exp}(1:end-4))); %ouverture boite de dialogue dans repertoire courant (nom propose)
  else
    [figname, path2fig] = uiputfile({'*.bmp';'*.tif';'*.jpeg';'*.eps';'*.fig'});
  end
    if figname~=0
        if ~isempty(rang2exp) && numel(rang2exp)==1
            savepar(fullfile(path2fig,figname),rang2exp); %param de la simul dans fichier par
            simulname=listfile{rang2exp};
        elseif comparisonmode % en mode comparaison
%             uiwait(msgbox({'WARNING:   Simulation not saved or overlaid simulations...'  ;['No ',figname(1:end-4),'.par will be saved.']},...
%                  'Simultispin_WARNING','Warn','modal'));
            simulname=[];
        else %pas en mode comparaison
             uiwait(msgbox({'WARNING:   Simulation not saved or overlaid simulations...'  ;['No ',figname(1:end-4),'.par will be saved.']},...
                  'Simultispin_WARNING','Warn','modal'));
            simulname=[];
        end    
        hplots2save=findobj(hSimultispinmain,'type','axes'); %liste des handles de plot a sauver (dans graphe=axes)
        pos2save=get(hSimultispinmain,'position');
        figure2save=figure();%figure(max(findobj('type','figure'))+1); %pour ne pas superposer des figures 
        set(figure2save,'Units','pixels','Name','Simultispin_archive','NumberTitle','off','visible','off',...
            'Position',pos2save.*[1 1 1 0.75],'Menubar', 'figure','Toolbar', 'figure');
        %hspecaxes=axes('parent',hSimultispinmain,'OuterPosition',[0 0.25 1 0.75],'Position',[0.05 0.30 0.9 0.65],'Xcolor','k');
        %'Outerposition',[0.05 0.4 0.5 0.5],
        copyobj(hplots2save,figure2save);%graphe(=axes)+legend copier dans nouvelle figure

        %new title
        hnewaxes=findobj(figure2save,'type','axes');
        if versionyear>2014
            haxes2save=hnewaxes;
        else
            haxes2save=hnewaxes(2);%hnewaxes(1)=legend
        end
        set(haxes2save,'position',[0.05 0.067 0.9 0.87],'Xcolor',[0.15 0.15 0.15]);
        %set(hnewaxes(1),'position',[0.05 0.067 0.9 0.87]);
        %newtitle=['exp: ',expspecf(1:end-4),'  /  simul: ',strrep(simulname(1:end-4),'_','\_') ];
       
        if strcmp(get(hfitindicator,'visible'),'on')
                newtitle=['exp: ',expspecf(1:end-4),'  /  simul: ',simulname(1:end-4),'  /  ',get(hfitindicator,'string') ];
        else
                newtitle=['exp: ',expspecf(1:end-4),'  /  simul: ',simulname(1:end-4) ];
        end

        title(newtitle,'fontsize',0.8*ftsz,'interpreter','none'); %hnewaxes(1)=legend
        set(figure2save,'visible','on');
        %pause
        saveas(figure2save,fullfile(path2fig,figname));
        delete(figure2save);
        clear haxes2save hplots2save figure2save;
    end
 end
end

function opendoc(~,~)
        fullname=fullfile(path4doc,'Simultispin_documentation.pdf');
            if ispc
           winopen('Simultispin_documentation.pdf'); 
           elseif ismac
                system(['open ',fullname]);
            elseif isunix
           system(['evince ',fullname]);
            end

    if ishandle(hmt2mhz) %si figure conversion deja affichee
        figure(hmt2mhz)
    else
        openmhz2mt();%ouvrir figure avec conversion mT et MHz
    end
end

function openmhz2mt() %affiche figure avec conversion mT et MHz
     hmt2mhz=figure();   
     pos=get(hSimultispinmain,'position');
     set(hmt2mhz,'Units','pixels','position',[pos(1) pos(2) 200 420],...
                 'Name','Simultispin_conv','Menubar', 'none', 'Toolbar', 'none',...
                 'NumberTitle','off','resize','on','CloseRequestFcn',@closemhz2mt,...
                 'color',[0.25 0.25 0.25]);
                 %'CloseRequestFcn',@closefig2esfit);
    %%% 1
        AmT=3.25:0.2:4.85;
        AMHz=90:5:135;

        lw=2;%linewidth

        haxmt2mhz=subplot(1,2,2);
        plot(ones(numel(AmT),1),AmT,'.w');%faire apparaitre figure

        limitx=get(haxmt2mhz,'xlim');
        set(haxmt2mhz,'ylim',[3.05 5.2],'xlim',limitx,'xtick',NaN,'ytick',NaN,'position',[0.5 0.075 0.45 0.85]);
        annotation(hmt2mhz,'arrow',[0.73 0.73],[0.12 0.85],'linewidth',lw);

        %%% mT %%%
        for k=1:numel(AmT)
        line([0.8 1],AmT(k)*[1 1],'color','k','linewidth',lw)
        text(0.1,AmT(k),num2str(AmT(k)));
        end
        %%% MHz %%
        for k=1:numel(AMHz)
        line([1 1.2],mhz2mt(AMHz(k))*[1 1],'color','k','linewidth',lw)
        text(1.3,mhz2mt(AMHz(k)),num2str(AMHz(k)));
        end

        y=5.06;
        text(0.3,y,'mT','fontweight','bold');
        text(1.2,y,'MHz','fontweight','bold');

        %%% 2
        AmT=0.35:0.05:0.55;
        AMHz=10:1:15;

        haxmt2mhz=subplot(1,2,1);
        plot(ones(numel(AmT),1),AmT,'.w');%faire apparaitre figure

        limitx=get(haxmt2mhz,'xlim')-0.1;
        set(haxmt2mhz,'ylim',[0.33 0.6],'xlim',limitx,'xtick',NaN,'ytick',NaN,'position',[0.05 0.075 0.4 0.85]);
        annotation(hmt2mhz,'arrow',[0.275 0.275],[0.12 0.85],'linewidth',lw);

        %%% mT %%%
        for k=1:numel(AmT)
        line([0.8 1],AmT(k)*[1 1],'color','k','linewidth',lw)
        text(0,AmT(k),num2str(AmT(k),'%1.2f'));
        end
        %%% MHz %%
        for k=1:numel(AMHz)
        line([1 1.2],mhz2mt(AMHz(k))*[1 1],'color','k','linewidth',lw)
        text(1.3,mhz2mt(AMHz(k)),num2str(AMHz(k)));
        end

        y=0.582;%5.1;
        text(0.25,y,'mT','fontweight','bold');
        text(1.1,y,'MHz','fontweight','bold');
end

function closemhz2mt(~,~) %ferme proprement figure avec conversion mT et MHz
    delete(hmt2mhz);
    hmt2mhz=hinit;   
end

%% fenetre pour 1 composant
function addcomponent(~,~) %ouverture nouvelle fenetre avec parametres d'une composante
    hfig=opencomponentwin; % ouverture d'une nouvelle fenetre de composante Simultispin_X
    %numel(componentdata)

    %place=find([componenth.hfig]==hfig) %indice de la composante consideree dans la structure des handles componenth
        place=find([componenth.hfig]==hfig); %indice de la composante consideree dans la structure des handles componenth
        componentdata(place)=componentdata(1);
        Sys{place}=Sys{1};
        dispcomponent(place); % remplissage de la fenetre avec donnees de depart
        if ishandle(hplotsimall)
            set(componenth(place).hchk,'value',0);
            set(componenth(place).hhide,'enable','off');
            set(componenth(place).hvisible,'enable','off');
            componentdata(place).include=0;
            componentdata(place).status=0;
            set(hrealtime,'value',0);
            set(hrunsimul,'enable','on');
        end
        dispweight();
end 

function hfig=opencomponentwin()   
    % ouverture d'une nouvelle fenetre de composante Simultispin_X :
    % hfig=handle de la figure, componentnumber: numero de composante
    %%% numero du nom de la fenetre: Simultispin_XX %%%
    fignumber=1; %numero de la  fenetres Simultispin_XX en train d'etre ouverte (1 par defaut)
    allfigname=get(findobj('type','figure'),'name'); %cellarray avec noms des figures ouvertes
    if ~isempty(allfigname)
        if ~ischar(allfigname) %Si 1! fenetre (Simultispin_main), fignumber=1
          allfigname=sort(allfigname);% +petit au + grand ('Simultispin_main' a la fin)
          for i=1:numel(allfigname)
              numSimultispin(i)=str2double(allfigname{i}(13:end));
          end
          numSimultispin(isnan(numSimultispin))=[]; %suprimer les NaN
          while  ~isempty(find(numSimultispin==fignumber,1))
              fignumber=fignumber+1;
          end
        end
    end
    
    %%%position de la figure
    if fignumber<=size(poscomponentfig,1)
        pos=poscomponentfig(fignumber,:);
    else
        posylocal=scrszpix(4)-scrszpix(4)/20-280-scrszpix(4)*0.1*(fignumber-1);
        if posylocal<0
            posylocal=min(poscomponentfig(:,2));
        end
        pos=[scrszpix(3)-scrszpix(3)/20-800 posylocal 800 280];
    end
    %%% creation figure Simultispin_X
    hcurrentcomp=figure();%floor(max(findobj('type','figure'))+1)); %pour ne pas superposer des figures
    %hcurrentcomp=handle de la figure dans cette function
    set(hcurrentcomp,'Units','pixels',...
        'position',pos,...
        'Name',['Simultispin_',num2str(fignumber)],'Menubar', 'none',...
        'Toolbar', 'none','NumberTitle','off','DoubleBuffer','on',...'resize','off',...
        'color',[0.25 0.25 0.25],'CloseRequestFcn',@closeSimultispinX); % handle=0 correspond a root (ie bureau?!)
   
    %%% boutons
%     if fignumber>10
%         fignumberstr=num2str(fignumber);
%         kolornumber=str2double(fignumberstr(end));
%     else
%         kolornumber=fignumber;
%     end;
    hname = uicontrol(...
        'Parent',hcurrentcomp,...
        'Style','edit',...
        'Units','normalized',...
        'FontUnits','pixels',...
        'FontWeight','bold',...
        'BackgroundColor','w',...
        'Callback',@cllbckname,...
        'FontSize',1.3*ftsz,...'ForegroundColor',kolor(kolornumber,:),...[1 0 1],...
        'HorizontalAlignment','left',...
        'Position',[0.1 0.90 0.15 0.08],...
        'TooltipString',sprintf('Name of the component\n(can be modified)'));%'String',['component ',num2str(fignumber)]);
    
    hchk = uicontrol(...
        'Parent',hcurrentcomp,...
        'Style','checkbox',...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',@cllbckchk,...
        'FontSize',ftsz,...
        'Position',[0.1 0.83 0.08 0.05],...
        'String','Include',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Include in simulation',...
        'Value',1);

    haniso = uicontrol(...
        'Parent',hcurrentcomp,...
        'Style','checkbox',...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',@cllbckanisolw,...
        'FontSize',ftsz,...
        'Position',[0.55 0.65 0.18 0.05],...
        'String','Strain broadenings',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Check to set strain broadenings instead of convolutional broadenings',...
        'Value',0);
    
 %%%%%%%%%%%%
   hpanelradio=uibuttongroup(...
        'Parent',hcurrentcomp,...
        'BorderType','none',...'etchedin',
        'Title','',...
        'Position',[0.26 0.83 0.07 0.17],...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'SelectedObject',[],...
        'SelectionChangeFcn',@visible_or_hide,...
        'OldSelectedObject',[]);
    
    hvisible = uicontrol(...
        'Parent',hpanelradio,...
        'Style','radiobutton',...
        'Units','normalized',...
        'Position',[0 0.5 1 0.5],...
        'String','Visible',...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Display the component spectrum');%,...
        %'Value',0);
   % 'Callback',@(hObject,eventdata)Simultispin_componentX_export('visible_Callback',hObject,eventdata,guidata(hObject)),...
    
    hhide = uicontrol(...
        'Parent',hpanelradio,...
        'Style','radiobutton',...
        'Units','normalized',...
        'Position',[0 0.2 1 0.3 ],...
        'String','Hidden',...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Hide the component spectrum');%,...
        %'Value',1);
    %        'Callback',@(hObject,eventdata)Simultispin_componentX_export('hide_Callback',hObject,eventdata,guidata(hObject)),...
 %%%  store in memory as default parameters %%%
    uicontrol(...
        'Parent',hcurrentcomp,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',@cllbckstorepar,...
        'FontSize',ftsz,...
        'Position',[0.01 0.89 0.07 0.09],...
        'String','To Next',...
        'TooltipString','Store parameters in memory for next new components',...
        'enable','on',...
        'Style','pushbutton');  
    
 %%%  weight   %%%   
      htextweight = uicontrol(...  % text weight=
        'Parent',hcurrentcomp,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'FontWeight','bold',...
        'HorizontalAlignment','center',...'BackgroundColor','w',...
        'FontSize',1.3*ftsz,...
        'Position',[0.09 0.75 0.1 0.06],...
        'String','weight =',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Component absolute weight',...
        'visible','off',...
        'Style','text');
 
    heditweight = uicontrol(...
        'Parent',hcurrentcomp,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',@cllbckeditweight,...
        'FontSize',ftsz,...
        'Position',[0.18 0.75 0.05 0.06],...
        'TooltipString','Component absolute weight',...
        'visible','off',...
        'Style','edit');
    
     htextpercent = uicontrol(...  % text (XX%)
        'Parent',hcurrentcomp,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'BackgroundColor','w',...
        'FontSize',1.3*ftsz,...
        'Position',[0.23 0.72 0.08 0.1],...
        'TooltipString','Relative proportion of this component',...
        'visible','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

%%%% lw  %%%%%%%
    hpanellw = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.3*ftsz,...
        'FontWeight','bold',...
        'Title','Isotropic Line Width',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.44 0.74 0.25 0.255]);
    
    uicontrol(...  % text lorentzian
        'Parent',hpanellw,...
        'Units','normalized',...
        'FontUnits','pixels',...'BackgroundColor','w',...
        'HorizontalAlignment','right',...
        'FontSize',ftsz,...
        'Position',[0.01 0.2 0.3 0.2],...
        'String','Lorentzian:',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Lorentzian part of line width',...
        'Style','text');
   
    heditlorentzian = uicontrol(...
        'Parent',hpanellw,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',@cllbckeditlorentzian,...
        'FontSize',ftsz,...
        'Position',[0.32 0.15 0.16 0.3],...
        'TooltipString','Lorentzian part of line width',...
        'Style','edit');

     uicontrol(...  % text mT
        'Parent',hpanellw,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.48 0.2 0.1 0.2],...'BackgroundColor','w',...
        'String','mT',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     hslidlorentzian = uicontrol(...
        'Parent',hpanellw,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',@cllbckslidlorentzian,...
        'Position',[0.62 0.15 0.35 0.28],...
        'Min',lwmin,...
        'Max',lwmax,...
        'SliderStep',[minsteplw maxsteplw],...
        'TooltipString','Lorentzian part of line width',...
        'backgroundcolor',[0.25 0.25 0.25],...
        'Style','slider');
    
    uicontrol(...  % text gaussian
        'Parent',hpanellw,...
        'Units','normalized',...
        'FontUnits','pixels',... 'BackgroundColor','w',...
        'HorizontalAlignment','right',...
        'FontSize',ftsz,...
        'Position',[0.01 0.67 0.28 0.2],...
        'String','Gaussian:',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Gaussian part of line width',...
        'Style','text');
   
    heditgaussian = uicontrol(...
        'Parent',hpanellw,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',@cllbckeditgaussian,...
        'FontSize',ftsz,...
        'Position',[0.32 0.6 0.16 0.3],...
        'TooltipString','Gaussian part of line width',...
        'Style','edit');

     uicontrol(...  % text mT
        'Parent',hpanellw,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.48 0.67 0.1 0.2],...'BackgroundColor','w',...
        'String','mT',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     hslidgaussian = uicontrol(...
        'Parent',hpanellw,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',@cllbckslidgaussian,...
        'Position',[0.62 0.6 0.35 0.28],...
        'Min',lwmin,...
        'Max',lwmax,...
        'SliderStep',[minsteplw maxsteplw],...
        'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Gaussian part of line width',...
        'Style','slider');
    
    %%%% S  %%%%%%%
    hpanelS = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.5*ftsz,...
        'FontWeight','bold',...
        'Title','S',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.35 0.805 0.08 0.19]);

    hpopupS = uicontrol(...
        'Parent',hpanelS,...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'BackgroundColor','w',...
        'Units','normalized',...
        'Callback',@cllbckpopupS,...
        'Position',[0.1 0.5 0.80 0.30],...
        'String',differentS,...
        'Style','popupmenu',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Electronic spin value');
    
%%%% g  %%%%%%%
    hpanelg = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',2*ftsz,...
        'FontWeight','bold',...
        'FontName','Times New Roman',...
        'Title','g',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.01 0.1 0.17 0.50]);
    
    haxialg = uicontrol(...
        'Parent',hpanelg,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',@cllbckaxialg,...
        'FontSize',ftsz,...
        'Position',[0.03 0.1 0.24 0.14],...
        'String','Axial',...
        'TooltipString','Axial g tensor',...
        'enable','on',...
        'Style','pushbutton');

    heditg1 = uicontrol(...
        'Parent',hpanelg,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditg,1},...
        'FontSize',ftsz,...
        'Position',[0.03 0.74 0.33 0.2],...
        'TooltipString','g_1',...
        'Style','edit');
    
     hmarkerg1 = uicontrol(...  
        'Parent',hpanelg,...
        'Units','normalized',...
        'Position',[0.02 0.74 0.03 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');

     hslidg1 = uicontrol(...
        'Parent',hpanelg,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidg,1},...
        'Position',[0.37 0.77 0.62 0.14],...
        'TooltipString','g_1',...
        'backgroundcolor',[0.25 0.25 0.25],...
        'Min',gmin,...2.00000
        'Max',gmax,...2.01800,...
        'SliderStep',[minstepg maxstepg],...[1e-5/2 50e-5/2],...
        'Style','slider');    

     heditg2 = uicontrol(...
        'Parent',hpanelg,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditg,2},...
        'FontSize',ftsz,...
        'Position',[0.03 0.51 0.33 0.2],...
        'TooltipString','g_2',...
        'Style','edit');
    
      hmarkerg2 = uicontrol(...  
        'Parent',hpanelg,...
        'Units','normalized',...
        'Position',[0.02 0.51 0.03 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');

      hslidg2 = uicontrol(...
        'Parent',hpanelg,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidg,2},...
        'Position',[0.37 0.54 0.62 0.14],...
        'backgroundcolor',[0.25 0.25 0.25],...
         'TooltipString','g_2',...
        'Min',gmin,...2.00000
        'Max',gmax,...2.01800,...
        'SliderStep',[minstepg maxstepg],...[1e-5/2 50e-5/2],...
        'Style','slider');
    
     heditg3 = uicontrol(...
        'Parent',hpanelg,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditg,3},...
        'FontSize',ftsz,...
        'Position',[0.03 0.28 0.33 0.2],...
        'TooltipString','g_3',...
        'Style','edit');
    
      hmarkerg3 = uicontrol(...  
        'Parent',hpanelg,...
        'Units','normalized',...
        'Position',[0.02 0.28 0.03 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');

      hslidg3 = uicontrol(...
        'Parent',hpanelg,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidg,3},...
        'Position',[0.37 0.31 0.62 0.14],...
         'TooltipString','g_3',...
        'backgroundcolor',[0.25 0.25 0.25],...
        'Min',gmin,...2.00000
        'Max',gmax,...2.01800,...
        'SliderStep',[minstepg maxstepg],...[1e-5/2 50e-5/2],...
        'Style','slider');
    

       uicontrol(...  % text g_iso=
        'Parent',hpanelg,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',1.1*ftsz,...
        'FontName','Times New Roman',...
        'Position',[0.34 0.1 0.30 0.12],...'BackgroundColor','w',...
        'String','g_iso =',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Averaged g value',...
        'Style','text');
    
       hgmoy = uicontrol(...  % 
        'Parent',hpanelg,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.63 0.10 0.30 0.13],...
        'TooltipString','Averaged g value',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

%%%% A1  %%%%%%%
    hpanelA1 = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.6*ftsz,...
        'FontWeight','bold',...
        'Title','A_1',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.19 0.1 0.23 0.5]);
    
    hdocA1 = uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.90 0.01 0.09 0.15],'parent',hpanelA1,'Callback', @popupA,...
            'TooltipString',sprintf('periodic table'));

    hpopupI1 = uicontrol(...
        'Parent',hpanelA1,...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'BackgroundColor','w',...
        'Units','normalized',...
        'Callback',{@cllbckpopupI,1},...
        'Position',[0.011 0.6 0.22 0.25],...
        'String',differentI,...
        'Style','popupmenu',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Nuclear spin for the 1st hyperfine coupling',...
        'Value',1);

    haxialA1 = uicontrol(...
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',{@cllbckaxialA,1},...
        'FontSize',ftsz,...
        'Position',[0.02 0.4 0.18 0.15],...
        'String','Axial',...
        'TooltipString','Axial A1 tensor',...
        'enable','off',...
        'Style','pushbutton');    
    
    heditA11 = uicontrol(...
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditA,1,1},...
        'FontSize',ftsz,...
        'Position',[0.23 0.74 0.23 0.2],...
        'TooltipString','A1_1',...
        'enable','off',...
        'Style','edit');
    
    hmarkerA11 = uicontrol(...  
        'Parent',hpanelA1,...
        'Units','normalized',...
        'Position',[0.23 0.74 0.02 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');
    
     uicontrol(...  % text MHz(A1_1)
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.46 0.78 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'enable','off',...
        'Style','text');

     hslidA11 = uicontrol(...
        'Parent',hpanelA1,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidA,1,1},...
        'Position',[0.59 0.77 0.40 0.14],...
        'TooltipString','A1_1',...
        'Min',Amin,...
        'Max',Amax,...
        'backgroundcolor',[0.25 0.25 0.25],...
        'SliderStep',[minstepA maxstepA],...
        'enable','off',...
        'Style','slider');    

     heditA12 = uicontrol(...
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditA,1,2},...
        'FontSize',ftsz,...
        'Position',[0.23 0.51 0.23 0.2],...
        'TooltipString','A1_2',...
        'enable','off',...
        'Style','edit');
     
     hmarkerA12 = uicontrol(...  
        'Parent',hpanelA1,...
        'Units','normalized',...
        'Position',[0.23 0.51 0.02 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');

     uicontrol(...  % text MHz(A1_2)
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.46 0.55 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hslidA12 = uicontrol(...
        'Parent',hpanelA1,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidA,1,2},...
        'Position',[0.59 0.54 0.40 0.14],...
        'TooltipString','A1_2',...
        'Min',Amin,...
        'Max',Amax,...
        'backgroundcolor',[0.25 0.25 0.25],...
        'SliderStep',[minstepA maxstepA],...
        'enable','off',...
        'Style','slider');
    
     heditA13 = uicontrol(...
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditA,1,3},...
        'FontSize',ftsz,...
        'Position',[0.23 0.28 0.23 0.2],...
        'TooltipString','A1_3',...
        'enable','off',...
        'Style','edit');

    hmarkerA13 = uicontrol(...  
        'Parent',hpanelA1,...
        'Units','normalized',...
        'Position',[0.23 0.28 0.02 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');

     uicontrol(...  % text MHz(A1_3)
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.46 0.32 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hslidA13 = uicontrol(...
        'Parent',hpanelA1,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidA,1,3},...
        'Position',[0.59 0.31 0.40 0.14],...
        'TooltipString','A1_3',...
        'backgroundcolor',[0.25 0.25 0.25],...
        'Min',Amin,...
        'Max',Amax,...
        'SliderStep',[minstepA maxstepA],...
        'enable','off',...
        'Style','slider');
    
      uicontrol(...  % text A1_iso=
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.21 0.022 0.30 0.12],...'BackgroundColor','w',...
        'String','A_1_iso =',...
        'TooltipString','Averaged A1 value',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hA1moy = uicontrol(...  % 
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.51 0.032 0.20 0.1],...
        'TooltipString','Averaged A1 value',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      uicontrol(...  % text MHz(A1moy)
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.72 0.032 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'TooltipString','Averaged A1 value',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     uicontrol(...  % text A1 (mT)= [
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.032 0.15 0.3 0.12],...'BackgroundColor','w',...
        'String','A1(mT)= [',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');  
    
      uicontrol(...  % text ]
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.85 0.15 0.05 0.12],...'BackgroundColor','w',...
        'String',']',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

    hAmt11 = uicontrol(...  % 
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.32 0.16 0.18 0.1],...
        'TooltipString','A1(1) in mT',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
    hAmt12 = uicontrol(...  % 
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.51 0.16 0.18 0.1],...
        'TooltipString','A1(2) in mT',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hAmt13 = uicontrol(...  % 
        'Parent',hpanelA1,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.70 0.16 0.18 0.1],...
        'TooltipString','A1(3) in mT',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

%%%% A2  %%%%%%%
    hpanelA2 = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.6*ftsz,...
        'FontWeight','bold',...
        'Title','A_2',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.43 0.1 0.23 0.5]);
    
     hdocA2 = uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.90 0.01 0.09 0.15],'parent',hpanelA2,'Callback', @popupA,...
            'TooltipString',sprintf('periodic table'));

    hpopupI2 = uicontrol(...
        'Parent',hpanelA2,...
        'FontUnits','pixels',...
        'FontSize',ftsz,...
        'BackgroundColor','w',...
        'Units','normalized',...
        'Callback',{@cllbckpopupI,2},...
        'Position',[0.011 0.6 0.22 0.25],...
        'String',differentI,...
        'Style','popupmenu',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','Nuclear spin for the 2nd hyperfine coupling',...
        'Value',1);

    haxialA2 = uicontrol(...
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',{@cllbckaxialA,2},...
        'FontSize',ftsz,...
        'Position',[0.02 0.4 0.18 0.15],...
        'String','Axial',...
        'TooltipString','Axial A2 tensor',...
        'enable','off',...
        'Style','pushbutton');    
    
    heditA21 = uicontrol(...
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditA,2,1},...
        'FontSize',ftsz,...
        'Position',[0.23 0.74 0.23 0.2],...
        'TooltipString','A2_1',...
        'enable','off',...
        'Style','edit');
    
    hmarkerA21 = uicontrol(...  
        'Parent',hpanelA2,...
        'Units','normalized',...
        'Position',[0.23 0.74 0.02 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');
    
     uicontrol(...  % text MHz(A2_1)
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.46 0.78 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'enable','off',...
        'Style','text');

     hslidA21 = uicontrol(...
        'Parent',hpanelA2,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidA,2,1},...
        'Position',[0.59 0.77 0.40 0.14],...
        'TooltipString','A2_1',...
        'Min',Amin,...
        'Max',Amax,...
        'backgroundcolor',[0.25 0.25 0.25],...
        'SliderStep',[minstepA maxstepA],...
        'enable','off',...
        'Style','slider');    

     heditA22 = uicontrol(...
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditA,2,2},...
        'FontSize',ftsz,...
        'Position',[0.23 0.51 0.23 0.2],...
        'TooltipString','A2_2',...
        'enable','off',...
        'Style','edit');
     
     hmarkerA22 = uicontrol(...  
        'Parent',hpanelA2,...
        'Units','normalized',...
        'Position',[0.23 0.51 0.02 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');

     uicontrol(...  % text MHz(A2_2)
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.46 0.55 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hslidA22 = uicontrol(...
        'Parent',hpanelA2,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidA,2,2},...
        'Position',[0.59 0.54 0.40 0.14],...
        'TooltipString','A1_2',...
        'Min',Amin,...
        'Max',Amax,...
        'backgroundcolor',[0.25 0.25 0.25],...
        'SliderStep',[minstepA maxstepA],...
        'enable','off',...
        'Style','slider');
    
     heditA23 = uicontrol(...
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditA,2,3},...
        'FontSize',ftsz,...
        'Position',[0.23 0.28 0.23 0.2],...
        'TooltipString','A2_3',...
        'enable','off',...
        'Style','edit');

    hmarkerA23 = uicontrol(...  
        'Parent',hpanelA2,...
        'Units','normalized',...
        'Position',[0.23 0.28 0.02 0.2],...
        'BackgroundColor','r',...
        'visible','off',...
        'Style','text');

     uicontrol(...  % text MHz(A2_3)
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.46 0.32 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hslidA23 = uicontrol(...
        'Parent',hpanelA2,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',{@cllbckslidA,2,3},...
        'Position',[0.59 0.31 0.40 0.14],...
        'TooltipString','A2_3',...
        'backgroundcolor',[0.25 0.25 0.25],...
        'Min',Amin,...
        'Max',Amax,...
        'SliderStep',[minstepA maxstepA],...
        'enable','off',...
        'Style','slider');
    
      uicontrol(...  % text A2_iso=
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.22 0.022 0.30 0.12],...'BackgroundColor','w',...
        'String','A_2_iso =',...
        'TooltipString','Averaged A1 value',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hA2moy = uicontrol(...  % 
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.52 0.032 0.20 0.1],...
        'TooltipString','Averaged A2 value',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      uicontrol(...  % text MHz(A2moy)
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.72 0.032 0.14 0.1],...'BackgroundColor','w',...
        'String','MHz',...
        'TooltipString','Averaged A2 value',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     uicontrol(...  % text A2 (mT)= [
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.032 0.15 0.3 0.12],...'BackgroundColor','w',...
        'String','A2(mT)= [',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');  
    
      uicontrol(...  % text ]
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.85 0.15 0.05 0.12],...'BackgroundColor','w',...
        'String',']',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');  

    hAmt21 = uicontrol(...  % 
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.32 0.16 0.18 0.1],...
        'TooltipString','A2(1) in mT',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
    hAmt22 = uicontrol(...  % 
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.51 0.16 0.18 0.1],...
        'TooltipString','A2(2) in mT',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
      hAmt23 = uicontrol(...  % 
        'Parent',hpanelA2,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.70 0.16 0.18 0.1],...
        'TooltipString','A2(3) in mT',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

%%%% ZFS  %%%%%%%
    hpanelzfs = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.6*ftsz,...
        'FontWeight','bold',...
        'Title','ZFS',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.67 0.1 0.22 0.5]);
    
     hdoczfs = uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.88 0.02 0.10 0.15],'parent',hpanelzfs,'Callback', @popupZFS,...
            'TooltipString',sprintf('ZFS rhombograms'));
    
    uicontrol(...  % text D factor
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...'BackgroundColor','w',...
        'HorizontalAlignment','right',...
        'FontSize',ftsz,...
        'Position',[-0.06 0.67 0.2 0.2],...
        'String','D =',...
        'TooltipString','D value',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
   
    heditD = uicontrol(...
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',@cllbckeditD,...
        'FontSize',ftsz,...
        'Position',[0.15 0.70 0.21 0.2],...
        'TooltipString','D factor',...
        'Style','edit','enable','off');

     uicontrol(...  % text cm-1
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.36 0.67 0.16 0.2],...'BackgroundColor','w',...
        'String','cm-1',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     hslidD = uicontrol(...
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',@cllbckslidD,...
        'Position',[0.56 0.74 0.43 0.14],...
        'Min',Dmin,...
        'Max',Dmax,...
        'SliderStep',[minstepD maxstepD],...
        'TooltipString','D value',...
        'backgroundcolor',[0.25 0.25 0.25],...
        'Style','slider','enable','off');
    
    uicontrol(...  % text E
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',... 'BackgroundColor','w',...
        'HorizontalAlignment','right',...
        'FontSize',ftsz,...
        'Position',[-0.06 0.35 0.2 0.2],...
        'String','E =',...
        'TooltipString','E value',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
   
    heditE = uicontrol(...
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',@cllbckeditE,...
        'FontSize',ftsz,...
        'Position',[0.15 0.39 0.21 0.2],...
        'TooltipString','E value',...
        'Style','edit','enable','off');

     uicontrol(...  % text cm-1
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.36 0.36 0.16 0.2],...'BackgroundColor','w',...
        'String','cm-1',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     hslidE = uicontrol(...
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'BackgroundColor',[0.9 0.9 0.9],...
        'Callback',@cllbckslidE,...
        'Position',[0.56 0.42 0.43 0.14],...
        'Min',Emin,...
        'Max',Emax,...
        'SliderStep',[minstepE maxstepE],...
        'backgroundcolor',[0.25 0.25 0.25],...
        'TooltipString','E value',...
        'Style','slider','enable','off');
    
         uicontrol(...  % text [D E] (MHz) = [
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.028 0.22 0.42 0.12],...'BackgroundColor','w',...
        'String','[D E] (MHz)= [',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');  
    
      uicontrol(...  % text ]
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.94 0.22 0.05 0.12],...'BackgroundColor','w',...
        'String',']',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

    hDMHz = uicontrol(...  % 
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.43 0.23 0.25 0.1],...
        'TooltipString','D in MHz',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
    hEMHz = uicontrol(...  % 
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.70 0.23 0.24 0.1],...
        'TooltipString','E in MHz',...
        'enable','off',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
    uicontrol(...  % text E/D=
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.28 0.08 0.25 0.12],...'BackgroundColor','w',...
        'String','E/D =',...
        'TooltipString','E/D value',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
       hEsurD = uicontrol(...  % 
        'Parent',hpanelzfs,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...'backgroundcolor','w',...
        'FontSize',ftsz,...
        'Position',[0.49 0.08 0.15 0.12],...
        'TooltipString','E/D value',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
%%%% HStrain  %%%%%%%
    hpanelHStrain = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.4*ftsz,...
        'FontWeight','bold',...
        'Title','HStrain',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.70 0.63 0.09 0.36]);  
    
   hdocHStrain = uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.68 0.04 0.28 0.2],'parent',hpanelHStrain,'Callback', @popupHStrain,...
            'TooltipString',sprintf('HStrain definition'));

    haxialHStrain = uicontrol(...
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',@cllbckaxialHStrain,...
        'FontSize',ftsz,...
        'Position',[0.05 0.04 0.5 0.2],...
        'String','Axial',...
        'TooltipString','Axial HStrain tensor',...
        'Style','pushbutton');    
    
    heditHStrain1 = uicontrol(...
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditHStrain,1},...
        'FontSize',ftsz,...
        'Position',[0.03 0.74 0.62 0.2],...
        'TooltipString','HStrain_1',...
        'Style','edit');
    
    hmarkerHStrain1 = uicontrol(...  
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'Position',[0.03 0.74 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');
    
     uicontrol(...  % text mT(HStrain_1)
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.78 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     heditHStrain2 = uicontrol(...
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditHStrain,2},...
        'FontSize',ftsz,...
        'Position',[0.03 0.51 0.62 0.2],...
        'TooltipString','HStrain_2',...
        'Style','edit');
     
     hmarkerHStrain2 = uicontrol(...  
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'Position',[0.03 0.51 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');

     uicontrol(...  % text mT(HStrain_2)
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.55 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
     heditHStrain3 = uicontrol(...
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditHStrain,3},...
        'FontSize',ftsz,...
        'Position',[0.03 0.28 0.62 0.2],...
        'TooltipString','HStrain_3',...
        'Style','edit');

    hmarkerHStrain3 = uicontrol(...  
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'Position',[0.03 0.28 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');

     uicontrol(...  % text mT(HStrain_3)
        'Parent',hpanelHStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.32 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

    %%%% gStrain  %%%%%%%
 hpanelgStrain = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.4*ftsz,...
        'FontWeight','bold',...
        'Title','gStrain',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.9 0.63 0.09 0.36]);  
    
   hdocgStrain = uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.68 0.04 0.28 0.2],'parent',hpanelgStrain,'Callback', @popupgStrain,...
            'TooltipString',sprintf('gStrain definition'));

    haxialgStrain = uicontrol(...
        'Parent',hpanelgStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',@cllbckaxialgStrain,...
        'FontSize',ftsz,...
        'Position',[0.05 0.04 0.5 0.2],...
        'String','Axial',...
        'TooltipString','Axial gStrain tensor',...
        'Style','pushbutton');    
    
    heditgStrain1 = uicontrol(...
        'Parent',hpanelgStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditgStrain,1},...
        'FontSize',ftsz,...
        'Position',[0.15 0.74 0.68 0.2],...
        'TooltipString','gStrain_1',...
        'Style','edit');
    
    hmarkergStrain1 = uicontrol(...  
        'Parent',hpanelgStrain,...
        'Units','normalized',...
        'Position',[0.15 0.74 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');

     heditgStrain2 = uicontrol(...
        'Parent',hpanelgStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditgStrain,2},...
        'FontSize',ftsz,...
        'Position',[0.15 0.51 0.68 0.2],...
        'TooltipString','gStrain_2',...
        'Style','edit');
     
     hmarkergStrain2 = uicontrol(...  
        'Parent',hpanelgStrain,...
        'Units','normalized',...
        'Position',[0.15 0.51 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');
    
     heditgStrain3 = uicontrol(...
        'Parent',hpanelgStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditgStrain,3},...
        'FontSize',ftsz,...
        'Position',[0.15 0.28 0.68 0.2],...
        'TooltipString','gStrain_3',...
        'Style','edit');

    hmarkergStrain3 = uicontrol(...  
        'Parent',hpanelgStrain,...
        'Units','normalized',...
        'Position',[0.15 0.28 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');
    
    %%%% AStrain  %%%%%%%
 hpanelAStrain = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.4*ftsz,...
        'FontWeight','bold',...
        'Title','AStrain',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.80 0.63 0.09 0.36]);  
    
   hdocAStrain = uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.68 0.04 0.28 0.20],'parent',hpanelAStrain,'Callback', @popupAStrain,...
            'TooltipString',sprintf('AStrain definition'));

    haxialAStrain = uicontrol(...
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'Callback',@cllbckaxialAStrain,...
        'FontSize',ftsz,...
        'Position',[0.05 0.04 0.5 0.2],...
        'String','Axial',...
        'TooltipString','Axial AStrain tensor',...
        'Style','pushbutton');    
    
    heditAStrain1 = uicontrol(...
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditAStrain,1},...
        'FontSize',ftsz,...
        'Position',[0.03 0.74 0.62 0.2],...
        'TooltipString','AStrain_1',...
        'Style','edit');
    
    hmarkerAStrain1 = uicontrol(...  
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'Position',[0.03 0.74 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');
    
     uicontrol(...  % text mT(AStrain_1)
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.78 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     heditAStrain2 = uicontrol(...
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditAStrain,2},...
        'FontSize',ftsz,...
        'Position',[0.03 0.51 0.62 0.2],...
        'TooltipString','AStrain_2',...
        'Style','edit');
     
     hmarkerAStrain2 = uicontrol(...  
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'Position',[0.03 0.51 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');

     uicontrol(...  % text mT(AStrain_2)
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.55 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
     heditAStrain3 = uicontrol(...
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditAStrain,3},...
        'FontSize',ftsz,...
        'Position',[0.03 0.28 0.62 0.2],...
        'TooltipString','AStrain_3',...
        'Style','edit');

    hmarkerAStrain3 = uicontrol(...  
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'Position',[0.03 0.28 0.05 0.2],...
        'BackgroundColor','r',...
        'Style','text');

     uicontrol(...  % text mT(AStrain_3)
        'Parent',hpanelAStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.32 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
    %%%% DStrain  %%%%%%%
 hpanelDStrain = uipanel(...
        'Parent',hcurrentcomp,...
        'FontUnits','pixels',...
        'FontSize',1.4*ftsz,...
        'FontWeight','bold',...
        'Title','DStrain',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Position',[0.90 0.1 0.09 0.50]);  
    
   hdocDStrain = uicontrol('Style','pushbutton','String','?','Units','Normalized','fontunits','pixels','fontsize',ftsz,...
            'pos',[0.72 0.02 0.25 0.14],'parent',hpanelDStrain,'Callback', @popupDStrain,...
            'TooltipString',sprintf('DStrain definition'));  
    
    heditDStrain1 = uicontrol(...
        'Parent',hpanelDStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditDStrain,1},...
        'FontSize',ftsz,...
        'Position',[0.03 0.71 0.62 0.16],...
        'TooltipString','DStrain_1',...
        'Style','edit');
    
     uicontrol(...  % text MHz(DStrain_1)
        'Parent',hpanelDStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.71 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');

     heditDStrain2 = uicontrol(...
        'Parent',hpanelDStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'BackgroundColor','w',...
        'Callback',{@cllbckeditDStrain,2},...
        'FontSize',ftsz,...
        'Position',[0.03 0.40 0.62 0.16],...
        'TooltipString','DStrain_2',...
        'Style','edit');

     uicontrol(...  % text MHz(DStrain_2)
        'Parent',hpanelDStrain,...
        'Units','normalized',...
        'FontUnits','pixels',...
        'HorizontalAlignment','center',...
        'FontSize',ftsz,...
        'Position',[0.65 0.40 0.35 0.14],...'BackgroundColor','w',...
        'String','MHz',...
        'foregroundcolor',[0.9 0.9 0.9],'backgroundcolor',[0.25 0.25 0.25],...
        'Style','text');
    
        hfig=hcurrentcomp; %handle=double

    componentnumber=numel(componenth)+1;
    
 % structure avec handles de la fenetre venant d'etre construite
%   tempstruct = struct('hfig',hfig,...
%     'hname',hname,'hchk',hchk,'hvisible',hvisible,'hhide',hhide,...
%     'htextweight',htextweight,'heditweight',heditweight,'htextpercent',htextpercent,...
%     'hedittime',hedittime,'hslidtime',hslidtime,...
%     'heditlorentzian',heditlorentzian,'hslidlorentzian',hslidlorentzian,'heditgaussian',heditgaussian,'hslidgaussian',hslidgaussian,...
%     'hpanelS','heditS',...
%     'hpanelg',hpanelg,'heditg',[heditg1 heditg2 heditg3],'hslidg',[hslidg1 hslidg2 hslidg3],...
%     'haxialg',haxialg','hmarkerg',[hmarkerg1 hmarkerg2 hmarkerg3],'hgmoy',hgmoy,...
%     'hpopupI',[hpopupI1 hpopupI2],'haxialA',[haxialA1 haxialA2],'heditA',[heditA11 heditA12 heditA13;heditA21 heditA22 heditA23],...
%     'hslidA',[hslidA11 hslidA12 hslidA13;hslidA21 hslidA22 hslidA23],'hAmoy',[hA1moy,hA2moy],...
%     'hpanelA',[hpanelA1 hpanelA2],'hmarkerA',[hmarkerA11 hmarkerA12 hmarkerA13;hmarkerA21 hmarkerA22 hmarkerA23]); 

  %componenth(componentnumber)=tempstruct;
    componenth(componentnumber).hfig=hfig;
    componenth(componentnumber).hname=hname;
    componenth(componentnumber).hchk=hchk;
    componenth(componentnumber).haniso=haniso;
    componenth(componentnumber).hvisible=hvisible;
    componenth(componentnumber).hhide=hhide;
    componenth(componentnumber).htextweight=htextweight;
    componenth(componentnumber).heditweight=heditweight;
    componenth(componentnumber).htextpercent=htextpercent;
    componenth(componentnumber).hpanellw=hpanellw;
    componenth(componentnumber).heditlorentzian=heditlorentzian;
    componenth(componentnumber).hslidlorentzian=hslidlorentzian;
    componenth(componentnumber).heditgaussian=heditgaussian;
    componenth(componentnumber).hslidgaussian=hslidgaussian;
    componenth(componentnumber).hpanelg=hpanelg;
    componenth(componentnumber).heditg=[heditg1 heditg2 heditg3];
    componenth(componentnumber).hslidg=[hslidg1 hslidg2 hslidg3];
    componenth(componentnumber).haxialg=haxialg;
    componenth(componentnumber).hmarkerg=[hmarkerg1 hmarkerg2 hmarkerg3];
    componenth(componentnumber).hgmoy=hgmoy;
    componenth(componentnumber).hpopupI=[hpopupI1 hpopupI2];
    componenth(componentnumber).hpanelS=hpanelS;
    componenth(componentnumber).hpopupS=hpopupS;
    componenth(componentnumber).haxialA=[haxialA1 haxialA2];
    componenth(componentnumber).heditA=[heditA11 heditA12 heditA13;heditA21 heditA22 heditA23];
    componenth(componentnumber).hslidA=[hslidA11 hslidA12 hslidA13;hslidA21 hslidA22 hslidA23];
    componenth(componentnumber).hAmoy=[hA1moy,hA2moy];
    componenth(componentnumber).hAmt=[hAmt11 hAmt12 hAmt13;hAmt21 hAmt22 hAmt23];
    componenth(componentnumber).hpanelA=[hpanelA1 hpanelA2];
    componenth(componentnumber).hmarkerA=[hmarkerA11 hmarkerA12 hmarkerA13;hmarkerA21 hmarkerA22 hmarkerA23]; 
    componenth(componentnumber).hpanelHStrain=hpanelHStrain;
    componenth(componentnumber).heditHStrain=[heditHStrain1 heditHStrain2 heditHStrain3];
    componenth(componentnumber).haxialHStrain=haxialHStrain;
    componenth(componentnumber).hmarkerHStrain=[hmarkerHStrain1 hmarkerHStrain2 hmarkerHStrain3];
    componenth(componentnumber).hpanelgStrain=hpanelgStrain;
    componenth(componentnumber).heditgStrain=[heditgStrain1 heditgStrain2 heditgStrain3];
    componenth(componentnumber).haxialgStrain=haxialgStrain;
    componenth(componentnumber).hmarkergStrain=[hmarkergStrain1 hmarkergStrain2 hmarkergStrain3];
    componenth(componentnumber).hpanelAStrain=hpanelAStrain;
    componenth(componentnumber).heditAStrain=[heditAStrain1 heditAStrain2 heditAStrain3];
    componenth(componentnumber).haxialAStrain=haxialAStrain;
    componenth(componentnumber).hmarkerAStrain=[hmarkerAStrain1 hmarkerAStrain2 hmarkerAStrain3];    
    componenth(componentnumber).hpanelzfs=hpanelzfs;
    componenth(componentnumber).heditD=heditD;
    componenth(componentnumber).hslidD=hslidD;
    componenth(componentnumber).heditE=heditE;
    componenth(componentnumber).hslidE=hslidE;
    componenth(componentnumber).hDMHz=hDMHz;
    componenth(componentnumber).hEMHz=hEMHz;    
    componenth(componentnumber).hEsurD=hEsurD;
    componenth(componentnumber).hpanelDStrain=hpanelDStrain;    
    componenth(componentnumber).heditDStrain=[heditDStrain1 heditDStrain2];    
    componenth(componentnumber).hplot=hinit; %reinitialisayion du handle de plot
end

%% Affichage d'une composante
function dispcomponent(nieme) %affichage des donnees niemes sur la figure correspondante 
  
    structdata=componentdata(nieme); %donnees a afficher
    structh=componenth(nieme); %handles correspondant
    %componenth
    figname=get(structh.hfig,'name'); %nom de la figure courante
    fignumber=str2double(figname(13:end)); % numero de la figure courante Simultispin_XX
    
    % initialisation des marqueurs d'axialite (si ils etaient present dans
    % une fenetre reutilisee)
    set(structh.hmarkerg,'visible','off');
    set(structh.hmarkerA,'visible','off');
    set(structh.hmarkerHStrain,'visible','off');
    set(structh.hmarkergStrain,'visible','off');
    set(structh.hmarkerAStrain,'visible','off');
    
    if fignumber>size(kolor,1)
        fignumberstr=num2str(fignumber);
        kolornumber=str2double(fignumberstr(end))-1;
    else
        kolornumber=fignumber;
    end
    
    set(structh.hname,'ForegroundColor',kolor(kolornumber,:));
    componentdata(nieme).color=kolor(kolornumber,:);
    if strcmp(structdata.name,'')
        componentname=['component ',num2str(fignumber)];
        componentdata(nieme).name=componentname;
    else
        componentname=structdata.name;
    end
    set(structh.hname,'string',componentname);
    
    
    set(structh.heditweight,'string',num2str(structdata.weightval));
    %set(structh.htextpercent,'string',['(=',structdata.percentstr,'%)']); 

    set(structh.hchk,'value',structdata.include);
    if structdata.include
        set(structh.hvisible,'enable','on','value',structdata.status);
        set(structh.hhide,'enable','on','value',~structdata.status);
    else
        set(structh.hvisible,'enable','off','value',structdata.status);
        set(structh.hhide,'enable','off','value',~structdata.status);
    end
    
    %chkbox strains
    set(structh.haniso,'value',structdata.anisolw); 
    lwhandles=get(structh.hpanellw,'children');
    HStrainhandles=get(structh.hpanelHStrain,'children');
    if structdata.anisolw
        set(lwhandles,'enable','off');
        set(HStrainhandles,'enable','on');
    else
        set(lwhandles,'enable','on');
        set(HStrainhandles,'enable','off');
    end
 
    set(structh.heditlorentzian,'string',num2str(structdata.lorentzianval,'%3.2f'));
    set(structh.hslidlorentzian,'value',structdata.lorentzianval);
    set(structh.heditgaussian,'string',num2str(structdata.gaussianval,'%3.2f'));
    set(structh.hslidgaussian,'value',structdata.gaussianval);
        
    for i=1:3 %g
        set(structh.heditg(i),'string',num2str(structdata.gval(i),'%6.5f'));
        set(structh.hslidg(i),'value',(structdata.gval(i)-2)*1e5);  
    end
    set(structh.hgmoy,'string',num2str(mean(structdata.gval),'%6.5f'));
    
    if ~isnan(structdata.axialcombinationg)
            for j=1:2
               set(structh.hmarkerg(structdata.axialcombinationg(j)),'visible','on');
            end
    end
    
    %structdata.Sval
    Sterm = structdata.Sval;
    Sterm = rats(Sterm);
    Sterm = strtrim(Sterm);
    set(structh.hpopupS,'value',find(ismember(differentS,Sterm)));
    
    %structdata.Istr
    for i=1:2 %A1 ou A2
        for k=1:3
            set(structh.hpopupI(i),'value',find(ismember(differentI,structdata.Istr{i}))); %donne indice (pour value) de Ii dans cellarray differentI
            if ~isnan(structdata.Aval(i,k)) 
                set(structh.hslidA(i,k),'value',structdata.Aval(i,k));
                set(structh.heditA(i,k),'string',num2str(structdata.Aval(i,k),'%3.2f'));
            else
                set(structh.hslidA(i,k),'value',Amin); %pour que le slider soit affiche meme si pas de valeur
                set(structh.heditA(i,k),'string','');
            end
            
            Amt=(structdata.Aval(i,k)*1E9 * 6.62608E-34) / (structdata.gval(k) * 9.2401E-24);
            if ~isnan(Amt)
            set(structh.hAmt(i,k),'string',num2str(Amt,'%3.2f'));
            else
            set(structh.hAmt(i,k),'string','')
            end
        end

        Amoy=mean(structdata.Aval(i,:));
        if ~isnan(Amoy)
            set(structh.hAmoy(i),'string',num2str(Amoy,'%3.2f'));
        else
            set(structh.hAmoy(i),'string','')
        end
        
        if ~isnan(structdata.axialcombinationA(i,:))
            for j=1:2
               set(structh.hmarkerA(i,structdata.axialcombinationA(i,j)),'visible','on');
            end
        end  
    end 
        for i=1:3 %gStrain
            set(structh.heditgStrain(i),'string',num2str(structdata.gStrainval(i),'%6.5f'));
        end
        
        if ~isnan(structdata.axialcombinationgStrain)
            for j=1:2
                set(structh.hmarkergStrain(structdata.axialcombinationgStrain(j)),'visible','on');
            end
        end
        
        for i=1:3 %AStrain
            set(structh.heditAStrain(i),'string',num2str(structdata.AStrainval(i),'%3.2f'));
        end
        
        if ~isnan(structdata.axialcombinationAStrain)
            for j=1:2
                set(structh.hmarkerAStrain(structdata.axialcombinationAStrain(j)),'visible','on');
            end
        end
        for i=1:3 %HStrain
            set(structh.heditHStrain(i),'string',num2str(structdata.HStrainval(i),'%3.2f'));
        end
        
        if ~isnan(structdata.axialcombinationHStrain)
            for j=1:2
                set(structh.hmarkerHStrain(structdata.axialcombinationHStrain(j)),'visible','on');
            end
        end
        
%ZFS
    if structdata.Sval < 1
        set(structh.hslidD,'enable','off');
        set(structh.heditD,'enable','off');
        set(structh.heditE,'enable','off');
        set(structh.hslidE,'enable','off');
    end
        set(structh.heditD,'string',num2str(structdata.Dval,'%4.3f'));
        set(structh.hslidD,'value',structdata.Dval);
        set(structh.heditE,'string',num2str(structdata.Eval,'%4.3f'));
        set(structh.hslidE,'value',structdata.Eval);

    set(structh.hEsurD,'string',num2str(structdata.Eval/structdata.Dval,'%3.2f'));
    
    DMHz=structdata.Dval/0.333E-4;
    EMHz=structdata.Eval/0.333E-4;
    set(structh.hDMHz,'string',num2str(DMHz,'%3.2f'));
    set(structh.hEMHz,'string',num2str(EMHz,'%3.2f'));
            
% DStrain
    DStrainhandles=get(structh.hpanelDStrain,'children');
        if structdata.Sval < 1
            set(DStrainhandles,'enable','off');
        elseif (structdata.Sval > 0.5 && structdata.anisolw == 0)
            set(DStrainhandles,'enable','off');
         elseif  any(structdata.AStrainval)~=0 | any(structdata.gStrainval(k))~=0
            %if structdata.anisolw
            set(DStrainhandles,'enable','off');
        else set(DStrainhandles,'enable','on');
    end

% g/AStrain
    gStrainhandles=get(structh.hpanelgStrain,'children');
    AStrainhandles=get(structh.hpanelAStrain,'children');
    if structdata.anisolw & structdata.DStrainval ==0
        set(gStrainhandles,'enable','on');
        set(AStrainhandles,'enable','on');
    else set(gStrainhandles,'enable','off');
           set(AStrainhandles,'enable','off');
    end
    
    for i=1:2 %DStrain
        set(structh.heditDStrain(i),'string',num2str(structdata.DStrainval(i),'%3.2f'));
    end    
    
    SysgAStrain(nieme);
    enableA(nieme); %gestion de la propriete 'enable' des A de la nieme composante
    dispweight();
    disppercent(); %affichage des %
    Syslw(nieme);
    SysD(nieme);  
    SysDStrain(nieme);
end

%% Callback function de Simultispin_X
function cllbckname(hobject,~)
    place=[componenth.hname]==hobject; %indice considere dans la structure des handles componenth
    componentdata(place).name=get(hobject,'string');
    setlegend()
    set(hlist,'value',[]);%pas de selection dans la liste
    set(hfreq,'TooltipString','');
    if ishandle(hplotsimall)
        set(hsavesimul,'enable','on');
    end
end

function cllbckchk(hobject,~) %cllbck include
        
        place=find([componenth.hchk]==hobject); %indice considere dans la structure des handles componenth

        if get(hobject,'Value')==1
            componentdata(place).include=1;
            set(componenth(place).hvisible,'enable','on');
            set(componenth(place).hhide,'enable','on');

            if isempty(get(hspecaxes,'children'))%~ishandle(hspecexp)
                set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
            end

        else
            if ishandle(componenth(place).hplot) %suppression de la simul de la composante
                delete(componenth(place).hplot)
                componenth(place).hplot=hinit;
            end
            componentdata(place).include=0;
            componentdata(place).status=0;
            set(componenth(place).hvisible,'enable','off','value',0);
            set(componenth(place).hhide,'enable','off','value',1);
        end

        if get(hrealtime,'value')==1
            if isempty(componentdata(place).specsimul)
                set(componenth(place).hchk,'value',0);
                componentdata(place).include=0;
                uiwait(msgbox({'WARNING:   This component can''t be included...';'';'You should first perform global simulation with "Run. Simul."...'},...
                 'Simultispin_WARNING','Warn','modal'));
            else
                runsimul2(hobject);%si modif des include
                dispweight();
                disppercent();              
            end
        else
           aspectbeforemanualrunsimul(place,1); %1:appel de aspect..simul depuis checkcallback
           dispweight();
           disppercent();           
        end
end

function cllbckanisolw(hobject,~) %cllbck anisolw
        
    place=find([componenth.haniso]==hobject); %indice considere dans la structure des handles componenth
     lwhandles=get(componenth(place).hpanellw,'children');
     HStrainhandles=get(componenth(place).hpanelHStrain,'children');
     gStrainhandles=get(componenth(place).hpanelgStrain,'children');
     AStrainhandles=get(componenth(place).hpanelAStrain,'children');
        if get(hobject,'Value')==1 && strcmp(componentdata(place).type,'Fast Motion')
        uiwait(msgbox({'WARNING:  Using garlic, only isotropic broadenings available...'},...
            'Simultispin_WARNING','Warn','modal'));
        set(componenth(place).haniso,'value',0);
        end
 for i=1:3        if get(hobject,'Value')==0
             componentdata(place).anisolw=0;
     		set(lwhandles,'enable','on');
         	set(componenth(place).heditlorentzian,'string',num2str(componentdata(place).lorentzianval,'%3.2f'));
         	set(componenth(place).heditgaussian,'string',num2str(componentdata(place).gaussianval,'%3.2f'));
     		set(HStrainhandles,'enable','off');
     		set(gStrainhandles,'enable','off');
     		set(AStrainhandles,'enable','off');
         else
            componentdata(place).anisolw=1;
     		set(lwhandles,'enable','off');
     		set(HStrainhandles,'enable','on');
     		set(gStrainhandles,'enable','on');
    		set(AStrainhandles,'enable','on');
         	set(componenth(place).heditHStrain(i),'string',num2str(componentdata(place).HStrainval(i),'%3.2f'));
         	set(componenth(place).heditgStrain(i),'string',num2str(componentdata(place).gStrainval(i),'%6.5f'));
         	set(componenth(place).heditAStrain(i),'string',num2str(componentdata(place).AStrainval(i),'%3.2f'));
     end
 end
    Syslw(place)
    SysDStrain(place)
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckstorepar(hobject,~) %garder parametres de la composante courante pour la suivante
    hfig=get(hobject,'parent'); %handle de la figure correspondante
    place=find([componenth.hfig]==hfig); %indice considere dans la structure des handles componenth
    componentdata(1)=componentdata(place);
    componentdata(1).name='';
    componentdata(1).weightval=1;
    componentdata(1).include=1;
    componentdata(1).status=0;
    componentdata(1).specsimul=[];
    Sys{1}=Sys{place};
    Sys{1}.weight=1;
end

function reinitcomponent(~,~) %reinitialiser parametres de la composante courante pour la suivante
    componentdata(1)=componentdatainit;
    componentdata(1).name='';
    componentdata(1).weightval=1;
    componentdata(1).include=1;
    componentdata(1).status=0;
    componentdata(1).specsimul=[];
    Sys{1}=Sysinit;
end

function visible_or_hide(hobject,~) %hobject= handle du button group
    hfig=get(hobject,'parent'); %handle de la figure correspondante
    place=find([componenth.hfig]==hfig); %indice considere dans la structure des handles componenth
    if get(componenth(place).hvisible,'value')==1
        if ishandle(componenth(place).hplot)
            set(componenth(place).hplot,'visible','on');
            componentdata(place).status=1;
        elseif isempty(componentdata(place).specsimul) % simul pas encore calculee
            set(componenth(place).hvisible,'value',0);
            set(componenth(place).hhide,'value',1);
            componentdata(place).status=0;
        else %simul loadee mais jamais affichee
            componentdata(place).status=1;
            componenth(place).hplot=plot(hspecaxes,Bsimul,scalefact*componentdata(place).specsimul,'color',componentdata(place).color,'visible','on');
        end
    else
        componentdata(place).status=0;
        set(componenth(place).hplot,'visible','off')
    end
    if ishandle(hspecexp)
      uistack(hspecexp,'top'); %spectre exp au 1er plan
    end
    setlegend();
end

function cllbckeditweight(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    place=[componenth.heditweight]==hobject; %indice considere dans la structure des handles componenth
    weight=str2double(get(hobject,'string'));
    if isnan(weight)
        weight=componentdata(1).weightval;
    end
    componentdata(place).weightval=weight;
    Sys{place}.weight=weight;
    set(hobject,'string',num2str(weight,'%3.2f')); %mise au bon format
    disppercent(); %recalcul des pourcentages
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckeditlorentzian(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    place=find([componenth.heditlorentzian]==hobject); %indice considere dans la structure des handles componenth
    lor=str2double(get(hobject,'string'));
    if isnan(lor)
        lor=componentdata(1).lorentzianval;
    end
    if componentdata(place).gaussianval==0 && lor==0 %les deux largeurs ne peuvent etre nulles en meme temps
        lor=0.00;
    end
    lor=str2double(num2str(lor,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    set(hobject,'string',num2str(lor,'%3.2f')); %mise au bon format
    componentdata(place).lorentzianval=lor;
    Syslw(place)
    set(componenth(place).hslidlorentzian, 'Value',lor); %accord slider et entree manuelle
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckslidlorentzian(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    place=find([componenth.hslidlorentzian]==hobject); %indice considere dans la structure des handles componenth
    lor=get(hobject,'value');
    if componentdata(place).gaussianval==0 && lor==0 %les deux largeurs ne peuvent etre nulles en meme temps
        lor=0.00;
        set(componenth(place).hslidlorentzian, 'Value',lor); %accord slider et entree manuelle
    end
    lor=str2double(num2str(lor,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    componentdata(place).lorentzianval=lor;
    Syslw(place)
    set(componenth(place).heditlorentzian,'string',num2str(lor,'%3.2f')); %mise au bon format
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckeditgaussian(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    place=find([componenth.heditgaussian]==hobject); %indice considere dans la structure des handles componenth
    gauss=str2double(get(hobject,'string'));
    if isnan(gauss)
        gauss=componentdata(1).gaussianval;
    end
    if componentdata(place).lorentzianval==0 && gauss==0 %les deux largeurs ne peuvent etre nulles en meme temps
        gauss=0.00;
    end
    gauss=str2double(num2str(gauss,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    set(hobject,'string',num2str(gauss,'%3.2f')); %mise au bon format
    componentdata(place).gaussianval=gauss;
    Syslw(place)
    set(componenth(place).hslidgaussian, 'Value',gauss); %accord slider et entree manuelle
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckslidgaussian(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    place=find([componenth.hslidgaussian]==hobject); %indice considere dans la structure des handles componenth
    gauss=get(hobject,'value');
    if componentdata(place).lorentzianval==0 && gauss==0 %les deux largeurs ne peuvent etre nulles en meme temps
        gauss=0.00;
        set(componenth(place).hslidgaussian, 'Value',gauss); %accord slider et entree manuelle
    end
    gauss=str2double(num2str(gauss,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    componentdata(place).gaussianval=gauss;   
    Syslw(place)
    set(componenth(place).heditgaussian,'string',num2str(gauss,'%3.2f')); %mise au bon format
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

%%%  g  %%%%
function cllbckaxialg(hobject,~)
    if get(hrealtime,'value')==0
        if ishandle(hplotsimall) %suppression de la simul totale
            delete(hplotsimall)
            hplotsimall=hinit;
            set(hsavesimul,'enable','off');
            setlegend()
            set(hfreq,'string','');
            set(hsuprsimul,'enable','off');
        end
        set(hlist,'value',[]);%pas de selection dans la liste

        hpanel=get(hobject,'parent');
        place=[componenth.hfig]==get(hpanel,'parent'); %indice considere dans la structure des handles componenth

        markerstatestr=[get(componenth(place).hmarkerg(1),'visible'),' ',... marqueurs actuel (genre 'off on on')
                        get(componenth(place).hmarkerg(2),'visible'),' ',...
                        get(componenth(place).hmarkerg(3),'visible')];
        possibility=find(strcmp(markerstatestr,markerstatepossy)); %numero de ligne dans markerstatepossy
        if possibility==4
            nextpossibility=1;
        else
            nextpossibility=possibility+1;
        end
        nextpossibilitystr=markerstatepossy{nextpossibility};
        indspace=strfind(nextpossibilitystr,' '); %indice des espaces dans str ('on off on' par ex)=>indspace a 2 elements
        nextpossibility_cell={nextpossibilitystr(1:indspace(1)-1) ...
                              nextpossibilitystr(indspace(1)+1:indspace(2)-1)... 'on off on'=>{'on' 'off' 'on'}
                              nextpossibilitystr(indspace(2)+1:end)};
        %axialcombinationg
       [~,onpos]=ismember(nextpossibility_cell,{'on'}); % cas 'off off off'=> onpos=[0 0 0]
       if sum(onpos)==0
           componentdata(place).axialcombinationg=[NaN NaN];
       else
           componentdata(place).axialcombinationg=find(onpos);
       end
       %disp(componentdata(place).axialcombinationg)
        for k=1:3
            set(componenth(place).hmarkerg(k),'visible',nextpossibility_cell{k});             
        end 
    else
        uiwait(msgbox({'WARNING:   "Real time" mode selected...';'';'Quit "Real time" first...'},...
            'Simultispin_WARNING','Warn','modal'));
   end    
end

function cllbckeditg(hobject,~,k)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hpanelg]==hpanel); %indice considere dans la structure des handles componenth
    g=str2double(get(hobject,'string'));
    if isnan(g)
        g=componentdata(1).gval(1);
    else
        g=str2double(num2str(g,'%6.5f')); %correspondance exacte entre affichage et valeur en memoire
    end
    poseq=componentdata(place).axialcombinationg; %positions x y / gx=gy (si non NaN)
    
    if ~ismember(k,poseq)
        if isnan(g)
            g=componentdata(1).gval(k);
        else
            set(hobject,'string',num2str(g,'%6.5f')); %mise au bon format
            set(componenth(place).hslidg(k), 'Value',g); %accord slider et entree manuelle
        end
        componentdata(place).gval(k)=g;%sauvegarde
        Sys{place}.g(k)=g;
        set(componenth(place).hslidg(k), 'Value',(g-2)*1e5); %accord slider et entree manuelle
    else
        for j=1:2 %donnees axiales donc 2 affichages
            if isnan(g)
                g=componentdata(1).gval(poseq(j));
            end
            set(componenth(place).heditg(poseq(j)),'string',num2str(g,'%6.5f')); 
            set(componenth(place).hslidg(poseq(j)),'value',(g-2)*1e5); %pour que le slider soit affiche meme si pas de valeur
            componentdata(place).gval(poseq(j))=g;%sauvegarde
            Sys{place}.g(poseq(j))=g;
        end 
    end
    dispgmoy(place);
    for i=1:2
        for m=1:3
    dispAmt(componenth(place).hAmt(i,m),componentdata(place).Aval(i,m),componentdata(place).gval(m)); %affichage de Amt,sur uicontrol de handle hAmt
        end
    end
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        if ~isequal(componentdata(place).gval,[2.00000 2.00000 2.00000])
            runsimul(hobject)
        end
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckslidg(hobject,~,k)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hpanelg]==hpanel); %indice considere dans la structure des handles componenth
    g=2+1e-5*get(hobject,'value');
    g=str2double(num2str(g,'%6.5f')); %correspondance exacte entre affichage et valeur en memoire
    poseq=componentdata(place).axialcombinationg; %positions x y / gx=gy (si non NaN)
    if ~ismember(k,poseq)
        componentdata(place).gval(k)=g;
        Sys{place}.g(k)=g;
        set(componenth(place).heditg(k),'string',num2str(g,'%6.5f')); %mise au bon format
    else
        for j=1:2
            set(componenth(place).hslidg(poseq(j)),'value',(g-2)*1e5);
            componentdata(place).gval(poseq(j))=g;%correspondance exacte entre affichage et valeur en memoire
            Sys{place}.g(poseq(j))=g;
            set(componenth(place).heditg(poseq(j)),'string',num2str(g,'%6.5f')); %mise au bon format

        end
    end

    dispgmoy(place);
    for i=1:2
        for m=1:3
    dispAmt(componenth(place).hAmt(i,m),componentdata(place).Aval(i,m),componentdata(place).gval(m)); %affichage de Amt,sur uicontrol de handle hAmt
        end
    end
    if get(hrealtime,'value')==1 && componentdata(place).include==1
       % if ~isequal(componentdata(place).gval,[2.00000 2.00000 2.00000])
            runsimul(hobject)
       % end
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

%%% S %%%
function cllbckpopupS(hobject,~)
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent')); %indice considere dans la structure des handles componenth
    Sval=differentS(get(hobject,'value'));
    Sval=str2num(cell2mat(Sval));
    if Sval > 0.5 && strcmp(componentdata(place).type,'Fast Motion')
        uiwait(msgbox({'WARNING:  Using garlic, S = 1/2 only...'},...
            'Simultispin_WARNING','Warn','modal'));
        Sterm = 0.5;
        Sterm = rats(Sterm);
        Sterm = strtrim(Sterm);
        set(componenth(place).hpopupS,'value',find(ismember(differentS,Sterm)));
        Sval=differentS(get(hobject,'value'));
        Sval=str2num(cell2mat(Sval));
    end
    componentdata(place).Sval=Sval;
    Sys{place}.S=Sval;
    SysD(place)
    SysDStrain(place)
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

%%% A %%%
function cllbckpopupI(hobject,~,i)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent')); %indice considere dans la structure des handles componenth
    Istr=differentI(get(hobject,'value'));
    componentdata(place).Istr{i}=Istr;
    enableA(place); %gestion de la propriete 'enable' des A
    SysAetNucs(place); %gestion des champs A et Nucs de Sys pour simul easyspin
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        if ~strcmp(Istr,'') 
            if isempty(find(isnan(componentdata(place).Aval(i,:)), 1))
                runsimul(hobject)
            end
        else
            runsimul(hobject)
        end
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end
 
function cllbckaxialA(hobject,~,i)
    if get(hrealtime,'value')==0
        if ishandle(hplotsimall) %suppression de la simul totale
            delete(hplotsimall)
            hplotsimall=hinit;
            set(hsavesimul,'enable','off');
            setlegend()
            set(hfreq,'string','');
            set(hsuprsimul,'enable','off');
        end
        set(hlist,'value',[]);%pas de selection dans la liste
        hpanel=get(hobject,'parent');
        place=[componenth.hfig]==get(hpanel,'parent'); %indice considere dans la structure des handles componenth

        markerstatestr=[get(componenth(place).hmarkerA(i,1),'visible'),' ',... marqueurs actuel (genre 'off on on')
                        get(componenth(place).hmarkerA(i,2),'visible'),' ',...
                        get(componenth(place).hmarkerA(i,3),'visible')];
        possibility=find(strcmp(markerstatestr,markerstatepossy)); %numero de ligne dans markerstatepossy
        if possibility==4
            nextpossibility=1;
        else
            nextpossibility=possibility+1;
        end
        nextpossibilitystr=markerstatepossy{nextpossibility};
        indspace=strfind(nextpossibilitystr,' '); %indice des espaces dans str ('on off on' par ex)=>indspace a 2 elements
        nextpossibility_cell={nextpossibilitystr(1:indspace(1)-1) ...
                              nextpossibilitystr(indspace(1)+1:indspace(2)-1)... 'on off on'=>{'on' 'off' 'on'}
                              nextpossibilitystr(indspace(2)+1:end)};
        %axialcombinationA
       [~,onpos]=ismember(nextpossibility_cell,{'on'}); % cas 'off off off'=> onpos=[0 0 0]
       if sum(onpos)==0
           componentdata(place).axialcombinationA(i,:)=[NaN NaN];
       else
           componentdata(place).axialcombinationA(i,:)=find(onpos);
       end
       %disp(componentdata(place).axialcombinationA)
        for k=1:3
            set(componenth(place).hmarkerA(i,k),'visible',nextpossibility_cell{k});             
        end
   else
        uiwait(msgbox({'WARNING:   "Real time" mode selected...';'';'Quit "Real time" first...'},...
            'Simultispin_WARNING','Warn','modal'));
   end
end

function cllbckeditA(hobject,~,i,k) %couplage i coordonnee k
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent')); %indice considere dans la structure des handles componenth
    A=str2double(get(hobject,'string'));
    if isnan(A)
        A=componentdata(1).Aval(1);
    else
        A=str2double(num2str(A,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    end

    poseq=componentdata(place).axialcombinationA(i,:); %positions x y / Ax=Ay (si non NaN)
    
    if ~ismember(k,poseq)
        if isnan(A)
            A=componentdata(1).Aval(i,k);
            set(hobject,'string',''); 
            set(componenth(place).hslidA(i,k),'value',Amin); %pour que le slider soit affiche meme si pas de valeur
        else
            set(hobject,'string',num2str(A,'%3.2f')); %mise au bon format
            set(componenth(place).hslidA(i,k), 'Value',A); %accord slider et entree manuelle
        end
        componentdata(place).Aval(i,k)=A;%sauvegarde
    else
        for j=1:2 %donnees axiales donc 2 affichages
            if isnan(A)
                A=componentdata(1).Aval(i,poseq(j));
                set(componenth(place).heditA(i,poseq(j)),'string',''); 
                set(componenth(place).hslidA(i,poseq(j)),'value',Amin); %pour que le slider soit affiche meme si pas de valeur
                
            else
                set(componenth(place).heditA(i,poseq(j)),'string',num2str(A,'%3.2f')); %mise au bon format
                set(componenth(place).hslidA(i,poseq(j)), 'Value',A); %accord slider et entree manuelle
            end
            componentdata(place).Aval(i,poseq(j))=A;%sauvegarde
        end
    end
    
    dispAmoy(componenth(place).hAmoy(i),componentdata(place).Aval(i,:)); %affichage de Amoy,sur uicontrol de handle hAmoy
    for m=1:3
    dispAmt(componenth(place).hAmt(i,m),componentdata(place).Aval(i,m),componentdata(place).gval(m)); %affichage de Amt,sur uicontrol de handle hAmt
    end
    enableA(place); %gestion de la propriete 'enable' des A
    SysAetNucs(place); %gestion des champs A et Nucs de Sys pour simul easyspin
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        if ~strcmp(componentdata(place).Istr{i},'') && isempty(find(isnan(componentdata(place).Aval(i,:)), 1))
            runsimul(hobject)
        end
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckslidA(hobject,~,i,k) %couplage i coordonnee k
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent')); %indice considere dans la structure des handles componenth
    A=get(hobject,'value');
    poseq=componentdata(place).axialcombinationA(i,:); %positions x y / Ax=Ay (si non NaN)
    if ~ismember(k,poseq)
        componentdata(place).Aval(i,k)=str2double(num2str(A,'%3.2f'));%correspondance exacte entre affichage et valeur en memoire
        set(componenth(place).heditA(i,k),'string',num2str(A,'%3.2f')); %mise au bon format
    else
        for j=1:2
            set(componenth(place).hslidA(i,poseq(j)),'value',A);
            componentdata(place).Aval(i,poseq(j))=str2double(num2str(A,'%3.2f'));%correspondance exacte entre affichage et valeur en memoire
            set(componenth(place).heditA(i,poseq(j)),'string',num2str(A,'%3.2f')); %mise au bon format
        end
    end
    dispAmoy(componenth(place).hAmoy(i),componentdata(place).Aval(i,:)); %affichage de Amoy,sur uicontrol de handle hAmoy
    for m=1:3
    dispAmt(componenth(place).hAmt(i,m),componentdata(place).Aval(i,m),componentdata(place).gval(m)); %affichage de Amt,sur uicontrol de handle hAmoy
    end
    enableA(place); %gestion de la propriete 'enable' des A
    SysAetNucs(place); %gestion des champs A et Nucs de Sys pour simul easyspin
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        if ~strcmp(componentdata(place).Istr{i},'') && isempty(find(isnan(componentdata(place).Aval(i,:)), 1))
            runsimul(hobject)
        end
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

%%%  HStrain  %%%%
function cllbckaxialHStrain(hobject,~)
    if get(hrealtime,'value')==0
        if ishandle(hplotsimall) %suppression de la simul totale
            delete(hplotsimall)
            hplotsimall=hinit;
            set(hsavesimul,'enable','off');
            setlegend()
            set(hfreq,'string','');
            set(hsuprsimul,'enable','off');
        end
        set(hlist,'value',[]);%pas de selection dans la liste

        hpanel=get(hobject,'parent');
        place=[componenth.hfig]==get(hpanel,'parent'); %indice considere dans la structure des handles componenth

        markerstatestr=[get(componenth(place).hmarkerHStrain(1),'visible'),' ',... marqueurs actuel (genre 'off on on')
                        get(componenth(place).hmarkerHStrain(2),'visible'),' ',...
                        get(componenth(place).hmarkerHStrain(3),'visible')];
        possibility=find(strcmp(markerstatestr,markerstatepossy)); %numero de ligne dans markerstatepossy
        if possibility==4
            nextpossibility=1;
        else
            nextpossibility=possibility+1;
        end
        nextpossibilitystr=markerstatepossy{nextpossibility};
        indspace=strfind(nextpossibilitystr,' '); %indice des espaces dans str ('on off on' par ex)=>indspace a 2 elements
        nextpossibility_cell={nextpossibilitystr(1:indspace(1)-1)...
                              nextpossibilitystr(indspace(1)+1:indspace(2)-1)... 'on off on'=>{'on' 'off' 'on'}
                              nextpossibilitystr(indspace(2)+1:end)};
        %axialcombinationHStrain
       [~,onpos]=ismember(nextpossibility_cell,{'on'}); % cas 'off off off'=> onpos=[0 0 0]
       if sum(onpos)==0
           componentdata(place).axialcombinationHStrain=[NaN NaN];
       else
           componentdata(place).axialcombinationHStrain=find(onpos);
       end
       %disp(componentdata(place).axialcombinationHStrain)
        for k=1:3
            set(componenth(place).hmarkerHStrain(k),'visible',nextpossibility_cell{k});             
        end 
    else
        uiwait(msgbox({'WARNING:   "Real time" mode selected...';'';'Quit "Real time" first...'},...
            'Simultispin_WARNING','Warn','modal'));
   end    
end

function cllbckeditHStrain(hobject,~,k)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hpanelHStrain]==hpanel); %indice considere dans la structure des handles componenth
    HStrain=str2double(get(hobject,'string'));
    if isnan(HStrain)
        HStrain=componentdata(1).HStrainval(1);
    else
        HStrain=str2double(num2str(HStrain,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    end
    poseq=componentdata(place).axialcombinationHStrain; %positions x y / gx=gy (si non NaN)
    
    if ~ismember(k,poseq)
        if isnan(HStrain)
            HStrain=componentdata(1).HStrainval(k);
        else
            set(hobject,'string',num2str(HStrain,'%3.2f')); %mise au bon format
        end
        componentdata(place).HStrainval(k)=HStrain;%sauvegarde
    else
        for j=1:2 %donnees axiales donc 2 affichages
            if isnan(HStrain)
                HStrain=componentdata(1).HStrainval(poseq(j));
            end
            set(componenth(place).heditHStrain(poseq(j)),'string',num2str(HStrain,'%3.2f')); 
            componentdata(place).HStrainval(poseq(j))=HStrain;%sauvegarde
        end 
    end
    Syslw(place) 
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

%%%  gStrain  %%%%
function cllbckaxialgStrain(hobject,~)
    if get(hrealtime,'value')==0
        if ishandle(hplotsimall) %suppression de la simul totale
            delete(hplotsimall)
            hplotsimall=hinit;
            set(hsavesimul,'enable','off');
            setlegend()
            set(hfreq,'string','');
            set(hsuprsimul,'enable','off');
        end
        set(hlist,'value',[]);%pas de selection dans la liste

        hpanel=get(hobject,'parent');
        place=[componenth.hfig]==get(hpanel,'parent'); %indice considere dans la structure des handles componenth

        markerstatestr=[get(componenth(place).hmarkergStrain(1),'visible'),' ',... marqueurs actuel (genre 'off on on')
                        get(componenth(place).hmarkergStrain(2),'visible'),' ',...
                        get(componenth(place).hmarkergStrain(3),'visible')];
        possibility=find(strcmp(markerstatestr,markerstatepossy)); %numero de ligne dans markerstatepossy
        if possibility==4
            nextpossibility=1;
        else
            nextpossibility=possibility+1;
        end
        nextpossibilitystr=markerstatepossy{nextpossibility};
        indspace=strfind(nextpossibilitystr,' '); %indice des espaces dans str ('on off on' par ex)=>indspace a 2 elements
        nextpossibility_cell={nextpossibilitystr(1:indspace(1)-1)...
                              nextpossibilitystr(indspace(1)+1:indspace(2)-1)... 'on off on'=>{'on' 'off' 'on'}
                              nextpossibilitystr(indspace(2)+1:end)};
        %axialcombinationgStrain
       [~,onpos]=ismember(nextpossibility_cell,{'on'}); % cas 'off off off'=> onpos=[0 0 0]
       if sum(onpos)==0
           componentdata(place).axialcombinationgStrain=[NaN NaN];
       else
           componentdata(place).axialcombinationgStrain=find(onpos);
       end
       %disp(componentdata(place).axialcombinationgStrain)
        for k=1:3
            set(componenth(place).hmarkergStrain(k),'visible',nextpossibility_cell{k});             
        end 
    else
        uiwait(msgbox({'WARNING:   "Real time" mode selected...';'';'Quit "Real time" first...'},...
            'Simultispin_WARNING','Warn','modal'));
   end    
end

function cllbckeditgStrain(hobject,~,k)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hpanelgStrain]==hpanel); %indice considere dans la structure des handles componenth
    gStrain=str2double(get(hobject,'string'));
    if isnan(gStrain)
        gStrain=componentdata(1).gStrainval(1);
    else
        gStrain=str2double(num2str(gStrain,'%6.5f')); %correspondance exacte entre affichage et valeur en memoire
    end
    poseq=componentdata(place).axialcombinationgStrain; %positions x y / gx=gy (si non NaN)
    
    if ~ismember(k,poseq)
        if isnan(gStrain)
            gStrain=componentdata(1).gStrainval(k);
        else
            set(hobject,'string',num2str(gStrain,'%6.5f')); %mise au bon format
        end
        componentdata(place).gStrainval(k)=gStrain;%sauvegarde
    else
        for j=1:2 %donnees axiales donc 2 affichages
            if isnan(gStrain)
                gStrain=componentdata(1).gStrainval(poseq(j));
            end
            set(componenth(place).heditgStrain(poseq(j)),'string',num2str(gStrain,'%6.5f')); 
            componentdata(place).gStrainval(poseq(j))=gStrain;%sauvegarde
        end 
    end
    SysgAStrain(place)  
    SysDStrain(place) 
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end 
end

%%%  AStrain  %%%%
function cllbckaxialAStrain(hobject,~)
    if get(hrealtime,'value')==0
        if ishandle(hplotsimall) %suppression de la simul totale
            delete(hplotsimall)
            hplotsimall=hinit;
            set(hsavesimul,'enable','off');
            setlegend()
            set(hfreq,'string','');
            set(hsuprsimul,'enable','off');
        end
        set(hlist,'value',[]);%pas de selection dans la liste

        hpanel=get(hobject,'parent');
        place=[componenth.hfig]==get(hpanel,'parent'); %indice considere dans la structure des handles componenth

        markerstatestr=[get(componenth(place).hmarkerAStrain(1),'visible'),' ',... marqueurs actuel (genre 'off on on')
                        get(componenth(place).hmarkerAStrain(2),'visible'),' ',...
                        get(componenth(place).hmarkerAStrain(3),'visible')];
        possibility=find(strcmp(markerstatestr,markerstatepossy)); %numero de ligne dans markerstatepossy
        if possibility==4
            nextpossibility=1;
        else
            nextpossibility=possibility+1;
        end
        nextpossibilitystr=markerstatepossy{nextpossibility};
        indspace=strfind(nextpossibilitystr,' '); %indice des espaces dans str ('on off on' par ex)=>indspace a 2 elements
        nextpossibility_cell={nextpossibilitystr(1:indspace(1)-1)...
                              nextpossibilitystr(indspace(1)+1:indspace(2)-1)... 'on off on'=>{'on' 'off' 'on'}
                              nextpossibilitystr(indspace(2)+1:end)};
        %axialcombinationAStrain
       [~,onpos]=ismember(nextpossibility_cell,{'on'}); % cas 'off off off'=> onpos=[0 0 0]
       if sum(onpos)==0
           componentdata(place).axialcombinationAStrain=[NaN NaN];
       else
           componentdata(place).axialcombinationAStrain=find(onpos);
       end
       %disp(componentdata(place).axialcombinationAStrain)
        for k=1:3
            set(componenth(place).hmarkerAStrain(k),'visible',nextpossibility_cell{k});             
        end 
    else
        uiwait(msgbox({'WARNING:   "Real time" mode selected...';'';'Quit "Real time" first...'},...
            'Simultispin_WARNING','Warn','modal'));
   end    
end

function cllbckeditAStrain(hobject,~,k)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hpanelAStrain]==hpanel); %indice considere dans la structure des handles componenth
    AStrain=str2double(get(hobject,'string'));
    if isnan(AStrain)
        AStrain=componentdata(1).AStrainval(1);
    else
        AStrain=str2double(num2str(AStrain,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    end
    poseq=componentdata(place).axialcombinationAStrain; %positions x y / gx=gy (si non NaN)
    
    if ~ismember(k,poseq)
        if isnan(AStrain)
            AStrain=componentdata(1).AStrainval(k);
        else
            set(hobject,'string',num2str(AStrain,'%3.2f')); %mise au bon format
        end
        componentdata(place).AStrainval(k)=AStrain;%sauvegarde
    else
        for j=1:2 %donnees axiales donc 2 affichages
            if isnan(AStrain)
                AStrain=componentdata(1).AStrainval(poseq(j));
            end
            set(componenth(place).heditAStrain(poseq(j)),'string',num2str(AStrain,'%3.2f')); 
            componentdata(place).AStrainval(poseq(j))=AStrain;%sauvegarde
        end 
    end
    SysgAStrain(place)   
    SysDStrain(place) 
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

%ZFS%
function cllbckeditD(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent'));
    D=str2double(get(hobject,'string'));
    D=str2double(num2str(D,'%4.3f')); %correspondance exacte entre affichage et valeur en memoire
    set(hobject,'string',num2str(D,'%4.3f')); %mise au bon format
    componentdata(place).Dval=D;
    set(componenth(place).hslidD,'Value',D); %accord slider et entree manuelle
    dispEsurD(place)
    dispzfs(componenth(place).hDMHz, componenth(place).hEMHz,componentdata(place).Dval,componentdata(place).Eval)
    SysD(place)
    if get(hrealtime,'value')==1 && componentdata(place).include==1
            runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckslidD(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent'));
    D=get(hobject,'value');
    D=str2double(num2str(D,'%4.3f')); %correspondance exacte entre affichage et valeur en memoire
    componentdata(place).Dval=D;
    Sys{place}.D(1)=D/0.333E-4;
    set(componenth(place).heditD,'string',num2str(D,'%4.3f')); %mise au bon format
    dispEsurD(place);
    dispzfs(componenth(place).hDMHz, componenth(place).hEMHz,componentdata(place).Dval,componentdata(place).Eval)
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckeditE(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent'));
    E=str2double(get(hobject,'string'));
    E=str2double(num2str(E,'%4.3f')); %correspondance exacte entre affichage et valeur en memoire
    set(hobject,'string',num2str(E,'%4.3f')); %mise au bon format
    componentdata(place).Eval=E;
    set(componenth(place).hslidE,'Value',E); %accord slider et entree manuelle
    dispEsurD(place)
    SysD(place)
    dispzfs(componenth(place).hDMHz, componenth(place).hEMHz,componentdata(place).Dval,componentdata(place).Eval)
    if get(hrealtime,'value')==1 && componentdata(place).include==1
            runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckslidE(hobject,~)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hfig]==get(hpanel,'parent'));
    E=get(hobject,'value');
    E=str2double(num2str(E,'%4.3f')); %correspondance exacte entre affichage et valeur en memoire
    componentdata(place).Eval=E;
    Sys{place}.D(2)=E/0.333E-4;
    set(componenth(place).heditE,'string',num2str(E,'%4.3f')); %mise au bon format
    dispEsurD(place);
    dispzfs(componenth(place).hDMHz, componenth(place).hEMHz,componentdata(place).Dval,componentdata(place).Eval)
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function cllbckeditDStrain(hobject,~,k)
    %set(hlist,'value',[]);%pas de selection dans la liste
    hpanel=get(hobject,'parent');
    place=find([componenth.hpanelDStrain]==hpanel); %indice considere dans la structure des handles componenth
    DStrain=str2double(get(hobject,'string'));
    if isnan(DStrain)
        DStrain=componentdata(1).DStrainval(1);
    else
        DStrain=str2double(num2str(DStrain,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    end
    set(hobject,'string',num2str(DStrain,'%3.2f')); %mise au bon format
    componentdata(place).DStrainval(k)=DStrain;
    SysDStrain(place) 
    SysgAStrain(place)
    if get(hrealtime,'value')==1 && componentdata(place).include==1
        runsimul(hobject)
    else 
        aspectbeforemanualrunsimul(place,0);
    end
end

function  aspectbeforemanualrunsimul(place,fromchk)
   
    if componentdata(place).include || fromchk
        set(hrunsimul,'enable','on')
        if ishandle(componenth(place).hplot) %suppression de la simul de la composante
            delete(componenth(place).hplot);
            componenth(place).hplot=hinit;
            
            componentdata(place).status=0;
            set(componenth(place).hhide,'value',1);
            set(componenth(place).hvisible,'value',0);
        end
        if ishandle(hplotsimall) %suppression de la simul totale
            delete(hplotsimall)
            hplotsimall=hinit;
            %dispsimulfreq=NaN;
            set(hfitindicator,'visible','off');
            set(hsavesimul,'enable','off');
            setlegend()
            set(hsuprsimul,'enable','off');
            set(hlist,'value',[]);%pas de selection dans la liste
            set(hfreq,'TooltipString','');
            if runsim %=> 1 simul a ete lancee
              set(hcurrentsimul,'enable','on'); 
            end

        end
    end
end

%% AUTRES FONCTIONS

function dispweight() %affichage ou pas des editbox
        componentnumber=numel(componenth);
        if componentnumber>2 %pour affichage pourcentage
            componentnumberincluded=sum([componentdata.include])-1; %componentdata(1) = initialisation
            if componentnumberincluded>1
                for i=2:componentnumber %componentnumber(1)=empty
                    if componentdata(i).include==1
                        set(componenth(i).htextweight,'visible','on');
                        set(componenth(i).heditweight,'visible','on');
                        set(componenth(i).htextpercent,'visible','on');
                    else
                        set(componenth(i).htextweight,'visible','off');
                        set(componenth(i).heditweight,'visible','off');
                        set(componenth(i).htextpercent,'visible','off'); 
                    end
                end
            else
                for i=2:componentnumber %componentnumber(1)=empty
                    set(componenth(i).htextweight,'visible','off');
                    set(componenth(i).heditweight,'visible','off');
                    set(componenth(i).htextpercent,'visible','off'); 
                end
            end           
        else
            set(componenth(2).htextweight,'visible','off');
            set(componenth(2).heditweight,'visible','off');
            set(componenth(2).htextpercent,'visible','off');            
        end
        
end 

function disppercent() %calcul des pourcentages
    numcomp=numel(componenth);
    numcompincluded=sum([componentdata.include])-1; %componentdata(1) = initialisation
  
    if numcompincluded>1 %au moins 2 composantes
        k=1;
        for i=2:numcomp
            if componentdata(i).include==1
                    %componentdata(i).weightval
                Spercent(k)=struct('h',componenth(i).htextpercent,'weight',componentdata(i).weightval); %structure avec handle et poids
                k=k+1;               
            end
        end
        weighttot=sum([Spercent.weight]); %<=>100
        for k=1:numel(Spercent)
            set(Spercent(k).h,'string',['(',num2str(100*Spercent(k).weight/weighttot,'%3.1f'),'%)']);
        end
    else       
    end
end
    
function Syslw(nieme)
    data=componentdata(nieme);
    if isfield(Sys{nieme},{'lw','HStrain'}) 
        Sys{nieme}=rmfield(Sys{nieme},{'lw','HStrain'});
    end
	if componentdata(nieme).anisolw==1
		Sys{nieme}.HStrain=data.HStrainval;
        if isfield(Sys{nieme},{'lw'})
        	Sys{nieme}=rmfield(Sys{nieme},{'lw'});  
        end   
	else 	
		Sys{nieme}.lw(1)=data.gaussianval;
		Sys{nieme}.lw(2)=data.lorentzianval;
        if isfield(Sys{nieme},{'HStrain'}) %,'gStrain','AStrain'
         	Sys{nieme}=rmfield(Sys{nieme},{'HStrain'}); %,'gStrain','AStrain'
        end
    end 
    if componentdata(nieme).HStrainval==0
        if isfield(Sys{nieme},{'HStrain'})
            Sys{nieme}=rmfield(Sys{nieme},{'HStrain'});
        end
    end
end

function dispgmoy(nieme) % %affichage de gmoyen de la nieme composante
    gmoy=mean(componentdata(nieme).gval);
    set(componenth(nieme).hgmoy,'string',num2str(gmoy,'%6.5f'));%affichage
end

function SysAetNucs(nieme) %gestion des champs A et Nucs de Sys{nieme} pour simul easyspin
    if isfield(Sys{nieme},{'A','Nucs'})
        Sys{nieme}=rmfield(Sys{nieme},{'A','Nucs'}); %par defaut pas de couplage
    end
    data=componentdata(nieme);
    if ~strcmp(data.Istr{1},'') & ~isnan(data.Aval(1,:)) %s'il existe un premier couplage (I et A definis) (& et pas &&)
        if isnan(data.Aval(2,:)) | strcmp(data.Istr{2},'') %sans 2e couplage (| et pas ||)
            Sys{nieme}.Nucs=differentNucs{ismember(differentI,data.Istr{1})}; 
            Sys{nieme}.A=(data.Aval(1,:));
        else
            Sys{nieme}.Nucs=[differentNucs{ismember(differentI,data.Istr{1})},',',differentNucs{ismember(differentI,data.Istr{2})}];
            Sys{nieme}.A=(data.Aval);
        end
    end
end

function enableA(nieme) %gestion de la propriete 'enable' des A de la nieme composante
    A1handles=get(componenth(nieme).hpanelA(1),'children'); %tous les handles du panel A1 considere
    A1handles(A1handles==componenth(nieme).hpopupI(1))=[]; %suppression du handle de popupI1
    
    A2handles=get(componenth(nieme).hpanelA(2),'children'); %tous les handles du panel A2 considere
    A2handles(A2handles==componenth(nieme).hpopupI(2))=[]; %suppression du handle de popupI2
    if strcmp(componentdata(nieme).Istr{1},'') %pas de couplage hyperfin
       set(A1handles,'enable','off');
       set(componenth(nieme).hpopupI(2),'enable','off');
       set(A2handles,'enable','off');
    else 
       set(A1handles,'enable','on');
       if ~isnan(componentdata(nieme).Aval(1,:))
           set(componenth(nieme).hpopupI(2),'enable','on');
           if strcmp(componentdata(nieme).Istr{2},'') %pas de 2nd couplage hyperfin
                set(A2handles,'enable','off');
           else
                 set(A2handles,'enable','on');
           end
       else
           set(componenth(nieme).hpopupI(2),'enable','off');
           set(A2handles,'enable','off');
       end
    end         
end

function dispAmoy(hAmoy,A) % %affichage de Amoy,sur uicontrol de handle hAmoy
    Amoy=mean(A);
    if ~isnan(Amoy) %s'il existe bien 3 composantes
        Amoy=str2double(num2str(Amoy,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
        set(hAmoy,'string',num2str(Amoy,'%3.2f')); %affichage sur handle qui va bien
    else
        set(hAmoy,'string',''); %affichage sur handle qui va bien
    end   
end

function dispAmt(hAmt,A,g) % %affichage de Amt sur uicontrol de handle hAmt
    Amt=(A*1E9 * 6.62608E-34) / (g * 9.2401E-24);
    if ~isnan(Amt) %s'il existe bien 3 composantes
        Amt=str2double(num2str(Amt,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
        set(hAmt,'string',num2str(Amt,'%3.2f')); %affichage sur handle qui va bien
    else
        set(hAmt,'string',''); %affichage sur handle qui va bien
    end   
end

function dispzfs(hDMHz, hEMHz,D,E) % affichage [D E] en MHz sur panel zfs
    DMHz=D/0.333E-4;
    EMHz=E/0.333E-4;
    DMHz=str2double(num2str(DMHz,'%3.2f')); %correspondance exacte entre affichage et valeur en memoire
    EMHz=str2double(num2str(EMHz,'%3.2f'));
    set(hDMHz,'string',num2str(DMHz,'%3.2f')); %affichage sur handle qui va bien
    set(hEMHz,'string',num2str(EMHz,'%3.2f')); %affichage sur handle qui va bien
end

function SysD(nieme) %gestion SysD pour simul easyspin
    data=componentdata(nieme);
    Sval=componentdata(nieme).Sval;
    zfshandles=get(componenth(nieme).hpanelzfs,'children');
    if Sval <1
        set(zfshandles,'enable','off')
        if isfield(Sys{nieme},'D')  %|| Sval < 1  || isnan(data.Dval)
            Sys{nieme}=rmfield(Sys{nieme},'D');
        end
    elseif data.Dval==0 && data.Eval==0 %isfield(Sys{nieme},'D')
        set(zfshandles,'enable','on')
        set(componenth(nieme).heditD,'string',num2str(componentdata(nieme).Dval,'%4.3f'));
        set(componenth(nieme).heditE,'string',num2str(componentdata(nieme).Eval,'%4.3f'));
        if isfield(Sys{nieme},'D')
            Sys{nieme}=rmfield(Sys{nieme},'D');
        end
    else  set(zfshandles,'enable','on')
        set(componenth(nieme).heditD,'string',num2str(componentdata(nieme).Dval,'%4.3f'));
        set(componenth(nieme).heditE,'string',num2str(componentdata(nieme).Eval,'%4.3f'));
        Sys{nieme}.D(1)=(data.Dval)/0.333E-4;
        Sys{nieme}.D(2)=(data.Eval)/0.333E-4;
    end
end

function dispEsurD(nieme) % %affichage de EsurD de la nieme composante
    EsurD=componentdata(nieme).Eval/componentdata(nieme).Dval;
    set(componenth(nieme).hEsurD,'string',num2str(EsurD,'%6.5f'));%affichage
end

function SysDStrain(nieme) %gestion SysDStrain pour simul easyspin
    Sval=componentdata(nieme).Sval;
    DStrainhandles=get(componenth(nieme).hpanelDStrain,'children');
    if isfield(Sys{nieme},{'DStrain'})
        Sys{nieme}=rmfield(Sys{nieme},{'DStrain'});
    end
    if Sval <1
        set(DStrainhandles,'enable','off')
        if isfield(Sys{nieme},'DStrain')
            Sys{nieme}=rmfield(Sys{nieme},'DStrain');
        end
    elseif Sval > 0.5 && componentdata(nieme).anisolw ==0
        set(DStrainhandles,'enable','off')
        if isfield(Sys{nieme},'DStrain')
            Sys{nieme}=rmfield(Sys{nieme},'DStrain');
        end
    elseif any(componentdata(nieme).AStrainval) ~=0 | any(componentdata(nieme).gStrainval) ~=0
        set(DStrainhandles,'enable','off')
        if isfield(Sys{nieme},'DStrain')
            Sys{nieme}=rmfield(Sys{nieme},'DStrain');
        end
    else set(DStrainhandles,'enable','on')
        for k=1:2
            set(componenth(nieme).heditDStrain(k),'string',num2str(componentdata(nieme).DStrainval(k),'%3.2f'));
        end
        Sys{nieme}.DStrain=componentdata(nieme).DStrainval;
    end
    if componentdata(nieme).DStrainval==0
        if isfield(Sys{nieme},{'DStrain'})
            Sys{nieme}=rmfield(Sys{nieme},{'DStrain'});
        end
    end
end

function SysgAStrain(nieme)
    gStrainhandles=get(componenth(nieme).hpanelgStrain,'children');
    AStrainhandles=get(componenth(nieme).hpanelAStrain,'children');
    if isfield(Sys{nieme},{'gStrain','AStrain'}) 
        Sys{nieme}=rmfield(Sys{nieme},{'gStrain','AStrain'});
    end
    if componentdata(nieme).anisolw & componentdata(nieme).DStrainval ==0
        set(gStrainhandles,'enable','on');
        set(AStrainhandles,'enable','on');
        for k=1:3
        set(componenth(nieme).heditgStrain(k),'string',num2str(componentdata(nieme).gStrainval(k),'%6.5f'));
        set(componenth(nieme).heditAStrain(k),'string',num2str(componentdata(nieme).AStrainval(k),'%3.2f'));
        end
        Sys{nieme}.gStrain=componentdata(nieme).gStrainval;
        Sys{nieme}.AStrain=componentdata(nieme).AStrainval;
    else set(gStrainhandles,'enable','off');
        set(AStrainhandles,'enable','off');
        if isfield(Sys{nieme},{'gStrain','AStrain'}) 
            Sys{nieme}=rmfield(Sys{nieme},{'gStrain','AStrain'});
        end
    end
    if componentdata(nieme).gStrainval==0
        if isfield(Sys{nieme},{'gStrain'})
            Sys{nieme}=rmfield(Sys{nieme},{'gStrain'});
        end
    end
    if componentdata(nieme).AStrainval==0
        if isfield(Sys{nieme},{'AStrain'})
            Sys{nieme}=rmfield(Sys{nieme},{'AStrain'});
        end
    end
end

function popupZFS(~,~)
    open ('Simultispin_ZFS.pdf');
end
    
function popupHStrain(~,~)
       popupHStrain = msgbox({'Anisotropic residual line width (full width at half height, FWHM) in MHz,';'describing broadening due to unresolved hyperfine couplings or other transition-independent effects.';'The three components are the Gaussian line widths in the x, y and z direction of the molecular frame.';'';'https://easyspin.org/documentation/broadenings.html'},'HStrain');
end

function popupgStrain(~,~)
       popupgStrain = msgbox({'Defines the g strain for the electron spin.';'It specifies the FWHM widths of the Gaussian distributions of the g principal values (gx, gy and gz).';'The distributions are assumed to be completely uncorrelated.';'';'https://easyspin.org/documentation/broadenings.html'},'gStrain');
end

function popupAStrain(~,~)
       popupAStrain = msgbox({'Vector of FWHM widths (in MHz) of the Gaussian distributions of the corresponding principal values in A (Ax, Ay, Az) of the first nucleus in the spin system.';'The distributions are completely uncorrelated.';'AStrain is not supported for systems with more than one electron spin, and it is only available for the first nucleus.';'';'https://easyspin.org/documentation/broadenings.html'},'AStrain');
end

function popupDStrain(~,~)
       popupDStrain = msgbox({'Widths (FWHM) in MHz of the Gaussian distributions of the scalar parameters D and E that specify the D matrix of the zero-field interaction.';'The distributions in D and in E are treated as uncorrelated.';'';'https://easyspin.org/documentation/broadenings.html'},'DStrain');
end

function popupA(~,~)
        isotopes;
end

function closeSimultispinX(hobject,~) %fermeture fenetre de composante
   if get(hrealtime,'value')==0
     place=find([componenth.hfig]==hobject); %indice de la composante consideree dans la structure des handles componenth
     figname=get(hobject,'name');
     fignumber=str2double(figname(13:end));
%     if componentdata(place).include==1 && ishandle(hplotsimall) %si derniere composante vient d'etre fermee et que simul affichee
     if componentdata(place).include==1  %si derniere composante vient d'etre fermee et que simul affichee
        if ishandle(hplotsimall)
            delete(hplotsimall);
            hplotsimall=hinit;
             set(hfitindicator,'visible','off');
            if ~ishandle(hspecexp) %pas de spectre exp => reinit des abscisses
                set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
            end

        end
         if ishandle(componenth(place).hplot) %si simul de cette composante est affichee=> l'effacer
            delete(componenth(place).hplot)
            componenth(place).hplot=hinit;
         end
         
         set(hsavesimul,'enable','off');
         set(hsuprsimul,'enable','off');
         %set(hcurrentsimul,'enable','off');
         %hplotsimall=hinit;
         set(hfreq,'visible','off');
         set(hlist,'value',[]); %pas de selection dans la listbox
         set(hfreq,'TooltipString','');
     end
     
     poscomponentfig(fignumber,:)=get(hobject,'pos'); %mise en memoire du vecteur position de la figure
     delete(hobject)
     componenth(place)=[]; %supression des handles de la composante dont la fenetre vient d'etre fermee
     componentdata(place)=[]; %supression des donnees de la composante dont la fenetre vient d'etre fermee
     Sys(place)=[]; %supression des donnees de la composante dont la fenetre vient d'etre fermee
     componentnumber=numel(componenth);
     
         
     if componentnumber==2 %componenth(1)=empty <=> plus qu'une seule fenetre affichee
         set(componenth(2).htextweight,'visible','off');
         set(componenth(2).heditweight,'visible','off');
         set(componenth(2).htextpercent,'visible','off');
         %set(componenth(2).htextpercent,'string',componentdata(i).textpercent);
     elseif componentnumber>2
         disppercent()
     else %componentnumber==1 ie plus de fenetre affichee
         dispsimulfreq=NaN;
         if isempty(get(hspecaxes,'children'))%~ishandle(hspecexp)
            set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
         end
         setlegend()
     end
%      if get(hrealtime,'value')==1
%          if ~reloading
%         runsimul2();%<=> si modif des include
%          end
%      else
        setlegend()
   else
        uiwait(msgbox({'WARNING:   "Real time" mode selected...';'';'Quit "Real time" first...'},...
            'Simultispin_WARNING','Warn','modal'));
   end
end
       
function Exp=Expgeneration() %generation de la  structure Exp  pour 
    % simulation des spectres avec easyspinfunc (easyspin)
   
        %Exp=struct('mwFreq',9.8,'Range',[300 400]); 
    if ishandle(hspecexp) %si spectre exp: frequence=freq exp
        freq=expfreq;
        str2disp=['Simulation frequency: ',num2str(freq),' GHz (from exp.)'];
    elseif ~isnan(dispsimulfreq) %si simul seule: frequence=frequence de la simul
        freq=dispsimulfreq;
        str2disp=['Simulation frequency: ',num2str(freq),' GHz (from prev. simul.)'];
    else %freq par defaut
        %freq=9.8;%GHz
        prompt = 'Enter frequency (GHz):';
        dlg_title = 'Simultispin_setFrequency';
        def={'9.8'}; %valeur par defaut
        freqtxt=inputdlg(prompt,dlg_title,1,def);
        freq=str2double(freqtxt);
        
        if isempty(freq)
            freq=NaN;
        end
            
        str2disp=['Simulation frequency: ',num2str(freq),' GHz (from user)'];
    end
    %freq
    if ~isnan(freq)
        set(hfreq,'string',str2disp,'visible','on');
    end
    RangeB=get(hspecaxes,'xlim');
    if isequal(RangeB,[0 1]) %valeur par defaut  si aucun spectre experimental n'est ou n'a ete affiche
         RangeB=defaultRangeB(freq);
    end
    
    %Temp=get(htempexp,'string');
    Temp=str2double(get(htempexp,'string'));
    if isnan(Temp)
       Temp=100;
    end
    set(htempexp,'string',Temp);
    
    mode=simulmode{get(hsimulmode,'value')};
    
    Exp=struct('mwFreq',freq,'Range',RangeB,'Temperature',Temp,'Mode',mode); %expfreq en GHz

end

function RangeB=defaultRangeB(freq)
    RangeB=floor(1e3*planck*freq*1e9/bmagn./defaultRangeg); %mT
end

function [y_,h]=mimilrescale(B,y,scalingfactor) %scaling
   switch get(get(hnormpanel,'SelectedObject'),'Tag')
       
       case 'intensity' %normalisation/Intensite
            h=1/abs(trapz(B,cumtrapz(B,y)));
            
       case 'minmax'
            %normalisation min max
            if max(y)~=min(y)
             h=1/(max(y)-min(y));
            else
                h=1;
            end
           
%        case 'proportion'
%             yexp=get(hspecexp,'ydata');
%             if max(yexp)~=min(yexp)
%              h=weight/(max(yexp)-min(yexp));
%             else
%                 h=weight;
%             end
        
   end
   
    h=h*scalingfactor;
    y_=y*h;
end

function setlegend() % supprime la veille legende, affiche la nouvelle legende sur le graphe 
    if ishandle(hlegend)
        delete(hlegend);
        hlegend=hinit;
    end
    i2bevisible=find([componentdata.status]); % tenir compte du 1er element car componentdata(1).status=0
    handlevec=[];
     legendtxt=[];

   if ishandle(hspecexp) && ishandle(hplotsimall)
        handlevec(1:2)=[hspecexp hplotsimall];
        legendtxt={'exp.','simul.'};

   elseif ishandle(hplotsimall) 
        handlevec=hplotsimall;
        legendtxt={'simul.'};
   elseif ishandle(hspecexp)
        handlevec=hspecexp;
        legendtxt={'exp.'};
   end
   nbspecdisp=numel(handlevec);
       if ~isempty(i2bevisible)
               classhinit=class(hinit);
               switch classhinit
                   case 'double' %version matlab ou handle=double
                       for k=1:numel(i2bevisible)
                       if ishandle(componenth(i2bevisible(k)).hplot) %la composante peut etre "visible" mais plot efface 
                          handlevec(k+nbspecdisp)=componenth(i2bevisible(k)).hplot;
                          legendtxt{k+nbspecdisp}=componentdata(i2bevisible(k)).name;
                       else
                           componentdata(i2bevisible(k)).status=0;
                           set(componenth(i2bevisible(k)).hvisible,'value',0);
                           set(componenth(i2bevisible(k)).hhide,'value',1);
                       end
                       end
                   case 'struct' %version matlab ou handle=struct
                       for k=1:numel(i2bevisible)
                       if isequal(componenth(i2bevisible(k)).hplot,hinit) %la composante peut etre "visible" mais plot efface 
                          handlevec(k+nbspecdisp)=componenth(i2bevisible(k)).hplot;
                          legendtxt{k+nbspecdisp}=componentdata(i2bevisible(k)).name;
                       else
                           componentdata(i2bevisible(k)).status=0;
                           set(componenth(i2bevisible(k)).hvisible,'value',0);
                           set(componenth(i2bevisible(k)).hhide,'value',1);
                       end
                       end
                end
       end

       if ~isempty(handlevec)
            hlegend=legend(hspecaxes,handlevec,legendtxt);
            set(hlegend,'Interpreter','none','color','none');
            if versionyear>2016
                set(hlegend,'AutoUpdate','off');
            end
       end
end

function setlegend2(index) % affiche la nouvelle legende sur le graphe en mode comparaison de simuls
                                %index=vecteur contenant les indices de
                                %listfile (=ceux de hprevsimplot)
    
    handlevec=[];
    legendtxt=[];
    if ishandle(hspecexp) 
        handlevec=hspecexp;
        legendtxt={'exp.'};
       
%         handlevec
%         legendtxt
   end
       nbspecdisp=numel(handlevec);
       for k=1:numel(index)
               handlevec(k+nbspecdisp)=hprevsimplot(k);
               legendtxt{k+nbspecdisp}=listfile{index(k)};
       end

       hlegend=legend(hspecaxes,handlevec,legendtxt);
       set(hlegend,'Interpreter','none');
end

function setlegend3(index) % affiche la nouvelle legende sur le graphe en mode comparaison de spec exp
                                %index=vecteur contenant les indices de
                                %listfileexp (=ceux de hprevsimplot)
    
    handlevec=[];
    legendtxt=[];

       nbspecdisp=numel(handlevec);
       for k=1:numel(index)
               handlevec(k+nbspecdisp)=hprevsimplot(k);
               legendtxt{k+nbspecdisp}=listfileexp{index(k)};
       end

       hlegend=legend(hspecaxes,handlevec,legendtxt);
       set(hlegend,'Interpreter','none');
end

function plotspecexp(deltaB)% affiche spectre experimental y en tenant compte du decalage en
    % champ(deltaB=reel-lu)

    if ishandle(hspecexp)       
        delete(hspecexp)
    end
    Bexp=Bexpinit+deltaB; %champ decale en mT
    hspecexp=plot(hspecaxes,Bexp,specexp,'k','linewidth',1);hold(hspecaxes,'on');
    set(hspecexp, 'ButtonDownFcn',@MouseleftclickexpCllbck);
    
    set(hspecaxes,'Ytick',NaN,'XTickMode','auto');
    xlabel(hspecaxes,'Magnetic Field [mT]');
    %fullscale(Bexp,specexp);
    setlegend()
    
    set(hresetfreq,'enable','off');
    %reload?
end

function MouseleftclickexpCllbck(~,~)
    if ishandle(hpoint)
        delete(hpoint)
    end
    if ishandle(hvert)
        delete(hvert)
    end
     p = get(hspecaxes,'CurrentPoint');
     p = p(1,1:2);
     str2disp=[num2str(p(1),'%3.2f'),'mT, ',num2str(p(2),'%3.3f'),', g=',num2str(planck*expfreq*1e9/bmagn/p(1)*1e3,'%6.5f')];
     set(hcursorinfo,'string',str2disp,'visible','on','foregroundcolor','k');
     hpoint=plot(p(1),p(2),'ok','markersize',6,'markerfacecolor','k');
     hvert=plot([p(1) p(1)],get(hspecaxes,'ylim'),':k','linewidth',1);
end

function MouseleftclicksimCllbck(~,~)
    if ishandle(hpoint)
        delete(hpoint)
    end
    if ishandle(hvert)
        delete(hvert)
    end
     p = get(hspecaxes,'CurrentPoint');
     p = p(1,1:2);
     str2disp=[num2str(p(1),'%3.2f'),'mT, ',num2str(p(2),'%3.3f'),', g=',num2str(planck*dispsimulfreq*1e9/bmagn/p(1)*1e3,'%6.5f')];
     set(hcursorinfo,'string',str2disp,'visible','on','foregroundcolor','m');
     hpoint=plot(p(1),p(2),'om','markersize',6,'markerfacecolor','m');
     hvert=plot([p(1) p(1)],get(hspecaxes,'ylim'),':m','linewidth',1);
end

function MouseleftclickaxeCllbck(~,~)
    set(hcursorinfo,'string','','visible','off');
    if ishandle(hpoint)
        delete(hpoint)
    end
    if ishandle(hvert)
        delete(hvert)
    end
end
    
    
function fullscale(x,y)
    maxy=max(y);
    miny=min(y);
    h=maxy-miny;
%     if (miny-fsfactor*h)==0 && (maxy+fsfactor*h)==0 
        axis(hspecaxes,[x(1) x(end) miny-fsfactor*h maxy+fsfactor*h]);
%     else %pas de resonance dans la plage de champ
%         set(hspecaxes,'xlim',[0 1],'ylim',[0 1],'Xtick',NaN); %reinitialisation si pas de simul affichee
%     end
    if ishandle(hvert)
        set(hvert,'ydata',get(hspecaxes,'ylim'));
    end
end          

%% functions gestion sauvegarde ...
function add2list(file,path)
    set(hlist,'value',[]);
    rang2test=find(ismember(listfile,file));
    rang=0;
    if isempty(rang2test) % si ce nom de fichier n'est pas deja affiche
        rang=numel(listfile)+1;
        listfile{rang}=file;
        listpath{rang}=path;
        list2disp{rang}=[num2str(rang),': ',file];
    else
          for k=1:numel(rang2test)
             if strcmp(path,listpath{rang2test(k)}) %sinon si meme chemin
                 rang=rang2test(k);
             end
          end
          if rang==0 %si chemin different
            rang=numel(listfile)+1;
            listfile{rang}=file;
            listpath{rang}=path;
            list2disp{rang}=[num2str(rang),': ',file];
          end
    end

    set(hlist,'string',list2disp,'value',rang);
end

function add2listexp(file,path)
    set(hlistexp,'value',[]);
    rang2test=find(ismember(listfileexp,file));
    rang=0;
    if isempty(rang2test) % si ce nom de fichier n'est pas deja affiche
        rang=numel(listfileexp)+1;
        listfileexp{rang}=file;
        listpathexp{rang}=path;
        list2dispexp{rang}=[num2str(rang),': ',file];
    else
          for k=1:numel(rang2test)
             if strcmp(path,listpathexp{rang2test(k)}) %sinon si meme chemin
                 rang=rang2test(k);
             end
          end
          if rang==0 %si chemin different
            rang=numel(listfileexp)+1;
            listfileexp{rang}=file;
            listpathexp{rang}=path;
            list2dispexp{rang}=[num2str(rang),': ',file];
          end
    end
    set(hlistexp,'string',list2dispexp,'value',rang);
end

function loadanddisp(prevdata) %charge et affiche simul anterieure sauvee
       %%% champs attendus
%          waitedfields={'Exp','Syssimul','datasimul'};
%          if isfield(prevdata,waitedfields)
            %numel([prevdata.datasimul])
            %simul type
            %save('test.mat','prevdata')
            set(hfitindicator,'visible','off');
             if ishandle(hpoint)
                delete(hpoint)
                delete(hvert)
                set(hcursorinfo,'string','','visible','off');
            end
            type=prevdata(1).datasimul.type;
            componentdata(1).type=type;
            set(hsimultype,'value',find(ismember(simultype,type)));
            switch type
             case 'Fast Motion'
                 easyspinfunc=@garlic;
                 lwmax=1;
                 minsteplw=0.01/lwmax; %facteur d'increment min 
                 maxsteplw=0.05/lwmax; %facteur d'increment max
             case 'Frozen Solution'
                 easyspinfunc=@pepper;
                 lwmax=500;
                 minsteplw=0.5/lwmax; %facteur d'increment min 
                 maxsteplw=1/lwmax; %facteur d'increment max
            end

             nbcomponent2disp=numel(prevdata.datasimul); %nb de composantes a afficher
             %handles des figures Simultispin_X encore affichees
             allfigname=get(findobj('type','figure'),'name'); %cellarray avec noms des figures ouvertes
             if ishandle(hmt2mhz) %si fenetre conversion affichee
                 [~,index]=ismember('Simultispin_conv',allfigname);
                 allfigname(index)=[];
             end
            if ~isempty(allfigname)
                if ~ischar(allfigname) %Si 1! fenetre (Simultispin_main), fignumber=1
                  pos2keep= find(strncmp(allfigname,'Simultispin',11)); %compare les 8 premiers caracteres peutetre existe-t-il d'autres fenetres ouvertes
                  allfigname2=cell(1,numel(pos2keep));
                  for k=1:numel(pos2keep)
                      allfigname2{k}=allfigname{pos2keep(k)};
                  end
                  allfigname2=sort(allfigname2);% +petit au + grand ('Simultispin_main' a la fin)
                  oldhfig=-ones(1,numel(allfigname2)-1); %init
                  for i=1:numel(allfigname2)-1
                      oldhfig(i)=findobj('type','figure','-and','name',allfigname2{i});
                  end
                else
                    oldhfig=[];
                end
            end
             %oldhfig=[componenth.hfig] %handles des figures Simultispin_X encore affichees (1er element de componenth: initialisation)
             oldnbcomponent=numel(oldhfig);%-1;%nb de composantes encore affichees
%             hfig2del=[componenth.hfig]; %handles des figures Simultispin_X a supprimer (1er element de componenth: initialisation)
%              if numel(hfig2del)>=2 %s'il y a des fenetres a fermer
%                  for k=hfig2del(2:end)
%                     closeSimultispinX(k);
%                  end;
%              end

             diffnb=nbcomponent2disp-oldnbcomponent; %nb de composantes a afficher - nb de composante affichees
             if diffnb>0
                if versionyear>=2014
                        hfigtemp=gobjects(1,diffnb); %handle=structure
                else
                        hfigtemp=-1*ones(1,diffnb); %init (-1 ~= handle); %handle=double
                end
 
                    for k=1:diffnb
                        hfigtemp(k)=opencomponentwin; % ouverture d'une nouvelle fenetre de composante Simultispin_X
                        place=find([componenth.hfig]==hfigtemp(k)); %indice de la composante consideree dans la structure des handles componenth
                        componentdata(place)=componentdata(1); %init
                        Sys{place}=Sys{1}; %init
                    end
                   % hfigtemp
                   % if numel(oldhfig)==1 %pas de fenetres prealablement ouvertes
                    %    newhfig=hfigtemp;
                    %else
                    %    newhfig=[oldhfig(2:end),hfigtemp];
                    %end
                    newhfig=[oldhfig,hfigtemp];
             elseif diffnb<0
                 newhfig=oldhfig(1:nbcomponent2disp);
                 for h=oldhfig(nbcomponent2disp+1:end)
                     closeSimultispinX(h);
                 end
             else
                 newhfig=oldhfig(1:end);
             end          
             
             for h=[componenth.hplot]
                 if ishandle(h)
                    set(h,'visible','off');% efface composantes affichees 
                 end
             end
                   
             %newhfig
             tempprevdatasimul=update_simuldata(prevdata.datasimul);
             for k=1:nbcomponent2disp %affichage des fenetres et remplissage
                place=find([componenth.hfig]==newhfig(k)); %indice de la composante consideree dans la structure des handles componenth
                componentdata(place)=tempprevdatasimul(k);
                Sys(place)=prevdata.Syssimul(k);
                dispcomponent(place); % remplissage de la fenetre avec donnees correspondantes
                componenth(place).hplot=hinit;
                set(componenth(place).hslidlorentzian,'Min',lwmin,'Max',lwmax,'SliderStep',[minsteplw maxsteplw]);
                set(componenth(place).hslidgaussian,'Min',lwmin,'Max',lwmax,'SliderStep',[minsteplw maxsteplw]);
             end
             Exp=prevdata.Exp;
             dispsimulfreq=prevdata.Exp.mwFreq; %frequence de la simulation affichee 
             mode=prevdata.Exp.Mode;
             set(hsimulmode,'value',find(ismember(simulmode,mode)));
             Temp=prevdata.Exp.Temperature;
             set(htempexp,'string',Temp);
             
             plotsimul(prevdata);

             %Exp=prevdata.Exp;
             if strcmp(get(hlist,'enable'),'off')
             set(hlist,'enable','on');
             set(hsuprfromlist,'enable','on');
             set(hexpfromlist,'enable','on');
             set(hupsim,'enable','on');
             set(hdownsim,'enable','on');
             set(hsavesimul,'enable','off');
             end
             %dispsimulfreq=prevdata.Exp.mwFreq;  %frequence de la simulation affichee
             if get(hrealtime,'value')==1
                testwarning();%teste plage de champs et frequences
             end
             set(hsuprsimul,'enable','on');
             if ishandle(hspecexp)
                dispfitindicator() %affichage de l'indicateur de fit si bonnes plages de champ et bonnes frequences
             end

            for k=2:numel(componenth)
                    figure(componenth(k).hfig);%au premier plan...
            end
            
            figure(hSimultispinmain);%au premier plan...

% 
%          else
%              file=char(listfile(get(hlist,'value')));
%              
%              
%              %disp(['The file ',file,' is not a previous simulation of Simultispin.']);
%             uiwait(msgbox({'WARNING:   Wrong file...';'';['The file ',file,' is not a previous simulation of Simultispin.']},...
%                  'Simultispin_WARNING','Warn','modal'));
%              %suprfromlist()
%          end
end

function newstruct=update_simuldata(initstruct) %Si simul sauvee avec version precedente de SimLabel=> ajouter des champs...
    newstruct=initstruct;
    if ~isfield(initstruct,'anisolw') %simul sauvee avec version precedente sans check aniso lw
        [~,nbcomp]=size(initstruct);
         for k=1:nbcomp
                if (initstruct(k).gaussianval==0 & initstruct(k).lorentzianval==0)
                    initstruct(k).anisolw=1;
                elseif (initstruct(k).gaussianval~=0 | initstruct(k).lorentzianval~=0) & (any(initstruct(k).HStrainval~=0) | any(initstruct(k).gStrainval~=0) | any(initstruct(k).AStrainval~=0))
                    initstruct(k).anisolw=1;
                         uiwait(msgbox({'WARNING:   Broadening conflict...';'';'2 types of broadening have been set for the simulation.';'';'Check/uncheck the broadening option to select only one type of broadening: convolutional (lw) or strains';'Run the sim again to update the spectrum.'},...
                'Simultispin_WARNING','Warn','modal'));	
                else initstruct(k).anisolw=0;
                end
         end
    newstruct=orderfields(initstruct,[1:3 24 4:23]); %remise dans l'ordre de componentdata pour permettre assignation suivante
    end
        if ~isfield(newstruct,'DStrainval') %simul sauvee avec version precedente sans check aniso lw
        [~,nbcomp]=size(newstruct);
        for k=1:nbcomp
             newstruct(k).DStrainval=[0 0];
        end 
        newstruct=orderfields(newstruct,[1:20 25 21:24]); %remise dans l'ordre de componentdata pour permettre assignation suivante
        end
end

function plotsimul(prevdata)
        nbcomponent=numel(prevdata.datasimul);
        if ishandle(hplotsimall)
            delete(hplotsimall)
        end

        for k=1:nbcomponent
            compsimul(k,:)=prevdata.datasimul(k).specsimul;
            if ~prevdata.datasimul(k).include
                compsimul(k,:)=deal(0);
            end
        end
%         [dispspecsimul,h,delta]=mimilrescale(sum(compsimul,1));% somme des simul de composantes, recalee

        dispspecsimul=sum(compsimul,1);% somme des simul de composantes, 
        Bsimul=linspace(prevdata.Exp.Range(1),prevdata.Exp.Range(2),numel(dispspecsimul)); %champ magnetique de la simul
        [dispspecsimul,scalefact]=mimilrescale(Bsimul,dispspecsimul,str2double(get(hscalingval,'string')));% somme des simul de composantes, recalee
        
        %affichage simul anterieure
        hplotsimall=plot(hspecaxes,Bsimul,dispspecsimul,'m','linewidth',1);hold(hspecaxes,'on');
        set(hplotsimall, 'ButtonDownFcn',@MouseleftclicksimCllbck);
        set(hspecaxes,'Ytick',NaN,'XTickMode','auto');
        xlabel(hspecaxes,'Magnetic Field [mT]');
        if ~ishandle(hspecexp)
            fullscale(Bsimul,dispspecsimul);
        else
            fullscale(Bexp,specexp);
            uistack(hspecexp,'top'); %spectre exp au 1er plan
        end
        setlegend();
        %dispsimulfreq=prevdata.Exp.mwFreq;
        

        %if dispsimulfreq==9.8 %affichage de la frquence de calcul
        %    str2disp=['Simulation frequency: ',num2str(prevdata.Exp.mwFreq),' GHz (default)'];
        %else
            str2disp=['Simulation frequency: ',num2str(prevdata.Exp.mwFreq),' GHz (from exp. or prev. sim.)'];
        %end
        
        set(hfreq,'string',str2disp,'visible','on');
        %%%%
end

function [B,y]=prevsimul(prevdata) %retourne champ B et spectre simule de simul sauvee
        nbcomponent=numel(prevdata.datasimul);
        for k=1:nbcomponent
            compsimul(k,:)=prevdata.datasimul(k).specsimul;
        end
        y=sum(compsimul,1);% somme des simul de composantes       
        B=linspace(prevdata.Exp.Range(1),prevdata.Exp.Range(2),numel(y)); %champ magnetique de la simul
        y=mimilrescale(B,y,1);%,prevdata.datasimul(1).weightval);% somme des simul de composantes, recalee
        set(hscalingval,'string',num2str(1,'%3.2f'),'backgroundcolor','w');
end

function warnstatus=testwarning() %teste plage de champs et frequences
    warnstatus=0;
    epsB=1e-13;
     if dispsimulfreq~=expfreq && ~isnan(expfreq) && ~isequal([Bsimul(1) Bsimul(end)],get(hspecaxes,'xlim'))
             uiwait(msgbox({'WARNING:   Field Ranges and Frequencies conflicts...';'';'You should first perform global simulation with "Run. Simul."...'},...
                 'Simultispin_WARNING','Warn','modal'));
             warnstatus=1;
     else
         if dispsimulfreq~=expfreq && ~isnan(expfreq) % si frequence exp et de la simul affichee sont differentes
             uiwait(msgbox({'WARNING:   Frequencies conflict...';'';'You should first perform global simulation with "Run. Simul."...'},...
                 'Simultispin_WARNING','Warn','modal'));
             warnstatus=1;
         end
         Bdiff=abs([Bsimul(1) Bsimul(end)]-get(hspecaxes,'xlim'));
         if Bdiff(1)>=epsB || Bdiff(2)>=epsB
             %~isequal([Bsimul(1) Bsimul(end)],get(hspecaxes,'xlim')) %si plages de champs affichee et de la simul differentes
             uiwait(msgbox({'WARNING:   Field Ranges conflict...';'';'You should first perform global simulation with "Run. Simul."...'},...
                 'Simultispin_WARNING','Warn','modal'));
             warnstatus=1;
         end
     end
end

function testwarning4deltaB() %test les deux frequences lors d'un deltaB
    if ishandle(hplotsimall)
        simfreq=dispsimulfreq;
    else
        simfreq=NaN;
    end
    if simfreq~=expfreq && ~isnan(simfreq)% si frequence exp et de la simul affichee sont differentes
        uiwait(msgbox({'WARNING:   Frequencies conflict...';'';'You should first perform global simulation with "Run. Simul."...'},...
              'Simultispin_WARNING','Warn','modal'));
    end
end

function savepar(fullname,rang) %param de la simul dans fichier par 
    datastruct=load(fullfile(listpath{rang},listfile{rang}),'-mat'); 
    fid = fopen([fullname(1:end-4),'.par'],'w');
    if ~isempty(rang)
        fprintf(fid,'%s\n',['path: ',listpath{rang}]);
        fprintf(fid,'%s\n',' ');
        fprintf(fid,'%s\n',['simul. name: ',listfile{rang}(1:end-4)]);
        fprintf(fid,'%s\n',' ');
        fprintf(fid,'%s\n',['simul. type: ',simultype{get(hsimultype,'value')}]);
        fprintf(fid,'%s\n',['simul. mode: ',simulmode{get(hsimulmode,'value')}]);
        fprintf(fid,'%s\n',['simul. Temp (K): ',get(htempexp,'string')]);
        fprintf(fid,'%s\n',[get(hfreq,'string')]);
        fprintf(fid,'%s\n',' ');
    end
    if ~isempty(expspecf)
        fprintf(fid,'%s\n',['exp. spectrum from ',expspecf]);
        fprintf(fid,'%s\n',' ');
    end
    nbcomp=numel(datastruct.datasimul);
    for k=1:nbcomp
        fprintf(fid,'%s\n',datastruct.datasimul(k).name);
        tempstruct=datastruct.Syssimul{k};
        parametres=evalc('tempstruct');
        fprintf(fid,'%s\n',parametres(:,102:end)); %resultat sans 'ans =' 102:end au lieu de 16:end pour enlever l'affichage du code inutile
        %fprintf(fid,'%s\n','');
        parametres=[];
    end
      fprintf(fid,'%s\n','A, [D E], HStrain, AStrain and DStrain values in MHz');
      fprintf(fid,'%s\n','A (mT) = [A(MHz)E9 * 6.62608E-34] / [g * 9.2401E-24]');
      fprintf(fid,'%s\n','1 MHz = 0.333E-4 cm-1');
   fclose(fid);  
end 

function dispfitindicator() %affichage de l'indicateur de fit si bonnes plages de champ et bonnes frequences (hspecexp est un handle)
    % indicateur inspire d'un chi 2. Calcul sur les spectres absorption
    % pour ponderer le tout   
    epsB=1e-13;
         Bdiff=abs([Bsimul(1) Bsimul(end)]-get(hspecaxes,'xlim'));
         testBsweep= (Bdiff(1)<=epsB || Bdiff(2)<=epsB); %logical: 1 si plages equivalentes a 1e-13 pres.
         if dispsimulfreq==expfreq  && testBsweep %isequal([Bsimul(1) Bsimul(end)],get(hspecaxes,'xlim'))
             intspecexp=cumtrapz(get(hspecexp,'xdata'),specexp'); %spectre absorption exp
             intsimul=cumtrapz(Bsimul,dispspecsimul); %spectre absorption simul
             Bcalcfitext=[max([Bsimul(1),Bexp(1)]),min([Bsimul(end),Bexp(end)])]; %extrema plage pour calculer fitindicator
             Bcalcfit=linspace(Bcalcfitext(1),Bcalcfitext(2),1000); %plage pour calculer fitindicator (1000 pts)
            %alignement des grilles!
            intspecexp_=interp1(Bexp,intspecexp,Bcalcfit,'spline');
            intsimul_=interp1(Bsimul,intsimul,Bcalcfit,'spline');
            specexp_=interp1(Bexp,specexp',Bcalcfit,'spline');
            dispspecsimul_=interp1(Bsimul,dispspecsimul,Bcalcfit,'spline');

            fitindicatorabs=sum((intspecexp_-intsimul_).^2)/sum(intspecexp_.^2); %indicateur de fit (pas vraiment chi 2)
            fitindicatordataasis=sum((specexp_-dispspecsimul_).^2)/sum(specexp_.^2); %indicateur de fit (pas vraiment chi 2)

            set(hfitindicator,'string',['fit=',num2str(fitindicatordataasis,'%4.3f'),'/',num2str(fitindicatorabs,'%4.3f')],'visible','on');
         end
end

function disabletool()
        if ishandle(hpoint)
        delete(hpoint)
        delete(hvert)
        set(hcursorinfo,'string','','visible','off');
    end
        set (hexpx,'enable','on');
        set (hsetB,'enable','on');
        set (hzoomin,'enable','on');
        set (hzoomout,'enable','on');
        set (hhand,'enable','on');
        set (hresetfreq,'enable','off');
        set (hrunsimul,'enable','off');
        set (haddcomp,'enable','off');
        set (hsimultype,'enable','off');
        set (hlist,'enable','on');
        set (htempexp,'enable','off');
        set (htemptext,'enable','off');
        set (hsimulmode,'enable','off');
        set (hupsim,'enable','off');
        set (hdownsim,'enable','off');
        set (hsuprfromlist,'enable','off');
        set (hexpfromlist,'enable','off');
        set (hlistexp,'enable','off');
        set (hsuprfromlistexp,'enable','off');
        set (hupexp,'enable','off');
        set (hdownexp,'enable','off');
        set (hdeltaB1,'enable','off');
        set (hdeltaBslid,'enable','off');
        set (hdeltaBval,'enable','off');
        set(hrealtime,'enable','off');
        set (hsuprexp, 'enable', 'off');
        set (hsuprsimul, 'enable', 'off');
        set (hdefaultpar, 'enable', 'off');
        set (hloadexp, 'enable', 'off');
        set (hloadsim, 'enable', 'off');
        set (hesfit,'enable','off');  
        set(hresidue,'enable','off');
end

function enabletool()
           set (hexpx,'enable','on');
          set (hsetB,'enable','on');
          set (hzoomin,'enable','on');
          set (hzoomout,'enable','on');
          set (hhand,'enable','on');
          set (hrunsimul,'enable','on');
          set (haddcomp,'enable','on');
          set (hsimultype,'enable','on');
          set (hlist,'enable','on');
          set (htempexp,'enable','on');
          set (htemptext,'enable','on');
          set (hsimulmode,'enable','on');
          set (hupsim,'enable','on');
          set (hdownsim,'enable','on');
          set (hsuprfromlist,'enable','on');
          set (hexpfromlist,'enable','on');
          set (hlistexp,'enable','on');
          set (hsuprfromlistexp,'enable','on');
          set (hupexp,'enable','on');
          set (hdownexp,'enable','on');
          set(hrealtime,'enable','on');
          set (hsuprexp, 'enable', 'on');
          set (hsuprsimul, 'enable', 'on');
          set (hdefaultpar, 'enable', 'on');
          set (hloadexp, 'enable', 'on');
          set (hloadsim, 'enable', 'on');
          set (hesfit,'enable','on');
end

%% ESFIT


function openesfit(~,~)
    selectedrank=get(hlist,'value');
%     if isempty(selectedrank) || isempty(listfile)
%         uiwait(msgbox('WARNING:   No saved simulation selected...','Simultispin_WARNING','Warn','modal'));
%         %warningstatus=1; 
%     end
    epsB=1e-13;
    if ~isempty(selectedrank) && ishandle(hspecexp) && ~isempty(listfile) 
        if abs(Bsimul(1)-Bexp(1))>epsB  || abs(Bsimul(end)-Bexp(end))>epsB
            uiwait(msgbox('WARNING:   Field range of the simulation too large...','Simultispin_WARNING','Warn','modal'));
            warningstatus=1; 
        else
            warningstatus=testwarning(); %si warningstatus=0 pas de warning affiche
        end
    if warningstatus==0 
        %supression des fits precedents non sauves
        fitname=evalin('base','who(''-regexp'', ''fit*'')');
        if ~isempty(fitname)
            for k=1:numel(fitname)
                evalin('base',['clear ',fitname{k}])
            end
        end
        
        simulfile4esfit=fullfile(listpath{selectedrank},listfile{selectedrank}); %simulation manuelle utilisee pour lancer esfit

        alldata={}; %cell array contenant donnees affichees sur fenetre avant esfit (init)

        i2beincluded=find([componentdata.include]); % pas tenir compte du 1er element de ce tableau = 1 =>componentdata d'initialisation
        Sysfit=[];%initialisation du tableau de structures contenant les composantes pour le fit 
        for k=2:numel(i2beincluded) %generation de la structure Sys pour fit
                Sysfit{k-1}=Sys{i2beincluded(k)};
                componentdatafit(k-1)=componentdata(i2beincluded(k));
        end
        nbcmp2fit=numel(Sysfit);
        
        %%%%%  Recherche de correlation(s) possibles(s) (ie meme g,lw,A,Nucs) si plus d'une composante  %%%%%
        cancellation=0; %abandon quand correlation
        correlinfo=''; %string pour preciser l'existence ou non de correlation
        correltab=1:nbcmp2fit; %init: pas de correlation, correltab=[1 2 3 ...]
                       % si especes 1 et 2 correlees, correltab=[1 1 3 ...]
                        % si especes 2 et 3 correlees, correltab=[1 2 2 ...]
        testcorrel=zeros(nbcmp2fit);%init de la matrice des correlations
                
        if nbcmp2fit>1 
            Systest=Sysfit; %structure Sys avec les champs d'interet pour test
            for k=1:nbcmp2fit
                Systest{k}=rmfield(Systest{k},'weight'); %plus que g,lw,A,Nucs dans Systest
            end
            %Systest=[Systest{:}];%structure array plutot que cell array 

            for k=1:nbcmp2fit
               for n=1:nbcmp2fit
                   testcorrel(k,n)=isequal(Systest(k),Systest(n));
               end
            end
        end

        if ~isequal(testcorrel,eye(nbcmp2fit)) && nbcmp2fit>1 %testcorrel n'est pas la matrice identite: correlation(s) possible(s) si plusieurs composantes 
            correltemp=correltab;
            qst=''; %pour affichage dans boite de dialogue
            nbcorrel=0;
            for k=1:nbcmp2fit
                correltemp(k)=find(testcorrel(:,k),1,'first');
            end
            for k=1:nbcmp2fit
                if ~isequal(correltemp(k),k) %correltemp(2)=1 :correlation possible entre compste 1 et 2
                   qst=[qst,'''',componentdata(i2beincluded(correltemp(k)+1)).name,''' and ''',componentdata(i2beincluded(k+1)).name,''' are similar (same g, lw and A values).\n'];
                    nbcorrel=nbcorrel+1;
                    correlinfo{nbcorrel}=['C',num2str(i2beincluded(correltemp(k))),' and C',num2str(i2beincluded(k)),' are correlated.'];
                end
            end
            qst=[qst,' \nDo you want their g, lw and A values to be fitted being correlated?'];
            titleqst='to fitting mode: available correlation(s)...';
            choice = questdlg(sprintf(qst),titleqst,'Yes','No','Cancel','No');          
            switch choice
                case 'Cancel'
                    set(hcomponentletter,'string','','visible','off');
                    componentdatafit=componentdatainit;%composantes utilisees pour esfit (conservation de l'info d'axialite)
                    clc
                    cancellation=1; %abandon quand correlation
                    correltab=[];
                case 'Yes'
                    correltab=correltemp;
%                     if nbcorrel>1
%                         correlinfo='Correlations are considered...';
%                     else
%                         correlinfo='A correlation is considered...';
%                     end
                case 'No'
                    %correltab=correltab;
                    correlinfo='No correlation is considered...';
            end
        end
        
        if ~cancellation   % pas d'abandon quand correlation (si correlation possible)     
            line=1;%numero de la ligne courante de alldata
            for k=1:numel(Sysfit) %generation des donnees de la table pour esfit (chaque valeur par defaut = 10% des chifres apres la virgule (?))
                % + generation du cell array alldata pour choix des donnees variables
                Varytemp=Sysfit{k};
                names=fieldnames(Sysfit{k}); %liste des noms de champ de la composante k
                 strk=num2str(k);
                for n=1:numel(names)
                    %fieldval=getfield(Sysfit{k},names{n});%valeur du champ considere
                    switch names{n}
                        case 'S'
                            if k==correltab(k)
                               Varytemp.S=0;
                               alldata(line,:)={false,['S_C',strk],num2str(Sysfit{k}.S(1),'%2.1f'),num2str(Varytemp.S,'%2.1f')};line=line+1;
                            end
                        case 'g'
                            if k==correltab(k)
                               Varytemp.g=ones(1,3)*1e-1;%1e-5*gmax/2;
                               iperp=componentdatafit(k).axialcombinationg;
                               if sum(isnan(iperp))==0 % g axial (g non axial=[NaN NaN])
                                   iperp=componentdatafit(k).axialcombinationg;
                                   ipar=setdiff(1:3,iperp);
                                   alldata(line,:)={false,['gperp_C',strk],num2str(Sysfit{k}.g(iperp(1)),'%6.5f'),num2str(Varytemp.g(iperp(1)),'%6.5f')};line=line+1;
                                   alldata(line,:)={false,['gpar_C',strk],num2str(Sysfit{k}.g(ipar),'%6.5f'),num2str(Varytemp.g(ipar),'%6.5f')};line=line+1;
                               else
                                   alldata(line,:)={false,['g_C',strk,'(1)'],num2str(Sysfit{k}.g(1),'%6.5f'),num2str(Varytemp.g(1),'%6.5f')};line=line+1;
                                   alldata(line,:)={false,['g_C',strk,'(2)'],num2str(Sysfit{k}.g(2),'%6.5f'),num2str(Varytemp.g(2),'%6.5f')};line=line+1;
                                   alldata(line,:)={false,['g_C',strk,'(3)'],num2str(Sysfit{k}.g(3),'%6.5f'),num2str(Varytemp.g(3),'%6.5f')};line=line+1;
                               end
                            end
                        case 'lw'
                            if k==correltab(k)
                               Varytemp.lw=0.5*Sysfit{k}.lw;
                               alldata(line,:)={false,['lw_C',strk,'(1)'],num2str(Sysfit{k}.lw(1),'%3.2f'),num2str(Varytemp.lw(1),'%3.2f')};line=line+1;
                               alldata(line,:)={false,['lw_C',strk,'(2)'],num2str(Sysfit{k}.lw(2),'%3.2f'),num2str(Varytemp.lw(2),'%3.2f')};line=line+1;
                            end
                        case 'weight'
                            if numel(i2beincluded)>2 %si plusieurs composantes
                                Varytemp.weight=0.9*Sysfit{k}.weight;
                                alldata(line,:)={false,['weight_C',strk],num2str(Sysfit{k}.weight,'%3.2f'),num2str(Varytemp.weight,'%3.2f')};line=line+1;
    %                         else
    %                             Sysfit{k}=rmfield(Sysfit{k},'weight');
                            end
    %                     case 'Nucs'
    %                         Varytemp=rmfield(Varytemp,'Nucs');
    case 'A'
                            if k==correltab(k)
                                Varytemp.A=0.5*Sysfit{k}.A;
                                if numel(Varytemp.A)==6 %2 couplages
                                    iperp=componentdatafit(k).axialcombinationA(1,:);
                                    if sum(isnan(iperp))==0 % A1 axial
                                        ipar=setdiff(1:3,iperp);
                                        alldata(line,:)={false,['A1perp_C',strk],num2str(Sysfit{k}.A(1,iperp(1)),'%3.1f'),num2str(Varytemp.A(1,iperp(1)),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A1par_C',strk],num2str(Sysfit{k}.A(1,ipar),'%3.1f'),num2str(Varytemp.A(1,ipar),'%3.1f')};line=line+1;
        %                                 Sysfit{k}.A1perp=Sysfit{k}.A(1,iperp(1)); %nouveaux champs dans Sysfit
        %                                 Sysfit{k}.A1par=Sysfit{k}.A(1,ipar); 
                                    else
                                        alldata(line,:)={false,['A1_C',strk,'(1)'],num2str(Sysfit{k}.A(1,1),'%3.1f'),num2str(Varytemp.A(1,1),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A1_C',strk,'(2)'],num2str(Sysfit{k}.A(1,2),'%3.1f'),num2str(Varytemp.A(1,2),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A1_C',strk,'(3)'],num2str(Sysfit{k}.A(1,3),'%3.1f'),num2str(Varytemp.A(1,3),'%3.1f')};line=line+1;
        %                                 Sysfit{k}.A1=Sysfit{k}.A(1,:); %nouveaux champs dans Sysfit
                                    end
                                    iperp=componentdatafit(k).axialcombinationA(2,:);
                                    if sum(isnan(iperp))==0 % A2 axial
                                        ipar=setdiff(1:3,iperp);
                                        alldata(line,:)={false,['A2perp_C',strk],num2str(Sysfit{k}.A(2,iperp(1)),'%3.1f'),num2str(Varytemp.A(2,iperp(1)),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A2par_C',strk],num2str(Sysfit{k}.A(2,ipar),'%3.1f'),num2str(Varytemp.A(2,ipar),'%3.1f')};line=line+1;
                                    else
                                        alldata(line,:)={false,['A2_C',strk,'(1)'],num2str(Sysfit{k}.A(2,1),'%3.1f'),num2str(Varytemp.A(2,1),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A2_C',strk,'(2)'],num2str(Sysfit{k}.A(2,2),'%3.1f'),num2str(Varytemp.A(2,2),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A2_C',strk,'(3)'],num2str(Sysfit{k}.A(2,3),'%3.1f'),num2str(Varytemp.A(2,3),'%3.1f')};line=line+1;
                                    end
                                else %numel(Varytemp.A)=3 ie 1! couplage hyperfin
                                    iperp=componentdatafit(k).axialcombinationA(1,:);
                                    if sum(isnan(iperp))==0 % A axial
                                        ipar=setdiff(1:3,iperp);
                                        alldata(line,:)={false,['A1perp_C',strk],num2str(Sysfit{k}.A(iperp(1)),'%3.1f'),num2str(Varytemp.A(iperp(1)),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A1par_C',strk],num2str(Sysfit{k}.A(ipar),'%3.1f'),num2str(Varytemp.A(ipar),'%3.1f')};line=line+1;
                                     else
                                        alldata(line,:)={false,['A1_C',strk,'(1)'],num2str(Sysfit{k}.A(1),'%3.1f'),num2str(Varytemp.A(1),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A1_C',strk,'(2)'],num2str(Sysfit{k}.A(2),'%3.1f'),num2str(Varytemp.A(2),'%3.1f')};line=line+1;
                                        alldata(line,:)={false,['A1_C',strk,'(3)'],num2str(Sysfit{k}.A(3),'%3.1f'),num2str(Varytemp.A(3),'%3.1f')};line=line+1;
                                    end
                                end
                            end
                        
                          case 'HStrain'
                            if k==correltab(k)
                               Varytemp.HStrain=0.5*Sysfit{k}.HStrain;
                               iperp=componentdatafit(k).axialcombinationHStrain;
                               if sum(isnan(iperp))==0 % HStrain axial (HStrain non axial=[NaN NaN])
                                   iperp=componentdatafit(k).axialcombinationHStrain;
                                   ipar=setdiff(1:3,iperp);
                                   alldata(line,:)={false,['HStrainperp_C',strk],num2str(Sysfit{k}.HStrain(iperp(1)),'%3.1f'),num2str(Varytemp.HStrain(iperp(1)),'%3.1f')};line=line+1;
                                   alldata(line,:)={false,['HStrainpar_C',strk],num2str(Sysfit{k}.HStrain(ipar),'%3.1f'),num2str(Varytemp.HStrain(ipar),'%3.1f')};line=line+1;
                               else
                                   alldata(line,:)={false,['HStrain_C',strk,'(1)'],num2str(Sysfit{k}.HStrain(1),'%3.1f'),num2str(Varytemp.HStrain(1),'%3.1f')};line=line+1;
                                   alldata(line,:)={false,['HStrain_C',strk,'(2)'],num2str(Sysfit{k}.HStrain(2),'%3.1f'),num2str(Varytemp.HStrain(2),'%3.1f')};line=line+1;
                                   alldata(line,:)={false,['HStrain_C',strk,'(3)'],num2str(Sysfit{k}.HStrain(3),'%3.1f'),num2str(Varytemp.HStrain(3),'%3.1f')};line=line+1;
                               end
                            end
                            
                          case 'gStrain'
                            if k==correltab(k)
                               Varytemp.gStrain=0.5*Sysfit{k}.gStrain;
                               iperp=componentdatafit(k).axialcombinationgStrain;
                               if sum(isnan(iperp))==0 % gStrain axial (gStrain non axial=[NaN NaN])
                                   iperp=componentdatafit(k).axialcombinationgStrain;
                                   ipar=setdiff(1:3,iperp);
                                   alldata(line,:)={false,['gStrainperp_C',strk],num2str(Sysfit{k}.gStrain(iperp(1)),'%4.3f'),num2str(Varytemp.gStrain(iperp(1)),'%4.3f')};line=line+1;
                                   alldata(line,:)={false,['gStrainpar_C',strk],num2str(Sysfit{k}.gStrain(ipar),'%4.3f'),num2str(Varytemp.gStrain(ipar),'%4.3f')};line=line+1;
                               else
                                   alldata(line,:)={false,['gStrain_C',strk,'(1)'],num2str(Sysfit{k}.gStrain(1),'%4.3f'),num2str(Varytemp.gStrain(1),'%4.3f')};line=line+1;
                                   alldata(line,:)={false,['gStrain_C',strk,'(2)'],num2str(Sysfit{k}.gStrain(2),'%4.3f'),num2str(Varytemp.gStrain(2),'%4.3f')};line=line+1;
                                   alldata(line,:)={false,['gStrain_C',strk,'(3)'],num2str(Sysfit{k}.gStrain(3),'%4.3f'),num2str(Varytemp.gStrain(3),'%4.3f')};line=line+1;
                               end
                            end
                          
                           case 'AStrain'
                            if k==correltab(k)
                               Varytemp.AStrain=0.5*Sysfit{k}.AStrain;
                               iperp=componentdatafit(k).axialcombinationAStrain;
                               if sum(isnan(iperp))==0 % AStrain axial (AStrain non axial=[NaN NaN])
                                   iperp=componentdatafit(k).axialcombinationAStrain;
                                   ipar=setdiff(1:3,iperp);
                                   alldata(line,:)={false,['AStrainperp_C',strk],num2str(Sysfit{k}.AStrain(iperp(1)),'%3.1f'),num2str(Varytemp.AStrain(iperp(1)),'%3.1f')};line=line+1;
                                   alldata(line,:)={false,['AStrainpar_C',strk],num2str(Sysfit{k}.AStrain(ipar),'%3.1f'),num2str(Varytemp.AStrain(ipar),'%3.1f')};line=line+1;
                               else
                                   alldata(line,:)={false,['AStrain_C',strk,'(1)'],num2str(Sysfit{k}.AStrain(1),'%3.1f'),num2str(Varytemp.AStrain(1),'%3.1f')};line=line+1;
                                   alldata(line,:)={false,['AStrain_C',strk,'(2)'],num2str(Sysfit{k}.AStrain(2),'%3.1f'),num2str(Varytemp.AStrain(2),'%3.1f')};line=line+1;
                                   alldata(line,:)={false,['AStrain_C',strk,'(3)'],num2str(Sysfit{k}.AStrain(3),'%3.1f'),num2str(Varytemp.AStrain(3),'%3.1f')};line=line+1;
                               end
                            end 
                            
                           case 'D'
                            if k==correltab(k)
                               Varytemp.D=0.5*Sysfit{k}.D;
                               alldata(line,:)={false,['D_C',strk,'(1)'],num2str(Sysfit{k}.D(1),'%3.2f'),num2str(Varytemp.D(1),'%3.2f')};line=line+1;
                               alldata(line,:)={false,['D_C',strk,'(2)'],num2str(Sysfit{k}.D(2),'%3.2f'),num2str(Varytemp.D(2),'%3.2f')};line=line+1;
                            end
                            
                        case 'DStrain'
                            if k==correltab(k)
                               Varytemp.DStrain=0.5*Sysfit{k}.DStrain;
                               alldata(line,:)={false,['DStrain_C',strk,'(1)'],num2str(Sysfit{k}.DStrain(1),'%3.2f'),num2str(Varytemp.DStrain(1),'%3.2f')};line=line+1;
                               alldata(line,:)={false,['DStrain_C',strk,'(2)'],num2str(Sysfit{k}.DStrain(2),'%3.2f'),num2str(Varytemp.DStrain(2),'%3.2f')};line=line+1;
                            end                            
                    end
                end
                clear names

            end
            %alldata{1,:}
            %%%%% figure avec tableau pour parametres variables
            hSimultispin2esfit=figure();%figure(max(findobj('type','figure'))+1); %pour ne pas superposer des figures
            pos=get(hSimultispinmain,'position');
            set(hSimultispin2esfit,'Units','pixels','position',[pos(1)+pos(3)/3 pos(2)+pos(4)/4 pos(3)/2.5 pos(4)/2],...
                 'Name','to fitting mode','Menubar', 'none', 'Toolbar', 'none',...
                 'NumberTitle','off','WindowStyle','modal',...
                 'color',[0.25 0.25 0.25],...
                 'CloseRequestFcn',@closefig2esfit);

            htable=uitable(hSimultispin2esfit,'Units','normalized','Position',...
                [0.01 0.01 0.78 0.98],'Data',alldata,...
                'columnname',{'','Name','center',['vary (',char(177),')']},...
                'columnformat',{'logical','char','char','char'},... plutot que numeric
                'ColumnEditable',[ true false true true],...
                'rowname',[],...
                'TooltipString',sprintf([char(183),' Hyperfine coupling A, Strains except gStrain and [D E] in MHz\n',char(183),' 0<nb of parameters<=30']),...
                'ColumnWidth',{17 65 55 55},...
                'CellEditCallback',@newalldata);

           hOK4esfit=uicontrol('Style','pushbutton',...
               'String','Go','Units','Normalized',...
               'fontunits','pixels','fontsize',ftsz,...
                'pos',[0.79 0.02 0.21 0.1],'parent',hSimultispin2esfit,...
                'Callback', @ok4esfit,...{@ok4esfit,selectedrank},...
                'TooltipString','Open "esfit" panel with the pre-selected parameters','enable','off');

           hcancel4esfit=uicontrol('Style','pushbutton',...
               'String','Cancel','Units','Normalized',...
               'fontunits','pixels','fontsize',ftsz,...
                'pos',[0.79 0.13 0.21 0.07],'parent',hSimultispin2esfit,...
                'Callback', @cancel4esfit,'TooltipString','Back to Simultispin','enable','on'); 

            hall4esfit=uicontrol('Style','pushbutton',...
               'String','All','Units','Normalized',...
               'fontunits','pixels','fontsize',ftsz,...
                'pos',[0.79 0.94 0.15 0.05],'parent',hSimultispin2esfit,...
                'Callback', @all4esfit,'TooltipString','Select all parameters','enable','on'); 

            hnone4esfit=uicontrol('Style','pushbutton',...
               'String','None','Units','Normalized',...
               'fontunits','pixels','fontsize',ftsz,...
                'pos',[0.79 0.88 0.15 0.05],'parent',hSimultispin2esfit,...
                'Callback', @none4esfit,'TooltipString','Unselect all parameters','enable','on'); 
            %%%%%%%%%%%

            for k=2:numel(componentdata) %affichage des corresponadances esfit et componentdata
                if componentdata(k).include
                    corres2disp{k-1}=[componentdata(k).name,': C',num2str(k-1)]; 
                end
            end
            if iscell(correlinfo) %il existe des correl
                for n=1:numel(correlinfo)
                    corres2disp{k-1+n}=correlinfo{n};
                end
            else %correlinfo='No correlation is considered...' =char
                corres2disp{k}=correlinfo;
            end
            set(hcomponentletter,'string',corres2disp,'visible','on');
            if sum(cell2mat(alldata(:,1)))>30
                set(hOK4esfit,'enable','off')
            end
            end
    end
    else
         uiwait(msgbox({'WARNING:   Several possible reasons...';'';[char(183),' No saved simulation selected'];[char(183),' No experimental spectrum loaded']},'Simultispin_WARNING','Warn','modal'));
    end
end


function quitesfit(~,~)
      %pour quitter esfit. Question pour importer les donnees issues de
      %esfit qui sont contenues dans structure "fit1" du workspace de base
      
      fitname=evalin('base','who(''-regexp'', ''fit*'')');

      % Construct a questdlg with 2 options
      nbfit=numel(fitname);
      askstr=[];
      switch nbfit
          case 1 %1!fit
              askstr='Do you want to save the fit result?';
          case 0
              
              hfigesfit=findobj('type','figure','-and','name','EasySpin Least-Squares Fitting');
              if ishandle(hfigesfit)
              choice1=questdlg({'No fit exported from EasySpin Least-Squares Fitting.';'';'Do you really want to quit fitting mode?'},'Back to Simultispin...','Yes','No','No');
                switch choice1
                    case 'Yes'
                        closeesfit();
                end            
              else
                  closeesfit();
              end
            otherwise
              askstr='Do you want to save the fit results?';
      end
     if ~isempty(askstr)
        choice2 = questdlg(askstr,'Back to Simultispin...','Yes','No','Cancel','Yes');
        % Handle response
        switch choice2
             case 'No'
                 closeesfit()

             case 'Yes'
                               
%                     hfigesfit=findobj('type','figure','-and','name','EasySpin Least-Squares Fitting'); 
%                     delete(hfigesfit)

                    datafromfit=load(simulfile4esfit,'-mat'); %chargement de 'Syssimul','datasimul','Exp' de la simul manuelle utilisee pour lancer esfit
                    if nbfit==1
                        [fitfile,path2fitfile]=uiputfile('*.sms',['Saving ',fitname{1}],[simulfile4esfit(1:end-4),'_fit']); %ouverture boite de dialogue dans repertoire courant (nom propose)
                        if fitfile~=0
                            fit=evalin('base',fitname{1});
                            savefit(fit,datafromfit,path2fitfile,fitfile);
                            loadanddisp(load(fullfile(path2fitfile,fitfile),'-mat')); %affichage du dernier
                        end

                    else
                        for k=1:nbfit
                            [fitfile,path2fitfile]=uiputfile('*.sms',['Saving ',fitname{k}],[simulfile4esfit(1:end-4),'_fit',num2str(k)]); %ouverture boite de dialogue dans repertoire courant (nom propose)
                            if fitfile~=0
                                fit=evalin('base',fitname{k});
                                savefit(fit,datafromfit,path2fitfile,fitfile);
                            end
                        end
                        if fitfile~=0
                            loadanddisp(load(fullfile(path2fitfile,fitfile),'-mat')); %affichage du dernier
                        end
                    end
                    closeesfit()
        end
     end
      delete(fullfile(path4function4esfit,'temporary_data4esfit.mat'));
      clc
end

function savefit(fit,datafromfit,path2fitfile,fitfile)
        nbcomp=numel(datafromfit.datasimul);
        Sysfromfit=fit.Sys; %Sys resultat du fit
        newSys=datafromfit.Syssimul; %nouveau Sys=Sys du .sms envoye vers esfit pour modification et sauvegarde dans nouveau .sms
        datasimul=datafromfit.datasimul; %nouveau datasimul  /componentdata envoye a esfit

        allfield=fieldnames(Sysfromfit); %liste des noms de champ
        num_cp=zeros(1,numel(allfield)); %tableau des numeros de composante correspondant a allfield
        for k=1:numel(allfield)
            num_cp(k)=str2double(allfield{k}(end));
        end
        for k=1:nbcomp
           strk=num2str(k);
           strkcorr=num2str(correltab(k));
           %champs forcement presents
           if nbcomp>1
            eval(['datasimul(k).weightval=Sysfromfit.weight_C',strk,';']);
            newSys{k}.weight=datasimul(k).weightval;
           end      

           %indcpk= num_cp==k; %tableau des indices des champs de allfield correspondant a la composante k
           indcpkcorr= num_cp==correltab(k); %tableau des indices des champs de allfield correspondant a la composante a laquelle est correlee k
                % si pas de correlation, correltab(k)=k
          % names=allfield(indcpk); %liste des noms de champ associe a la composante k
           namescorr=allfield(indcpkcorr); %liste des noms de champ associe a la composante a laquelle est correlee k
           isA1=0; %indicateur de presence de A1
           isA2=0; %indicateur de presence de A2
           for n=1:numel(namescorr)
            switch namescorr{n}
               case ['lw_C',strkcorr]
                     eval(['datasimul(k).gaussianval=Sysfromfit.lw_C',strkcorr,'(1);']);
                     eval(['datasimul(k).lorentzianval=Sysfromfit.lw_C',strkcorr,'(2);']);
                     newSys{k}.lw=[datasimul(k).gaussianval datasimul(k).lorentzianval];
                     
               case ['A1perp_C',strkcorr]
                      iperp=datasimul(correltab(k)).axialcombinationA(1,:); %indice directions perp (2elements)
                      ipar=setdiff(1:3,iperp); 
                      eval(['datasimul(k).Aval(1,[',num2str(iperp),'])=(Sysfromfit.A1perp_C',strkcorr,');']);
                      eval(['datasimul(k).Aval(1,',num2str(ipar),')=(Sysfromfit.A1par_C',strkcorr,');']);
                      isA1=1;
                      
               case ['A1_C',strkcorr]
                      eval(['datasimul(k).Aval(1,:)=(Sysfromfit.A1_C',strkcorr,');']);
                      isA1=1;

               case ['A2perp_C',strkcorr]
                      iperp=datasimul(correltab(k)).axialcombinationA(2,:); %indice directions perp (2elements)
                      ipar=setdiff(1:3,iperp); 
                      eval(['datasimul(k).Aval(2,[',num2str(iperp),'])=(Sysfromfit.A2perp_C',strkcorr,');']);
                      eval(['datasimul(k).Aval(2,',num2str(ipar),')=(Sysfromfit.A2par_C',strkcorr,');']);
                      isA2=1;

               case ['A2_C',strkcorr]   
                      eval(['datasimul(k).Aval(2,:)=(Sysfromfit.A2_C',strkcorr',');']);
                      isA2=1;

               case ['gperp_C',strkcorr]
                       iperp=datasimul(correltab(k)).axialcombinationg; %indice directions perp (2elements)
                       ipar=setdiff(1:3,iperp);
                       eval(['datasimul(k).gval([',num2str(iperp),'])=Sysfromfit.gperp_C',strkcorr,';']);
                       eval(['datasimul(k).gval(',num2str(ipar),')=Sysfromfit.gpar_C',strkcorr,';']);
                       newSys{k}.g=datasimul(k).gval;

                case ['g_C',strkcorr]
                       eval(['datasimul(k).gval=Sysfromfit.g_C',strkcorr,';']);
                       newSys{k}.g=datasimul(k).gval;
                       
                case ['S_C',strkcorr]
                       eval(['datasimul(k).Sval=Sysfromfit.S_C',strkcorr,';']);
                       newSys{k}.S=datasimul(k).Sval;
                
                case ['HStrainperp_C',strkcorr]
                       iperp=datasimul(correltab(k)).axialcombinationHStrain; %indice directions perp (2elements)
                       ipar=setdiff(1:3,iperp);
                       eval(['datasimul(k).HStrainval([',num2str(iperp),'])=Sysfromfit.HStrainperp_C',strkcorr,';']);
                       eval(['datasimul(k).HStrainval(',num2str(ipar),')=Sysfromfit.HStrainpar_C',strkcorr,';']);
                       newSys{k}.HStrain=datasimul(k).HStrainval;

                case ['HStrain_C',strkcorr]
                       eval(['datasimul(k).HStrainval=Sysfromfit.HStrain_C',strkcorr,';']);
                       newSys{k}.HStrain=datasimul(k).HStrainval;
                       
                 case ['gStrainperp_C',strkcorr]
                       iperp=datasimul(correltab(k)).axialcombinationgStrain; %indice directions perp (2elements)
                       ipar=setdiff(1:3,iperp);
                       eval(['datasimul(k).gStrainval([',num2str(iperp),'])=Sysfromfit.gStrainperp_C',strkcorr,';']);
                       eval(['datasimul(k).gStrainval(',num2str(ipar),')=Sysfromfit.gStrainpar_C',strkcorr,';']);
                       newSys{k}.gStrain=datasimul(k).gStrainval;

                case ['gStrain_C',strkcorr]
                       eval(['datasimul(k).gStrainval=Sysfromfit.gStrain_C',strkcorr,';']);
                       newSys{k}.gStrain=datasimul(k).gStrainval; 
                       
                case ['AStrainperp_C',strkcorr]
                       iperp=datasimul(correltab(k)).axialcombinationAStrain; %indice directions perp (2elements)
                       ipar=setdiff(1:3,iperp);
                       eval(['datasimul(k).AStrainval([',num2str(iperp),'])=Sysfromfit.AStrainperp_C',strkcorr,';']);
                       eval(['datasimul(k).AStrainval(',num2str(ipar),')=Sysfromfit.AStrainpar_C',strkcorr,';']);
                       newSys{k}.AStrain=datasimul(k).AStrainval;

                case ['AStrain_C',strkcorr]
                       eval(['datasimul(k).AStrainval=Sysfromfit.AStrain_C',strkcorr,';']);
                       newSys{k}.AStrain=datasimul(k).AStrainval;       
                  
               case ['D_C',strkcorr]
                 eval(['datasimul(k).Dval=0.333E-4*Sysfromfit.D_C',strkcorr,'(1);']);
                 eval(['datasimul(k).Eval=0.333E-4*Sysfromfit.D_C',strkcorr,'(2);']);
                 newSys{k}.D=[datasimul(k).Dval/0.333E-4 datasimul(k).Eval/0.333E-4];

               case ['DStrain_C',strkcorr]
                     eval(['datasimul(k).DStrainval=Sysfromfit.DStrain_C',strkcorr,';']);
                     newSys{k}.DStrain=datasimul(k).DStrainval;
            end
           end

            if isA1 %A1 existe
                if isA2
                    newSys{k}.A=(datasimul(k).Aval);
                else
                    newSys{k}.A=(datasimul(k).Aval(1,:));
                end
%                 newSys{k}.Nucs=Syssimul{k}.Nucs;
%             else
%                 newSys{k}=rmfield(Syssimul{k},'A');
            end

            datasimul(k).specsimul=easyspinfunc(newSys{k},datafromfit.Exp);

           clear names
        end
        
        datafromfit=rmfield(datafromfit,'datasimul');
        datafromfit=rmfield(datafromfit,'Syssimul');
        datafromfit.datasimul=datasimul;
        datafromfit.Syssimul=newSys;
        save(fullfile(path2fitfile,fitfile),'-struct','datafromfit');% sauvegarde de 'Syssimul','datasimul','Exp');%
        %evalin('base',['clear ', fit]); %suppression de fit du workspace de base
        add2list(fitfile,path2fitfile);
end

function closeesfit()% %ferme la figure esfit et remet les handle on et component visibles
   hfigesfit=findobj('type','figure','-and','name','EasySpin Least-Squares Fitting');
% hfigesfit
% hSimultispinmain
   if ishandle(hfigesfit)
       delete(hfigesfit)
   end 
   set(hcomponentletter,'string','','visible','off');
   set([componenth(2:end).hfig],'visible','on');
%    for k=1:numel(handlesmainenab4esfit)
%        if ~ishandle(handlesmainenab4esfit(k))
%            disp([num2str(k),': ', num2str(handlesmainenab4esfit(k))])
%        end
%    end
   set(hesfit,'Callback', @openesfit,'TooltipString','Open "esfit" panel (fitting with EasySpin)','String','ESFIT');
   set(handlesmainenab4esfit,'enable','on'); % tous les handles anciennement 'on 'redeviennent 'on'
  
   datafit=[]; % 1 structure regroupant toutes les composantes a envoyer a esfit 
   componentdatafit=componentdatainit;%composantes utilisees pour esfit (conservation de l'info d'axialite)
   Vary=[]; %structure des paramaetres variables envoyes a esfit
    htable=hinit; %handle de la table de parametres a transferer a esfit
    hOK4esfit=hinit; %handle bouton OK de la table de parametres a transferer a esfit
    warningstatus=0;% pas de warning affiche
    simulfile4esfit=[]; %simulation manuelle utilisee pour lancer esfit
    handlesmainenab4esfit=[];%liste des handles enable 'on' sur Simultispin_main avant esfit
    correltab=[]; %table des corelations pour esfit 
    delete(fullfile(path4function4esfit,'temp_function4esfit.m'));
end

function ok4esfit(hObject,~)%,selectedrank)
     %simulfile4esfit=fullfile(listpath{selectedrank},listfile{selectedrank}); %simulation manuelle utilisee pour lancer esfit

        %boutons enable off 
        set([componenth(2:end).hfig],'visible','off');
        handlesmainenab4esfit=findobj(hSimultispinmain,'-property','enable','-and','enable','on'); %tous les handles de Simultispin_main avec propriete 'enable' on
        handlesmainenab4esfit(handlesmainenab4esfit==hesfit)=[]; %sans le handle de "esfit"
        handlesmainenab4esfit(handlesmainenab4esfit==hcomponentletter)=[]; %sans le handle du texte d'info sur correspondance lettre component
        handlesmainenab4esfit(handlesmainenab4esfit==hdoc)=[]; %sans le handle de "?"
        handlesmainenab4esfit(end+1:end+3)=[hzoomin,hzoomout,hhand]; %handles zoom et main sont invisibles
        set(handlesmainenab4esfit,'enable','off'); % tous les handles 'enbale' off => pas d'action possible pendant esfit     
        set(hesfit,'Callback', @quitesfit,'TooltipString',sprintf('Back to Simultispin:\nImport data from "esfit" (fitting with EasySpin)?'),'String','Esc. Fit Mode');

        %nouveau Vary et Sysfit si modification des valeurs dans tableau
        
        Vary=[];%struct([]);
        Sysfit=Vary;

        nbvar=size(alldata,1);%sizealldata(1);
        for k=1:nbvar
            fieldval=alldata{k,2}; % du genre g_C1(1) ou weight_C2
        
            if alldata{k,1} %si parametre inclu dans fit
                strvalvary=alldata{k,4};%num2str(alldata{k,4},strformat);
            else
                strvalvary='0';
            end
            strvalsys=alldata{k,3};%num2str(alldata{k,3},strformat);
            %pbl si element de  structure avec que des zeros
            if ~isnan(str2double(strvalvary)) && ~isnan(str2double(strvalsys)) % si entrees non numeriques
               eval(['Vary.',fieldval,'=',strvalvary,';']);
               eval(['Sysfit.',fieldval,'=',strvalsys,';']);
            else
                error([fieldval,' contains non numeric data...']);
            end
        end

        if ~isequal([Bexp(1) Bexp(end)],Exp.Range)
            newBexp=linspace(Exp.Range(1),Exp.Range(2),1024);
            specexp4fit=interp1(Bexp,specexp,newBexp,'spline');
        else
            specexp4fit=specexp;
        end
       % save('test.mat','Sysfit')
        generate_function4esfit(Sysfit); %creation de la fonction de fitting

        esfit('temp_function4esfit',specexp4fit,Sysfit,Vary,Exp) %{Vary{1} Vary{2} Vary{3}}
        close(get(hObject,'parent')); %tue alldata Sys Vary        
end

function generate_function4esfit(Sys)%,ind)
    %creation de la fonction de fitting
    % Sys: systeme de spin customise pour le fit 
    %charfunction: chaine de caracteres contenant le nom de la fonction easyspin (garlic ou pepper)
    
    path4function4esfit=pwd;%path2expspec;
    fid=fopen(fullfile(path4function4esfit,'temp_function4esfit.m'),'w'); %nouvelle function dans repertoire courant pour etre utilisable par esfit
    fprintf(fid,'%s\n','function varargout = temp_function4esfit(Sys,Exp,SimOpt)');
    allfield=fieldnames(Sys); %liste des noms de champ
    nbcp=str2double(allfield{end}(end)); %nb de component=dernier caractere du dernier champ (A2par_C3)=> 3 composantes
   
    num_cp=zeros(1,numel(allfield)); %tableau des numeros de composante correspondant a allfield
    for k=1:numel(allfield)
        num_cp(k)=str2double(allfield{k}(end));
    end

    for k=1:nbcp
        indcpk= num_cp==k; %tableau des indices des champs de allfield correspondant a la composante k
        indcpkcorr= num_cp==correltab(k); %tableau des indices des champs de allfield correspondant a la composante a laquelle est correlee k
                % si pas de correlation, correltab(k)=k
        names=allfield(indcpk); %liste des noms de champ associe a la composante k
        namescorr=allfield(indcpkcorr); %liste des noms de champ associe a la composante a laquelle est correlee k
        
        strk=num2str(k);
        strkcorr=num2str(correltab(k));
        
        isA1=0; %indicateur de presence de A1
        isA2=0; %indicateur de presence de A2
        
        axialA=componentdatafit(correltab(k)).axialcombinationA;
        
        for n=1:numel(namescorr)
            switch namescorr{n}
                case ['lw_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.lw=Sys.lw_C',strkcorr,';']);
                    
                case ['g_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.g=Sys.g_C',strkcorr,';']);
                    
                case ['S_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.S=Sys.S_C',strkcorr,';']);
                    
                case ['gperp_C',strkcorr]
                    iperp=componentdatafit(correltab(k)).axialcombinationg; %indice directions perp (2elements)
                    ipar=setdiff(1:3,iperp);
                    fprintf(fid,'%s\n',['     Sys',strk,'.g([',num2str(iperp),'])=Sys.gperp_C',strkcorr,';']);
                    fprintf(fid,'%s\n',['     Sys',strk,'.g(',num2str(ipar),')=Sys.gpar_C',strkcorr,';']);

                case ['A1perp_C',strkcorr]
                    iperp=axialA(1,:); %indice directions perp (2elements)
                    ipar=setdiff(1:3,iperp);
                    fprintf(fid,'%s\n',['     A1([',num2str(iperp),'])=Sys.A1perp_C',strkcorr,';']);
                    fprintf(fid,'%s\n',['     A1(',num2str(ipar),')=Sys.A1par_C',strkcorr,';']);
                    isA1=1;
               
                case ['A2perp_C',strkcorr] 
                    iperp=axialA(2,:); %indice directions perp (2elements)
                    ipar=setdiff(1:3,iperp);
                    fprintf(fid,'%s\n',['     A2([',num2str(iperp),'])=Sys.A2perp_C',strkcorr,';']);
                    fprintf(fid,'%s\n',['     A2(',num2str(ipar),')=Sys.A2par_C',strkcorr,';']);
                    isA2=1;
                    
                case ['A1_C',strkcorr]
                    fprintf(fid,'%s\n',['     A1=Sys.A1_C',strkcorr,';']);
                    isA1=1;
                
                case ['A2_C',strkcorr]
                    fprintf(fid,'%s\n',['     A2=Sys.A2_C',strkcorr,';']);
                    isA2=1;
       
                case ['HStrain_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.HStrain=Sys.HStrain_C',strkcorr,';']);
                    
                case ['HStrainperp_C',strkcorr]
                    iperp=componentdatafit(correltab(k)).axialcombinationHStrain; %indice directions perp (2elements)
                    ipar=setdiff(1:3,iperp);
                    fprintf(fid,'%s\n',['     Sys',strk,'.HStrain([',num2str(iperp),'])=Sys.HStrainperp_C',strkcorr,';']);
                    fprintf(fid,'%s\n',['     Sys',strk,'.HStrain(',num2str(ipar),')=Sys.HStrainpar_C',strkcorr,';']);

                case ['gStrain_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.gStrain=Sys.gStrain_C',strkcorr,';']);
                    
                case ['gStrainperp_C',strkcorr]
                    iperp=componentdatafit(correltab(k)).axialcombinationgStrain; %indice directions perp (2elements)
                    ipar=setdiff(1:3,iperp);
                    fprintf(fid,'%s\n',['     Sys',strk,'.gStrain([',num2str(iperp),'])=Sys.gStrainperp_C',strkcorr,';']);
                    fprintf(fid,'%s\n',['     Sys',strk,'.gStrain(',num2str(ipar),')=Sys.gStrainpar_C',strkcorr,';']);
                    
                case ['AStrain_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.AStrain=Sys.AStrain_C',strkcorr,';']);
                    
                case ['AStrainperp_C',strkcorr]
                    iperp=componentdatafit(correltab(k)).axialcombinationAStrain; %indice directions perp (2elements)
                    ipar=setdiff(1:3,iperp);
                    fprintf(fid,'%s\n',['     Sys',strk,'.AStrain([',num2str(iperp),'])=Sys.AStrainperp_C',strkcorr,';']);
                    fprintf(fid,'%s\n',['     Sys',strk,'.AStrain(',num2str(ipar),')=Sys.AStrainpar_C',strkcorr,';']);    
    
                case ['D_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.D=Sys.D_C',strkcorr,';']);    
 
                case ['DStrain_C',strkcorr]
                    fprintf(fid,'%s\n',['     Sys',strk,'.DStrain=Sys.DStrain_C',strkcorr,';']);                      
            end
        end
              
        if isA1 %A1 existe
            Istr=componentdatafit(correltab(k)).Istr; %string contenant les spins nucleaires
            Istr1=Istr{1}; %char ou cell???
            if iscell(Istr1) %=> Istr1:char
                Istr1=Istr1{1};
            end
            indNuc1=ismember(differentI,Istr1); %indice du noyau1

            if isA2
                Istr2=Istr{2}; %char ou cell???
                if iscell(Istr2)%=> Istr2:char
                    Istr2=Istr2{1};
                end
                indNuc2= ismember(differentI,Istr2); %indice du noyau2
                fprintf(fid,'%s\n',['     Sys',strk,'.A=[A1;A2];']);
                fprintf(fid,'%s\n',['     Sys',strk,'.Nucs=''',differentNucs{indNuc1},',',differentNucs{indNuc2},''';']);
            else
                fprintf(fid,'%s\n',['     Sys',strk,'.A=A1;']);
                fprintf(fid,'%s\n',['     Sys',strk,'.Nucs=''',differentNucs{indNuc1},''';']);
            end
        end

        if k==1
            fprintf(fid,'%s\n',['     [x,y_(:,1)]=',func2str(easyspinfunc),'(Sys',strk,',Exp,SimOpt);']);
        else
            fprintf(fid,'%s\n',['     y_(:,',strk,')=',func2str(easyspinfunc),'(Sys',strk,',Exp,SimOpt);']);
        end
    end
    
    strcalc='y=y_(:,1)';
    if nbcp>1
       strcalc=[strcalc,'*Sys.weight_C1'];   
       for k=2:nbcp
           strk=num2str(k);
           strcalc=[strcalc,'+y_(:,',strk,')*Sys.weight_C',strk];
        end
    end
    fprintf(fid,'%s\n',['     ',strcalc,';']);
    fprintf(fid,'%s\n','     if nargout==1');
    fprintf(fid,'%s\n','        varargout={y};');
    fprintf(fid,'%s\n','     else');
    fprintf(fid,'%s\n','        varargout={x,y};');
    fprintf(fid,'%s\n','     end');   
    fprintf(fid,'%s','end');
    fclose(fid);  
end

function cancel4esfit(hObject,~)
    close(get(hObject,'parent'));
    set(hcomponentletter,'string','','visible','off');
    %datafit=[]; % 1 structure regroupant toutes les composantes a envoyer a esfit
     componentdatafit=componentdatainit;%composantes utilisees pour esfit (conservation de l'info d'axialite)
     correltab=[]; %table des corelations pour esfit
     % Vary=[]; %structure des paramaetres variables envoyes a esfit
%     alldata={}; %cell array contenant donnees affichees sur fenetre avant esfit
%     htable=hinit; %handle de la table de parametres a transferer a esfit
%     hOK4esfit=hinit; %handle bouton OK de la table de parametres a transferer a esfit
     clc
end

function closefig2esfit(hobject,~)
    delete(hobject);
    %datafit=[]; % 1 structure regroupant toutes les composantes a envoyer a esfit
    componentdatafit=componentdatainit;%composantes utilisees pour esfit (conservation de l'info d'axialite)
    %Vary=[]; %structure des paramaetres variables envoyes a esfit
    %alldata={}; %cell array contenant donnees affichees sur fenetre avant esfit
    htable=hinit; %handle de la table de parametres a transferer a esfit
    hOK4esfit=hinit; %handle bouton OK de la table de parametres a transferer a esfit
    %correltab=[]; %table des corelations pour esfit
    clc
end
    
function all4esfit(~,~)
    alldata(:,1)=deal({true});
    set(htable,'Data',alldata);
    nbdata2fit=sum(cell2mat(alldata(:,1)));
    if nbdata2fit>30 || nbdata2fit==0
        set(hOK4esfit,'enable','off')
    else
        set(hOK4esfit,'enable','on')
    end
end

function none4esfit(~,~)
    alldata(:,1)=deal({false});
    set(htable,'Data',alldata);
    set(hOK4esfit,'enable','off')
end

function newalldata(hobj,~)
        alldata=get(hobj,'data');
        nbdata2fit=sum(cell2mat(alldata(:,1)));
        if nbdata2fit>30 || nbdata2fit==0
            set(hOK4esfit,'enable','off')
        else
            set(hOK4esfit,'enable','on')
        end
end

end